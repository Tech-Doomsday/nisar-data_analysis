#include "Application.h"

#include <chrono>
#include <stdexcept>
#include <variant>

#include "../Utils/Log.h"

namespace lunar
{
	Application* Application::s_Instance = nullptr;
	std::vector<std::string> Application::s_Args;

	Application::Application(ApplicationSpec spec) : m_Spec(std::move(spec))
	{
		if (s_Instance) throw std::logic_error("lunar::Application: only one Application can exist at a time");
		s_Instance = this;
	}

	Application::~Application()
	{
		// By now the derived class' members are gone. Everything below still has the GL context.
		m_Running.store(false);
		StopLoops();
		try { ShutdownModules(); }
		catch (const std::exception& e) { LN_ERROR("exception while unmounting modules: " << e.what()); }
		catch (...) { LN_ERROR("unknown exception while unmounting modules"); }
		m_Gate.reset();

		if (m_PlatformReady)
		{
			m_PlatformReady = false;
			m_Window.Destroy();                 // after this no GL call is legal
		}
		s_Instance = nullptr;
	}

	Application& Application::Get()
	{
		if (!s_Instance) throw std::logic_error("lunar::Application::Get(): no application");
		return *s_Instance;
	}

	void Application::SetCommandLine(int argc, char** argv)
	{
		s_Args.clear();
		for (int i = 0; i < argc; ++i) s_Args.emplace_back(argv[i]);
	}

	FrameGate* Application::SetGate(std::unique_ptr<FrameGate> gate)
	{
		if (m_LoopsActive.load()) throw std::logic_error("Application::SetGate must be called before the loops start (OnStart)");
		m_Gate = std::move(gate);
		return m_Gate.get();
	}


	// ── run ──────────────────────────────────────────────────────────────────
	int Application::Run()
	{
		if (m_Started) throw std::logic_error("Application::Run() called twice");
		m_Started = true;

		m_Window.SetEventCallback([this](const events::Event& e) { DispatchEvent(e); });
		if (!m_Window.Create(m_Spec)) return 1;
		m_PlatformReady = true;
		m_Running.store(true);

		struct LoopGuard { Application& a; ~LoopGuard() { a.StopLoops(); } } guard{ *this };

		OnStart();
		ApplyPendingModules();                  // modules mounted before the platform existed

		m_LoopsActive.store(true);
		if (m_Spec.threading == ThreadingMode::Split)
			m_UpdateThread = std::thread(&Application::UpdateThreadMain, this);

		MainLoop();
		StopLoops();

		if (m_UpdateError) std::rethrow_exception(m_UpdateError);

		OnStop();
		ShutdownModules();
		m_Gate.reset();
		return m_ExitCode.load();
	}

	void Application::Quit(int exitCode)
	{
		if (exitCode != 0) m_ExitCode.store(exitCode);
		m_Running.store(false);
		if (m_PlatformReady) Window::WakeUp();  // lets WaitEvents() return (minimized window)
	}

	void Application::StopLoops()
	{
		m_Running.store(false);
		if (m_UpdateThread.joinable())
		{
			if (m_Gate) m_Gate->Interrupt();            // the update thread may be parked in WaitUpdate()
			m_UpdateThread.join();
		}
		m_LoopsActive.store(false);
	}


	// ── loops ────────────────────────────────────────────────────────────────
	void Application::MainLoop()
	{
		const bool single = (m_Spec.threading == ThreadingMode::Single);

		FrameClock renderClock(m_Spec.maxDelta);
		FrameClock updateClock(m_Spec.maxDelta);    // Single mode only
		Input input;                                // Single mode only
		FpsCounter fps(m_Spec.fpsInterval);
		Backoff backoff;

		while (m_Running.load(std::memory_order_relaxed))
		{
			m_Window.PollEvents();
			m_Relay.Flush();
			if (m_Window.ShouldClose()) Quit();     // RequestClose() does not go through the close callback
			ApplyPendingModules();
			if (!m_Running.load(std::memory_order_relaxed)) break;

			if (m_Window.IsMinimized())
			{
				// nothing to draw and the ring fills up on its own, so the simulation pauses too
				m_Window.WaitEvents(0.1);
				renderClock.Reset();
				continue;
			}

			bool progressed = false;
			if (single) progressed = StepUpdate(updateClock, input);
			if (RenderFrame(renderClock, fps)) progressed = true;

			if (progressed) backoff.Reset();
			else backoff.Pause();
		}
	}

	bool Application::RenderFrame(FrameClock& clock, FpsCounter& fps)
	{
		if (m_Gate && !m_Gate->AcquireRender()) return false;

		const float dt = clock.Tick();
		const RenderContext ctx{ dt, clock.Time(), clock.Ticks(), fps.Fps(), m_Window.Metrics(), m_Gate.get() };

		// only the main thread ever changes the stack, and never while we are in here
		for (auto it = m_Modules.rbegin(); it != m_Modules.rend(); ++it)
			(*it)->OnRender(ctx);

		m_Window.SwapBuffers();
		if (m_Gate) m_Gate->ReleaseRender();

		fps.Frame();
		fps.Update();
		return true;
	}

	bool Application::StepUpdate(FrameClock& clock, Input& input)
	{
		if (m_Gate && !m_Gate->AcquireUpdate()) return false;

		const float dt = clock.Tick();              // after the acquire: waiting for a slot just lengthens dt (clamped)
		m_Relay.Drain(input);
		const UpdateContext ctx{ dt, clock.Time(), clock.Ticks(), input, m_Window.Metrics(), m_Gate.get() };

		{
			std::shared_lock lock(m_ModuleMutex);
			for (const auto& m : m_Modules)
				m->OnUpdate(ctx);
		}

		if (m_Gate) m_Gate->ReleaseUpdate();
		return true;
	}

	void Application::UpdateThreadMain()
	{
		try
		{
			using SteadyClock = std::chrono::steady_clock;

			FrameClock clock(m_Spec.maxDelta);
			Input input;
			Backoff backoff;

			// without a gate nothing paces this loop, so pace it
			const bool paced = !m_Gate && m_Spec.updateHz > 0.0;
			const auto period = std::chrono::duration_cast<SteadyClock::duration>(std::chrono::duration<double>(paced ? 1.0 / m_Spec.updateHz : 0.0));
			auto next = SteadyClock::now();

			while (m_Running.load(std::memory_order_relaxed))
			{
				if (StepUpdate(clock, input))
				{
					backoff.Reset();
					if (paced)
					{
						next += period;
						const auto now = SteadyClock::now();
						if (next < now - period * 4) next = now;       // fell far behind: do not try to catch up
						else std::this_thread::sleep_until(next);
					}
				}
				else if (!(m_Gate && m_Gate->WaitUpdate()))      // no free slot: park if the gate can, else poll
				{
					backoff.Pause();
				}
			}
		}
		catch (...)
		{
			m_UpdateError = std::current_exception();
			Quit(1);
		}
	}


	// ── events ───────────────────────────────────────────────────────────────
	void Application::DispatchEvent(const events::Event& ev)
	{
		std::visit([this](const auto& e)
		{
			using E = std::remove_cvref_t<decltype(e)>;
			const bool consumed = m_Bus.Emit(e);

			if constexpr (std::is_same_v<E, events::WindowClosed>)
			{
				if (consumed) m_Window.CancelClose();   // a listener vetoed the close
				else Quit();
			}
			else
			{
				m_Relay.Offer(e, consumed);             // update thread gets what the main thread did not consume
			}
		}, ev);
	}


	// ── modules ──────────────────────────────────────────────────────────────
	void Application::QueueMount(std::unique_ptr<Module> mod)
	{
		{
			std::lock_guard<std::mutex> lock(m_PendingMutex);
			PendingOp op;
			op.mount = std::move(mod);
			m_Pending.push_back(std::move(op));
		}
		// before the loops start, on the main thread: mount right now
		if (m_PlatformReady && !m_LoopsActive.load()) ApplyPendingModules();
	}

	void Application::QueueUnmount(Module* mod)
	{
		{
			std::lock_guard<std::mutex> lock(m_PendingMutex);
			for (const PendingOp& p : m_Pending)
				if (p.unmount == mod) return;           // already requested
			PendingOp op;
			op.unmount = mod;
			m_Pending.push_back(std::move(op));
		}
		if (m_PlatformReady && !m_LoopsActive.load()) ApplyPendingModules();
	}

	void Application::ApplyPendingModules()
	{
		if (m_Applying) return;                         // an OnMount that mounts more: the outer loop picks them up
		m_Applying = true;
		struct Reset { bool& f; ~Reset() { f = false; } } reset{ m_Applying };

		for (;;)
		{
			std::vector<PendingOp> ops;
			{
				std::lock_guard<std::mutex> lock(m_PendingMutex);
				ops.swap(m_Pending);
			}
			if (ops.empty()) break;

			for (PendingOp& op : ops)
			{
				if (op.mount)
				{
					Module* raw = op.mount.get();
					raw->Attach(*this, m_Bus);
					raw->OnMount();                     // not visible to the update thread yet, no lock needed
					std::unique_lock lock(m_ModuleMutex);
					m_Modules.Insert(std::move(op.mount));
				}
				else if (op.unmount)
				{
					std::unique_ptr<Module> owned;
					{
						std::unique_lock lock(m_ModuleMutex);   // waits for the update thread to finish its tick
						owned = m_Modules.Extract(op.unmount);
					}
					if (owned)
					{
						owned->OnUnmount();
						owned->Detach();
					}
				}
			}
		}
	}

	void Application::ShutdownModules()
	{
		{
			std::lock_guard<std::mutex> lock(m_PendingMutex);
			m_Pending.clear();                          // requested but never mounted: just destroyed
		}
		// highest priority first. The loops are stopped by now, so no lock is needed.
		while (std::unique_ptr<Module> m = m_Modules.ExtractFirst())
		{
			m->OnUnmount();
			m->Detach();
		}                                               // ~Module runs here, GL still alive
	}
}
