#pragma once
#include <atomic>
#include <exception>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <thread>
#include <type_traits>
#include <vector>

#include "../Event/EventBus.h"
#include "../Input/InputRelay.h"
#include "../Utils/FrameClock.h"
#include "ApplicationSpec.h"
#include "FrameGate.h"
#include "Module.h"
#include "ModuleStack.h"
#include "Window.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Application  (replaces Lenz::Runtime)
//
//      class RiftApp : public lunar::Application
//      {
//      public:
//          RiftApp() : Application({ .title = "Lunar Rift", .width = 1600, .height = 900 }) {}
//          void OnStart() override { Mount<Rift>(); }
//      };
//      LUNAR_MAIN(RiftApp)
//
//  Lifetime
//    constructor          nothing GL yet. Set up plain C++ state here.
//    Run()                window + context  ->  OnStart()  ->  loops  ->  OnStop()  ->  modules unmounted
//    destructor           window + context destroyed (after the subclass' own members are gone)
//  OnStart() is called from Run(), so a derived override really runs (Lenz called the
//  virtual OnInit() from the base constructor, which never reaches the override).
//
//  Threads (ThreadingMode::Split, the default)
//    main thread     owns the window and the GL context: events, Module::OnRender, buffer swaps
//    update thread   Module::OnUpdate; makes no GL calls
//  Pacing between the two is the FrameGate (see FrameGate.h). With ThreadingMode::Single both
//  run alternately on the main thread.
//
//  Shutdown order (this is what Lenz got wrong): update thread joined -> OnStop -> modules
//  unmounted and destroyed (GL still alive) -> subclass members -> window / context.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	class Application
	{
	public:
		explicit Application(ApplicationSpec spec = ApplicationSpec{});
		virtual ~Application();
		Application(const Application&) = delete;
		Application& operator=(const Application&) = delete;

		// Blocks until Quit(). Returns the exit code.
		int Run();

		// Any thread.
		void Quit(int exitCode = 0);
		bool IsRunning() const { return m_Running.load(std::memory_order_relaxed); }

		// ── hooks (main thread, GL context current) ──────────────────────────
		virtual void OnStart() {}      // mount modules, create the scene
		virtual void OnStop() {}       // loops have stopped, modules are still mounted

		// ── modules ──────────────────────────────────────────────────────────
		// Mount from OnStart / OnMount / event handlers / Update. The module is constructed right
		// away and the reference is valid immediately. OnMount() runs at once when called before the
		// loops start (e.g. in OnStart), otherwise at the beginning of the next frame on the main thread.
		template<class T, class... Args>
		T& Mount(Args&&... args)
		{
			static_assert(std::is_base_of_v<Module, T>, "T must derive from lunar::Module");
			auto mod = std::make_unique<T>(std::forward<Args>(args)...);
			T& ref = *mod;
			QueueMount(std::move(mod));
			return ref;
		}

		// Same timing rules as Mount. False if no mounted module of that type exists.
		template<class T>
		bool Unmount()
		{
			T* m = m_Modules.Find<T>();
			if (!m) return false;
			QueueUnmount(m);
			return true;
		}

		// Main thread only. From the update thread keep the pointer you got in OnMount instead.
		template<class T>
		T* GetModule() const { return m_Modules.Find<T>(); }

		// ── frame ring ───────────────────────────────────────────────────────
		// Before the loops start (OnStart). Returns the gate for convenience.
		FrameGate* SetGate(std::unique_ptr<FrameGate> gate);
		FrameGate* GetGate() const { return m_Gate.get(); }
		template<class G>
		G* GetGate() const { return dynamic_cast<G*>(m_Gate.get()); }

		// ── access ───────────────────────────────────────────────────────────
		EventBus& Events() { return m_Bus; }
		Window& GetWindow() { return m_Window; }
		const ApplicationSpec& GetSpec() const { return m_Spec; }

		static Application& Get();
		static bool Exists() { return s_Instance != nullptr; }

		// command line, set by LUNAR_MAIN before the application is constructed
		static void SetCommandLine(int argc, char** argv);
		static const std::vector<std::string>& GetArgs() { return s_Args; }

	private:
		struct PendingOp
		{
			std::unique_ptr<Module> mount;      // set: mount this
			Module* unmount = nullptr;          // set: unmount this
		};

		void QueueMount(std::unique_ptr<Module> mod);
		void QueueUnmount(Module* mod);
		void ApplyPendingModules();             // main thread
		void ShutdownModules();

		void MainLoop();
		void UpdateThreadMain();
		bool StepUpdate(FrameClock& clock, Input& input);
		bool RenderFrame(FrameClock& clock, FpsCounter& fps);
		void StopLoops();
		void DispatchEvent(const events::Event& e);

		ApplicationSpec m_Spec;
		EventBus m_Bus;
		Window m_Window;
		InputRelay m_Relay;
		std::unique_ptr<FrameGate> m_Gate;

		ModuleStack m_Modules;
		mutable std::shared_mutex m_ModuleMutex;    // update thread: shared while it iterates; main thread: unique to change the stack
		std::mutex m_PendingMutex;
		std::vector<PendingOp> m_Pending;
		bool m_Applying = false;

		std::thread m_UpdateThread;
		std::exception_ptr m_UpdateError;
		std::atomic<bool> m_Running{ false };
		std::atomic<bool> m_LoopsActive{ false };
		std::atomic<int> m_ExitCode{ 0 };
		bool m_PlatformReady = false;
		bool m_Started = false;

		static Application* s_Instance;
		static std::vector<std::string> s_Args;
	};
}
