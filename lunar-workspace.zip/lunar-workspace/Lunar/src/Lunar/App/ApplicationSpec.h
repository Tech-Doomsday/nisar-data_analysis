#pragma once
#include <cstdint>
#include <string>

namespace lunar
{
	enum class ThreadingMode
	{
		Split,    // update thread fills frame slots, the main thread renders them (what Lunar's Scene is built for)
		Single,   // update + render alternate on the main thread (easier to debug, same Scene ring)
	};

	// Everything the engine needs to know before the window exists.
	// Fields are in this order so designated initializers work:
	//     Application({ .title = "My game", .width = 1600, .height = 900 })
	struct ApplicationSpec
	{
		std::string title = "Lunar";
		uint32_t width = 1280;
		uint32_t height = 720;
		bool vsync = true;
		bool resizable = true;
		bool fullscreen = false;

		int glMajor = 4;
		int glMinor = 6;
		int samples = 0;                 // MSAA samples of the default framebuffer
#ifdef NDEBUG
		bool debugContext = false;       // GL debug output (KHR_debug) -> log
#else
		bool debugContext = true;
#endif
		bool breakOnGLError = false;     // __debugbreak() on a high-severity GL debug message

		ThreadingMode threading = ThreadingMode::Split;

		float maxDelta = 0.05f;          // dt clamp (seconds) for both loops, 0 = no clamp
		double updateHz = 60.0;          // update rate when no FrameGate is set (a gate paces the loop itself)
		double fpsInterval = 0.5;        // RenderContext::fps refresh period (seconds)
	};
}
