#pragma once
#include <exception>

#include "../Utils/Log.h"
#include "Application.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Entry point  (replaces LENZ_MAIN)
//
//      LUNAR_MAIN(MyApp)
//
//  Same one-liner as Lenz, but:
//    * no `extern Window* GetAppWindow()` to define: the window comes from the
//      ApplicationSpec the application passes to its base constructor
//    * argc / argv reach the app (Application::GetArgs())
//    * an exception is logged and becomes a non-zero exit code; the Application
//      has already been destroyed (GL cleaned up) when the handler runs
//    * the real work is lunar::Launch<App>(), a function you can call yourself
//      (from a test, from your own main, from WinMain)
//
//  Define LUNAR_DISABLE_ENTRYPOINT to write main() yourself.
//  To change logging, call lunar::Log::Init(config) from the application's constructor.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	template<class App>
	int Launch(int argc = 0, char** argv = nullptr)
	{
		Application::SetCommandLine(argc, argv);
		try
		{
			App app;
			return app.Run();
		}
		catch (const std::exception& e)
		{
			LN_FATAL("Unhandled exception: " << e.what());
		}
		catch (...)
		{
			LN_FATAL("Unhandled non-standard exception");
		}
		return -1;
	}
}

#ifndef LUNAR_DISABLE_ENTRYPOINT
	#define LUNAR_MAIN(AppClass) \
		int main(int argc, char** argv) { return ::lunar::Launch<AppClass>(argc, argv); }
#else
	#define LUNAR_MAIN(AppClass)
#endif
