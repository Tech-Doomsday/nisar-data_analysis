#pragma once

// ─────────────────────────────────────────────────────────────────────────────
//  FrameGate
//
//  The seam between the application loops and the Scene's frame ring.
//
//  Lunar's Scene hands out frame slots: the update side asks for a free one
//  (UpdateStart) and publishes it (UpdateEnd); the render side asks for a written
//  one (RenderStart), draws, fences and gives it back (RenderFence + RenderEnd).
//  Which Scene<IVB, ISB> a game uses is a template argument, so the Application
//  cannot know it. A gate wraps it behind four calls (see Impl/SceneGate.h) and
//  the loops do the waiting / back-off.
//
//  Calls come from two threads:
//    AcquireUpdate / ReleaseUpdate  ... the update thread (the main thread in ThreadingMode::Single)
//    AcquireRender / ReleaseRender  ... the main thread
//
//  Without a gate the loops simply run: update at ApplicationSpec::updateHz,
//  render once per vsync.
//
//  Optional: WaitUpdate() / Interrupt(). A gate that can block the update thread
//  until a slot is free (SceneGate does, via Scene::WaitForUpdateSlot) saves the
//  CPU the polling back-off would burn while the ring is full (the normal case
//  whenever the simulation is faster than vsync, or the window is minimised).
//  Gates that do not override them keep working with the polling back-off.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	class FrameGate
	{
	public:
		virtual ~FrameGate() = default;

		// false: no free slot right now (the GPU / renderer still owns all of them), try again later
		virtual bool AcquireUpdate() = 0;
		virtual void ReleaseUpdate() = 0;     // publish the slot

		// false: nothing new to draw
		virtual bool AcquireRender() = 0;
		virtual void ReleaseRender() = 0;     // called AFTER the buffer swap: fence + hand the slot back

		// Update thread, called after AcquireUpdate() returned false. Blocks until AcquireUpdate() can succeed or
		// Interrupt() was called, then returns true. Returns false at once if the gate cannot block (default):
		// the application then falls back to polling with a back-off.
		virtual bool WaitUpdate() { return false; }

		// Any thread. Wakes a blocked WaitUpdate() and makes it return immediately from now on. Called while the
		// application stops, before it joins the update thread.
		virtual void Interrupt() {}
	};
}
