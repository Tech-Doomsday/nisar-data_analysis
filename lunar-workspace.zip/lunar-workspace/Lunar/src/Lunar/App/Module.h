#pragma once
#include <cassert>
#include <cstdint>
#include <string>
#include <string_view>
#include <utility>

#include "../Event/EventBus.h"
#include "../Input/Input.h"
#include "FrameGate.h"
#include "Window.h"

namespace lunar
{
	class Application;

	// Handed to Module::OnUpdate (update thread).
	struct UpdateContext
	{
		float dt;                       // seconds since the previous tick, clamped to ApplicationSpec::maxDelta
		double time;                    // accumulated update time
		uint64_t tick;
		const Input& input;             // this tick's input snapshot
		WindowMetrics window;           // for cursor -> framebuffer mapping
		FrameGate* gate;                // may be null
	};

	// Handed to Module::OnRender (main thread).
	struct RenderContext
	{
		float dt;                       // seconds since the previous frame
		double time;
		uint64_t frame;
		double fps;                     // refreshed every ApplicationSpec::fpsInterval
		WindowMetrics window;
		FrameGate* gate;
	};

	// ─────────────────────────────────────────────────────────────────────────
	//  Module  (Lenz::Module, with the missing pieces)
	//
	//    OnMount     main thread, GL context current        build GPU resources here
	//    OnUnmount   main thread, GL context still alive    release them here (or in the destructor)
	//    OnUpdate    update thread (main in Single mode)    NO GL calls
	//    OnRender    main thread                            GL calls
	//
	//  Priority decides ORDER, one rule for everything:
	//    events and updates:  higher priority first   (a UI layer sees the click before the game)
	//    rendering:           lower priority first    (the overlay draws on top)
	//    unmounting:          higher priority first   (what depends on the game goes first)
	//  Equal priorities keep mount order.
	//
	//  Events: `Listen<E>(handler)` in OnMount. Handlers run at the module's priority,
	//  `return true` consumes the event. They are removed automatically on unmount.
	// ─────────────────────────────────────────────────────────────────────────
	class Module
	{
	public:
		explicit Module(std::string_view name = "Module", int priority = 0) : m_Name(name), m_Priority(priority) {}
		virtual ~Module() = default;
		Module(const Module&) = delete;
		Module& operator=(const Module&) = delete;

		virtual void OnMount() {}
		virtual void OnUnmount() {}
		virtual void OnUpdate(const UpdateContext&) {}
		virtual void OnRender(const RenderContext&) {}

		std::string_view GetName() const { return m_Name; }
		int GetPriority() const { return m_Priority; }

	protected:
		Application& App() const { assert(m_App && "module is not mounted"); return *m_App; }
		EventBus& Events() const { assert(m_Bus && "module is not mounted"); return *m_Bus; }

		template<EventType E, class Fn>
		void Listen(Fn&& fn)
		{
			assert(m_Bus && "Listen<E>() is only valid from OnMount() onwards");
			m_Subs.Add(m_Bus->On<E>(std::forward<Fn>(fn), m_Priority));
		}

	private:
		friend class Application;

		void Attach(Application& app, EventBus& bus) { m_App = &app; m_Bus = &bus; }
		void Detach() { m_Subs.Clear(); m_App = nullptr; m_Bus = nullptr; }

		std::string m_Name;
		int m_Priority;
		Application* m_App = nullptr;
		EventBus* m_Bus = nullptr;
		SubscriptionList m_Subs;
	};
}
