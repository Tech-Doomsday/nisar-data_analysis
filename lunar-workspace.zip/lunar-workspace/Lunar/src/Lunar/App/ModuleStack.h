#pragma once
#include <algorithm>
#include <memory>
#include <vector>

#include "Module.h"

namespace lunar
{
	// Modules sorted by priority, highest first, mount order among equals.
	// Not thread-safe by itself: the Application serialises access (see Application::ApplyPendingModules).
	class ModuleStack
	{
		using Storage = std::vector<std::unique_ptr<Module>>;

	public:
		void Insert(std::unique_ptr<Module> m)
		{
			auto it = std::upper_bound(m_Modules.begin(), m_Modules.end(), m->GetPriority(),
				[](int p, const std::unique_ptr<Module>& x) { return p > x->GetPriority(); });
			m_Modules.insert(it, std::move(m));
		}

		std::unique_ptr<Module> Extract(const Module* m)
		{
			for (auto it = m_Modules.begin(); it != m_Modules.end(); ++it)
				if (it->get() == m)
				{
					std::unique_ptr<Module> out = std::move(*it);
					m_Modules.erase(it);
					return out;
				}
			return nullptr;
		}

		// highest priority first; null when empty
		std::unique_ptr<Module> ExtractFirst()
		{
			if (m_Modules.empty()) return nullptr;
			std::unique_ptr<Module> out = std::move(m_Modules.front());
			m_Modules.erase(m_Modules.begin());
			return out;
		}

		template<class T>
		T* Find() const
		{
			for (const auto& m : m_Modules)
				if (T* t = dynamic_cast<T*>(m.get())) return t;
			return nullptr;
		}

		bool Contains(const Module* m) const
		{
			return std::any_of(m_Modules.begin(), m_Modules.end(), [m](const auto& x) { return x.get() == m; });
		}

		bool Empty() const { return m_Modules.empty(); }
		size_t Count() const { return m_Modules.size(); }

		// descending priority (events, update)
		Storage::const_iterator begin() const { return m_Modules.begin(); }
		Storage::const_iterator end() const { return m_Modules.end(); }
		// ascending priority (render)
		Storage::const_reverse_iterator rbegin() const { return m_Modules.rbegin(); }
		Storage::const_reverse_iterator rend() const { return m_Modules.rend(); }

	private:
		Storage m_Modules;
	};
}
