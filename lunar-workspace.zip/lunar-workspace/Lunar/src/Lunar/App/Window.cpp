#include "Window.h"
#include "../Utils/Log.h"

namespace lunar
{
	namespace
	{
		void GLFWErrorCallback(int code, const char* description)
		{
			LN_ERROR("GLFW error " << code << ": " << (description ? description : "(null)"));
		}

		void GLAPIENTRY GLDebugCallback(GLenum, GLenum type, GLuint id, GLenum severity, GLsizei, const GLchar* message, const void* user)
		{
			const bool isError = (type == GL_DEBUG_TYPE_ERROR);
			switch (severity)
			{
			case GL_DEBUG_SEVERITY_HIGH:
				LN_ERROR("[GL] " << message << " (id " << id << ")");
				if (user && static_cast<const Window*>(user)->WantsDebugBreak()) LN_DEBUGBREAK();
				break;
			case GL_DEBUG_SEVERITY_MEDIUM:
				if (isError) LN_ERROR("[GL] " << message); else LN_WARN("[GL] " << message);
				break;
			default:
				LN_INFO("[GL] " << message);
				break;
			}
		}

		void EnableGLDebugOutput(const Window* window)
		{
			GLint flags = 0;
			glGetIntegerv(GL_CONTEXT_FLAGS, &flags);
			if (!(flags & GL_CONTEXT_FLAG_DEBUG_BIT))
			{
				LN_WARN("GL debug output requested, but the driver gave no debug context");
				return;
			}
			glEnable(GL_DEBUG_OUTPUT);
			glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
			glDebugMessageCallback(GLDebugCallback, window);
			glDebugMessageControl(GL_DONT_CARE, GL_DONT_CARE, GL_DEBUG_SEVERITY_NOTIFICATION, 0, nullptr, GL_FALSE);
		}
	}


	// GLFW callbacks. A struct (not lambdas in a function) so Window can befriend it.
	struct WindowCallbacks
	{
		static Window* Self(GLFWwindow* w) { return static_cast<Window*>(glfwGetWindowUserPointer(w)); }

		static void OnClose(GLFWwindow* w) { Self(w)->Emit(events::WindowClosed{}); }

		static void OnSize(GLFWwindow* w, int width, int height)
		{
			Window* s = Self(w);
			s->m_Size.store(Window::Pack(uint32_t(width), uint32_t(height)));
			s->Emit(events::WindowResized{ uint32_t(width), uint32_t(height) });
		}

		static void OnFramebuffer(GLFWwindow* w, int width, int height)
		{
			Window* s = Self(w);
			s->m_FbSize.store(Window::Pack(uint32_t(width), uint32_t(height)));
			s->Emit(events::FramebufferResized{ uint32_t(width), uint32_t(height) });
		}

		static void OnPos(GLFWwindow* w, int x, int y) { Self(w)->Emit(events::WindowMoved{ x, y }); }

		static void OnFocus(GLFWwindow* w, int focused)
		{
			Window* s = Self(w);
			s->m_Focused = focused != 0;
			s->m_HaveCursor = false;                 // the cursor may have moved while we were not looking
			s->Emit(events::WindowFocus{ focused != 0 });
		}

		static void OnIconify(GLFWwindow* w, int iconified)
		{
			Window* s = Self(w);
			s->m_Iconified = iconified != 0;
			s->Emit(events::WindowIconified{ iconified != 0 });
		}

		static void OnKey(GLFWwindow* w, int key, int scancode, int action, int mods)
		{
			if (key < 0) return;                     // GLFW_KEY_UNKNOWN
			Window* s = Self(w);
			const Key k = static_cast<lunar::Key>(key);
			switch (action)
			{
			case GLFW_PRESS:   s->Emit(events::KeyPressed{ k, scancode, mods, false }); break;
			case GLFW_REPEAT:  s->Emit(events::KeyPressed{ k, scancode, mods, true }); break;
			case GLFW_RELEASE: s->Emit(events::KeyReleased{ k, scancode, mods }); break;
			default: break;
			}
		}

		static void OnChar(GLFWwindow* w, unsigned int cp) { Self(w)->Emit(events::KeyTyped{ cp }); }

		static void OnMouseButton(GLFWwindow* w, int button, int action, int mods)
		{
			if (button < 0 || button >= int(MouseButtonCount)) return;
			Window* s = Self(w);
			const MouseButton b = static_cast<MouseButton>(button);
			if (action == GLFW_PRESS) s->Emit(events::MouseButtonPressed{ b, mods });
			else if (action == GLFW_RELEASE) s->Emit(events::MouseButtonReleased{ b, mods });
		}

		static void OnCursor(GLFWwindow* w, double x, double y)
		{
			Window* s = Self(w);
			const double dx = s->m_HaveCursor ? x - s->m_LastX : 0.0;
			const double dy = s->m_HaveCursor ? y - s->m_LastY : 0.0;
			s->m_HaveCursor = true;
			s->m_LastX = x;
			s->m_LastY = y;
			s->Emit(events::MouseMoved{ x, y, dx, dy });
		}

		static void OnScroll(GLFWwindow* w, double x, double y) { Self(w)->Emit(events::MouseScrolled{ x, y }); }
	};


	bool Window::Create(const ApplicationSpec& spec)
	{
		if (m_Handle)
		{
			LN_ERROR("Window::Create: already created");
			return false;
		}

		glfwSetErrorCallback(GLFWErrorCallback);     // legal before glfwInit; Core never sets one

		if (!Core::Init(spec.glMajor, spec.glMinor))   // glfwInit + version / core-profile hints
		{
			LN_FATAL("Could not initialise GLFW");
			return false;
		}

		glfwWindowHint(GLFW_RESIZABLE, spec.resizable ? GLFW_TRUE : GLFW_FALSE);
		glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT, spec.debugContext ? GLFW_TRUE : GLFW_FALSE);
		glfwWindowHint(GLFW_SAMPLES, spec.samples);

		if (!Core::CreateWindow(int(spec.width), int(spec.height), spec.title) || !(m_Handle = Core::GetWindow()))
		{
			LN_FATAL("Could not create a window with an OpenGL " << spec.glMajor << "." << spec.glMinor << " core context");
			return false;
		}

		m_BreakOnGLError = spec.breakOnGLError;
		glfwSetWindowUserPointer(m_Handle, this);

		if (!Core::MakeContextCurrent(m_Handle))     // also glewInit
		{
			LN_FATAL("Could not make the OpenGL context current / load the GL entry points");
			Destroy();
			return false;
		}

		SetVSync(spec.vsync);
		if (spec.debugContext) EnableGLDebugOutput(this);

		InstallCallbacks();
		RefreshSizes();
		glfwGetWindowPos(m_Handle, &m_WindowedX, &m_WindowedY);
		m_WindowedW = int(spec.width);
		m_WindowedH = int(spec.height);

		double cx = 0, cy = 0;
		glfwGetCursorPos(m_Handle, &cx, &cy);
		m_LastX = cx; m_LastY = cy; m_HaveCursor = true;

		LN_INFO("OpenGL " << reinterpret_cast<const char*>(glGetString(GL_VERSION))
			<< " | " << reinterpret_cast<const char*>(glGetString(GL_RENDERER))
			<< " | GLSL " << reinterpret_cast<const char*>(glGetString(GL_SHADING_LANGUAGE_VERSION)));

		if (spec.fullscreen) SetFullscreen(true);
		return true;
	}

	void Window::Destroy()
	{
		if (!m_Handle) return;
		m_Handle = nullptr;
		m_Callback = nullptr;
		Core::Terminate();                           // destroys the window and glfwTerminate
	}

	void Window::InstallCallbacks()
	{
		glfwSetWindowCloseCallback(m_Handle, WindowCallbacks::OnClose);
		glfwSetWindowSizeCallback(m_Handle, WindowCallbacks::OnSize);
		glfwSetFramebufferSizeCallback(m_Handle, WindowCallbacks::OnFramebuffer);
		glfwSetWindowPosCallback(m_Handle, WindowCallbacks::OnPos);
		glfwSetWindowFocusCallback(m_Handle, WindowCallbacks::OnFocus);
		glfwSetWindowIconifyCallback(m_Handle, WindowCallbacks::OnIconify);
		glfwSetKeyCallback(m_Handle, WindowCallbacks::OnKey);
		glfwSetCharCallback(m_Handle, WindowCallbacks::OnChar);
		glfwSetMouseButtonCallback(m_Handle, WindowCallbacks::OnMouseButton);
		glfwSetCursorPosCallback(m_Handle, WindowCallbacks::OnCursor);
		glfwSetScrollCallback(m_Handle, WindowCallbacks::OnScroll);
	}

	void Window::RefreshSizes()
	{
		int w = 0, h = 0, fw = 0, fh = 0;
		float sx = 1.0f, sy = 1.0f;
		glfwGetWindowSize(m_Handle, &w, &h);
		glfwGetFramebufferSize(m_Handle, &fw, &fh);
		glfwGetWindowContentScale(m_Handle, &sx, &sy);
		m_Size.store(Pack(uint32_t(w), uint32_t(h)));
		m_FbSize.store(Pack(uint32_t(fw), uint32_t(fh)));
		m_ScaleX.store(sx);
		m_ScaleY.store(sy);
		m_Iconified = glfwGetWindowAttrib(m_Handle, GLFW_ICONIFIED) != 0;
		m_Focused = glfwGetWindowAttrib(m_Handle, GLFW_FOCUSED) != 0;
	}

	void Window::PollEvents() { glfwPollEvents(); }
	void Window::WaitEvents(double timeoutSeconds) { glfwWaitEventsTimeout(timeoutSeconds); }
	void Window::WakeUp() { glfwPostEmptyEvent(); }

	void Window::SwapBuffers() { if (m_Handle) glfwSwapBuffers(m_Handle); }

	void Window::SetVSync(bool enable)
	{
		m_VSync = enable;
		glfwSwapInterval(enable ? 1 : 0);
	}

	void Window::SetTitle(const std::string& title) { if (m_Handle) glfwSetWindowTitle(m_Handle, title.c_str()); }

	void Window::SetFullscreen(bool fullscreen)
	{
		if (!m_Handle || fullscreen == m_Fullscreen) return;

		if (fullscreen)
		{
			glfwGetWindowPos(m_Handle, &m_WindowedX, &m_WindowedY);
			glfwGetWindowSize(m_Handle, &m_WindowedW, &m_WindowedH);
			GLFWmonitor* monitor = glfwGetPrimaryMonitor();
			const GLFWvidmode* mode = monitor ? glfwGetVideoMode(monitor) : nullptr;
			if (!mode) return;
			glfwSetWindowMonitor(m_Handle, monitor, 0, 0, mode->width, mode->height, mode->refreshRate);
		}
		else
		{
			glfwSetWindowMonitor(m_Handle, nullptr, m_WindowedX, m_WindowedY, m_WindowedW, m_WindowedH, 0);
		}
		m_Fullscreen = fullscreen;
		SetVSync(m_VSync);                           // the swap interval is reset by a mode switch on some drivers
	}

	bool Window::ShouldClose() const { return m_Handle && glfwWindowShouldClose(m_Handle); }
	void Window::RequestClose() { if (m_Handle) glfwSetWindowShouldClose(m_Handle, GLFW_TRUE); }
	void Window::CancelClose() { if (m_Handle) glfwSetWindowShouldClose(m_Handle, GLFW_FALSE); }

	WindowMetrics Window::Metrics() const
	{
		WindowMetrics m;
		const uint64_t s = m_Size.load(std::memory_order_relaxed);
		const uint64_t f = m_FbSize.load(std::memory_order_relaxed);
		m.width = uint32_t(s >> 32);
		m.height = uint32_t(s);
		m.fbWidth = uint32_t(f >> 32);
		m.fbHeight = uint32_t(f);
		m.scaleX = m_ScaleX.load(std::memory_order_relaxed);
		m.scaleY = m_ScaleY.load(std::memory_order_relaxed);
		return m;
	}
}
