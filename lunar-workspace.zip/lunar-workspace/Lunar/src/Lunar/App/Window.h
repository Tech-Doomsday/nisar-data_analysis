#pragma once
#include <atomic>
#include <cstdint>
#include <functional>

#include "../Core/Core.h"
#include "../Event/Events.h"
#include "ApplicationSpec.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Window  -  thin layer over lunar::Core (GLFW window + GL context)
//
//  Core stays as it is; Window creates the window through it, adds what Core
//  does not do (hints, error callback, GL debug output, swap interval) and turns
//  GLFW callbacks into events::Event. It replaces Lenz::Window + the callback
//  half of Lenz::RendererCommands.
//
//  Nothing global: the callbacks find their Window through glfwSetWindowUserPointer.
//
//  Main thread only, except Metrics() (any thread).
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	// Window sizes as seen by any thread (the update thread needs them to map the cursor).
	struct WindowMetrics
	{
		uint32_t width = 0, height = 0;            // screen coordinates
		uint32_t fbWidth = 0, fbHeight = 0;        // pixels
		float scaleX = 1.0f, scaleY = 1.0f;        // content scale (DPI)

		// Cursor position (window coords, y down) -> framebuffer pixels, y up.
		glm::dvec2 CursorToFramebuffer(double cx, double cy) const
		{
			const double sx = width > 0 ? double(fbWidth) / width : 1.0;
			const double sy = height > 0 ? double(fbHeight) / height : 1.0;
			return { cx * sx, double(fbHeight) - cy * sy };
		}
		glm::dvec2 CursorToFramebuffer(glm::dvec2 c) const { return CursorToFramebuffer(c.x, c.y); }
	};

	class Window
	{
	public:
		using EventCallback = std::function<void(const events::Event&)>;

		Window() = default;
		~Window() { Destroy(); }
		Window(const Window&) = delete;
		Window& operator=(const Window&) = delete;

		void SetEventCallback(EventCallback cb) { m_Callback = std::move(cb); }

		// Core::Init + window + context + GLEW + callbacks. False (and logged) on failure.
		bool Create(const ApplicationSpec& spec);
		// Core::Terminate. After this no GL call is legal.
		void Destroy();
		bool IsCreated() const { return m_Handle != nullptr; }

		GLFWwindow* GetHandle() const { return m_Handle; }
		operator GLFWwindow* () const { return m_Handle; }

		void PollEvents();
		void WaitEvents(double timeoutSeconds);
		static void WakeUp();                              // any thread: makes WaitEvents return

		void SwapBuffers();
		void SetVSync(bool enable);
		bool IsVSync() const { return m_VSync; }
		void SetTitle(const std::string& title);
		void SetFullscreen(bool fullscreen);
		bool IsFullscreen() const { return m_Fullscreen; }

		bool ShouldClose() const;
		void RequestClose();
		void CancelClose();

		bool IsMinimized() const { return m_Iconified || m_FbWidth() == 0 || m_FbHeight() == 0; }
		bool IsFocused() const { return m_Focused; }

		// any thread
		WindowMetrics Metrics() const;

		uint32_t GetWidth() const { return static_cast<uint32_t>(m_Size.load(std::memory_order_relaxed) >> 32); }
		uint32_t GetHeight() const { return static_cast<uint32_t>(m_Size.load(std::memory_order_relaxed)); }
		uint32_t GetFramebufferWidth() const { return m_FbWidth(); }
		uint32_t GetFramebufferHeight() const { return m_FbHeight(); }

		bool WantsDebugBreak() const { return m_BreakOnGLError; }

	private:
		friend struct WindowCallbacks;

		void InstallCallbacks();
		void RefreshSizes();
		void Emit(const events::Event& e) { if (m_Callback) m_Callback(e); }

		static uint64_t Pack(uint32_t hi, uint32_t lo) { return (uint64_t(hi) << 32) | lo; }
		uint32_t m_FbWidth() const { return static_cast<uint32_t>(m_FbSize.load(std::memory_order_relaxed) >> 32); }
		uint32_t m_FbHeight() const { return static_cast<uint32_t>(m_FbSize.load(std::memory_order_relaxed)); }

		GLFWwindow* m_Handle = nullptr;
		EventCallback m_Callback;

		std::atomic<uint64_t> m_Size{ 0 };       // window size, width << 32 | height
		std::atomic<uint64_t> m_FbSize{ 0 };     // framebuffer size
		std::atomic<float> m_ScaleX{ 1.0f }, m_ScaleY{ 1.0f };

		bool m_VSync = true;
		bool m_Fullscreen = false;
		bool m_Iconified = false;
		bool m_Focused = true;
		bool m_BreakOnGLError = false;

		bool m_HaveCursor = false;               // false: the next cursor event has delta 0
		double m_LastX = 0.0, m_LastY = 0.0;

		int m_WindowedX = 100, m_WindowedY = 100, m_WindowedW = 1280, m_WindowedH = 720;
	};
}
