#include"Buffer.h"



namespace lunar
{

    Buffer::Buffer()
    {

    }

    Buffer::~Buffer()
    {
        Destroy();
    }

    Buffer::Buffer(Buffer&& other) noexcept
    {
        *this = std::move(other);
    }

    Buffer& Buffer::operator=(Buffer&& other) noexcept
    {
        if (this == &other) return *this;
        Destroy();
        m_RendererID = other.m_RendererID;
        m_Type = other.m_Type;
        m_Size = other.m_Size;
        m_StorageUsageChache = other.m_StorageUsageChache;
        m_BufferUsageChache = other.m_BufferUsageChache;
        m_BindingPoint = other.m_BindingPoint;
        m_IsStorage = other.m_IsStorage;
        other.m_RendererID = -1;
        other.m_Size = 0;
        return *this;
    }


    void Buffer::DataInit(BufferType type, BufferHint usage, void* data, size_t size)
    {
        Destroy();

        m_IsStorage = false;
        m_BufferUsageChache = usage;

        m_Type = type;
        m_Size = size;

        // DSA creation: does not touch any global binding (the old glBindBuffer on
        // ELEMENT_ARRAY_BUFFER silently changed whatever VAO happened to be bound)
        glCreateBuffers(1, &m_RendererID);
        glNamedBufferData(m_RendererID, size, data, (GLenum)usage);

        GL_CHECK_ERROR();
    }




    void Buffer::StorageInit(BufferType type, StorageHints usage, void* data, size_t size)
    {
        Destroy();

        m_IsStorage = true;
        m_StorageUsageChache = usage;
        m_Size = size;
        m_Type = type;
        glCreateBuffers(1, &m_RendererID);
        glNamedBufferStorage(m_RendererID, size, data, (GLbitfield)usage);

        GL_CHECK_ERROR();
    }

    // The target used for the indexed binding is the one the caller asks for (hint). It used to use
    // the buffer's own type and ignore the hint, so e.g. an ArrayBuffer could never be bound as an SSBO.
    void Buffer::BindBase(unsigned int bindingPoint, BufferType hint)
    {
        if (!_IsIndexedBindable(hint))
        {
            LUNAR_ERROR("Buffer type cannot be used with glBindBufferBase");
            return;
        }

        m_BindingPoint = bindingPoint;
        glBindBufferBase((GLenum)hint, bindingPoint, m_RendererID);
    }

    void Buffer::BindRange(unsigned int bindingPoint, size_t offset, size_t size, BufferType hint)
    {
        if (!_IsIndexedBindable(hint))
        {
            LUNAR_ERROR("Buffer type cannot be used with glBindBufferRange");
            return;
        }

        m_BindingPoint = bindingPoint;
        glBindBufferRange((GLenum)hint, bindingPoint, m_RendererID, offset, size);
    }

    void Buffer::BindOwnBase(BufferType hint)
    {
        if (!_IsIndexedBindable(hint))
        {
            LUNAR_ERROR("Buffer type cannot be used with glBindBufferBase");
            return;
        }
        if (m_BindingPoint != (unsigned int)-1)
        {
            glBindBufferBase((GLenum)hint, m_BindingPoint, m_RendererID);
        }
        else
        {
            LUNAR_ERROR("StorageBuffer::BindOwnBase: Binding point not set. Use BindBase() or BindRange() first.");
        }
    }








    void Buffer::Destroy()
    {
        // the id is cleared: GL may hand the same name to a new buffer, deleting it twice
        // (Destroy() followed by the destructor) would destroy somebody else's buffer
        if (m_RendererID != (unsigned int)-1)
        {
            glDeleteBuffers(1, &m_RendererID);
            m_RendererID = -1;
        }
    }

    void Buffer::Bind()
    {
        glBindBuffer((GLenum)m_Type, m_RendererID);
    }



    void Buffer::Unbind()
    {
        glBindBuffer((GLenum)m_Type, 0);
    }

    void Buffer::Write(void* data, size_t offset, size_t size)
    {
        if (m_RendererID == (unsigned int)-1)
        {
            LUNAR_ERROR("Buffer::Write: buffer is not initialised.");
            return;
        }

        if (size == -1) size = m_Size - offset;

        if (offset + size > m_Size)
        {
            LUNAR_ERROR("Buffer::Write: Attempting to write beyond buffer size.");
            return;
        }

        if (m_IsStorage && !(m_StorageUsageChache & StorageHints::DynamicStorage))
        {
            LUNAR_ERROR("Buffer::Write: immutable storage was created without DynamicStorage, use mapping instead.");
            return;
        }

        glNamedBufferSubData(m_RendererID, offset, size, data);
    }

    void Buffer::DataReallocate(size_t newSize)
    {
        if (m_IsStorage)
        {
            LUNAR_ERROR("Buffer::DataReallocate: immutable storage cannot be reallocated.");
            return;
        }
        m_Size = newSize;
        glNamedBufferData(m_RendererID, newSize, nullptr, GL_DYNAMIC_DRAW);

    }


    void* Buffer::GetMappedPointer(StorageHints flags, size_t offset, size_t size)
    {
        if (size == -1) size = m_Size - offset;
        return glMapNamedBufferRange(m_RendererID, offset, size, (GLbitfield)flags);
    }

    void Buffer::UnMap()
    {
        glUnmapNamedBuffer(m_RendererID);
    }


    // glFlushMappedBufferRange's first argument is a *target*; the buffer name was being passed there
    // (GL_INVALID_ENUM, nothing flushed). The DSA variant takes the buffer name.
    void Buffer::Flush(size_t offset, size_t size)
    {
        glFlushMappedNamedBufferRange(m_RendererID, offset, size);
    }

    void Buffer::FlushAll()
    {
        glFlushMappedNamedBufferRange(m_RendererID, 0, m_Size);
    }



    VertexBuffer::VertexBuffer()
    {

    }

    void VertexBuffer::DataInit(BufferHint usage, void* data, size_t size)
    {
        Buffer::DataInit(BufferType::ArrayBuffer, usage, data, size);
    }

    void VertexBuffer::StorageInit(StorageHints usage, void* data, size_t size)
    {
        Buffer::StorageInit(BufferType::ArrayBuffer, usage, data, size);
    }



    void VertexBuffer::AddElement(unsigned int location, unsigned int count, unsigned int type, unsigned int size)
    {
        // forwards so the layout size is accumulated too (this overload used to skip it)
        AddElement(VertexBufferElement{ location, count, type, size });
    }

    void VertexBuffer::AddElement(const VertexBufferElement& element)
    {
        m_LayoutSize += element.size;
        m_Elements.push_back(element);
    }

    void VertexBuffer::SetLayout(const std::vector<VertexBufferElement>& layout, size_t totalSize)
    {
        m_LayoutSize = 0;

        if (totalSize == -1)
        {
            for (const VertexBufferElement& element : layout)
            {
                m_LayoutSize += element.size;
            }
        }

        else
        {
            m_LayoutSize = totalSize;
        }


        m_Elements = layout;
    }

    void VertexBuffer::PushLayout(const std::vector<VertexBufferElement>& layout)
    {
        for (const VertexBufferElement& element : layout)
        {
            m_LayoutSize += element.size;
            m_Elements.push_back(element);
        }
    }


    void VertexBuffer::RemoveAllElements()
    {
        m_Elements.clear();
        m_LayoutSize = 0;
    }



    void IndexBuffer::Init(BufferHint usage, void* data, size_t size)
    {
        m_Usage = usage;
        Buffer::DataInit(BufferType::ElementBuffer, usage, data, size);
    }






    ArrayObject::ArrayObject()
    {
    }

    ArrayObject::~ArrayObject()
    {
        Destroy();
    }

    ArrayObject::ArrayObject(ArrayObject&& other) noexcept
    {
        *this = std::move(other);
    }

    ArrayObject& ArrayObject::operator=(ArrayObject&& other) noexcept
    {
        if (this == &other) return *this;
        Destroy();
        m_VertexBuffers = std::move(other.m_VertexBuffers);
        m_IndexBuffer = other.m_IndexBuffer;
        m_RendererID = other.m_RendererID;
        other.m_IndexBuffer = nullptr;
        other.m_RendererID = -1;
        other.m_VertexBuffers.clear();
        return *this;
    }


    void ArrayObject::Init()
    {
        glCreateVertexArrays(1, &m_RendererID);
        GL_CHECK_ERROR();

        Bind();
    }

    void ArrayObject::Bind() const
    {
        glBindVertexArray(m_RendererID);
    }

    void ArrayObject::Unbind() const
    {
        glBindVertexArray(0);
    }

    void ArrayObject::Destroy()
    {
        m_VertexBuffers.clear();
        if (m_RendererID != (unsigned int)-1)
        {
            glDeleteVertexArrays(1, &m_RendererID);
            m_RendererID = -1;
        }
    }



    void ArrayObject::AddVertexBuffer(const VertexBuffer* element, size_t offset, size_t size, bool SoA)
    {
        if (!element)
        {
            LUNAR_ERROR("ArrayObject::AddVertexBuffer: null buffer");
            return;
        }
        m_VertexBuffers.emplace_back(element, offset, size == -1 ? element->GetSize() : size, SoA);
    }


    void ArrayObject::AddIndexBuffer(const Buffer* element)
    {
        if (element && element->GetType() != BufferType::ElementBuffer)
        {
            LUNAR_ERROR("ArrayObject::AddIndexBuffer: buffer is not an index buffer");
            return;
        }
        m_IndexBuffer = (IndexBuffer*)element;
    }


    static void _SetAttribFormat(unsigned int vao, const VertexBufferElement& element, unsigned int relativeOffset)
    {
        if (element.asInteger)
            glVertexArrayAttribIFormat(vao, element.location, element.count, element.type, relativeOffset);
        else
            glVertexArrayAttribFormat(vao, element.location, element.count, element.type, element.normalized ? GL_TRUE : GL_FALSE, relativeOffset);
    }

    void ArrayObject::Compile()
    {
        Bind();

        size_t offset = 0;
        size_t bufferNo = 0;


        for (const auto& bufferSegment : m_VertexBuffers)
        {
            if (bufferSegment.buffer->GetLayoutSize() == 0)
            {
                LUNAR_ERROR("ArrayObject::Compile: vertex buffer has no layout");
                continue;
            }

            if (bufferSegment.SoA)
            {
                size_t entityCount = bufferSegment.size / bufferSegment.buffer->GetLayoutSize();

                offset = bufferSegment.offset;

                for (const auto& element : bufferSegment.buffer->GetElements())
                {
                    glVertexArrayVertexBuffer(m_RendererID, bufferNo, bufferSegment.buffer->GetRendererID(), offset, element.size);

                    glEnableVertexArrayAttrib(m_RendererID, element.location);
                    _SetAttribFormat(m_RendererID, element, 0);

                    glVertexArrayAttribBinding(m_RendererID, element.location, bufferNo);

                    glVertexArrayBindingDivisor(m_RendererID, bufferNo, bufferSegment.buffer->GetInstanceDivisor());

                    offset += element.size * entityCount;

                    bufferNo++;


                }
            }

            else
            {
                glVertexArrayVertexBuffer(m_RendererID, bufferNo, bufferSegment.buffer->GetRendererID(), bufferSegment.offset, bufferSegment.buffer->GetLayoutSize());
                offset = 0;

                for (const auto& element : bufferSegment.buffer->GetElements())
                {
                    glEnableVertexArrayAttrib(m_RendererID, element.location);
                    _SetAttribFormat(m_RendererID, element, (unsigned int)offset);

                    glVertexArrayAttribBinding(m_RendererID, element.location, bufferNo);

                    glVertexArrayBindingDivisor(m_RendererID, bufferNo, bufferSegment.buffer->GetInstanceDivisor());

                    offset += element.size;
                }

                bufferNo++;

            }


        }

        if (m_IndexBuffer)
        {
            // DSA: attaches to this VAO without touching the global ELEMENT_ARRAY_BUFFER binding
            glVertexArrayElementBuffer(m_RendererID, m_IndexBuffer->GetRendererID());
        }

        Unbind();
    }

    void ArrayObject::Reset()
    {
        m_VertexBuffers.clear();
        m_IndexBuffer = nullptr;
    }








    void ShaderStorageBuffer::Init(StorageHints usage, void* data, size_t size)
    {
        Buffer::StorageInit(BufferType::ShaderStorage, usage, data, size);
        GL_CHECK_ERROR();
    }






    void UnifromStorageBuffer::Init(StorageHints usage, void* data, size_t size)
    {
        Buffer::StorageInit(BufferType::UniformBuffer, usage, data, size);
        GL_CHECK_ERROR();
    }














}
