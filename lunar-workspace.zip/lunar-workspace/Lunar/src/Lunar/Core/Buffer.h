#pragma once
#include"Core.h"


namespace lunar
{


	enum class BufferType
	{
		ArrayBuffer = GL_ARRAY_BUFFER,                 // Vertex attributes
		ElementBuffer = GL_ELEMENT_ARRAY_BUFFER,         // Index buffer

		UniformBuffer = GL_UNIFORM_BUFFER,               // Uniform Buffer Object (UBO)
		ShaderStorage = GL_SHADER_STORAGE_BUFFER,        // Shader Storage Buffer Object (SSBO)

		CopyReadBuffer = GL_COPY_READ_BUFFER,             // Source for buffer copies
		CopyWriteBuffer = GL_COPY_WRITE_BUFFER,            // Destination for buffer copies

		PixelPackBuffer = GL_PIXEL_PACK_BUFFER,            // Read pixels from GPU
		PixelUnpackBuffer = GL_PIXEL_UNPACK_BUFFER,          // Upload pixels/textures to GPU

		TexutreBuffer = GL_TEXTURE_BUFFER,               // Buffer texture

		TransformFeedbackBuffer = GL_TRANSFORM_FEEDBACK_BUFFER,    // Transform feedback output

		IndirectDrawBuffer = GL_DRAW_INDIRECT_BUFFER,         // Indirect draw commands
		IndirectDispachBuffer = GL_DISPATCH_INDIRECT_BUFFER,     // Indirect compute dispatch commands

		QueryBuffer = GL_QUERY_BUFFER,                 // Query results

		CounterBuffer = GL_ATOMIC_COUNTER_BUFFER         // Atomic counters in shaders
	};



	constexpr bool _IsIndexedBindable(BufferType type)
	{
		switch (type)
		{
		case BufferType::ShaderStorage:
			return true;
		case BufferType::CounterBuffer:
			return true;
		case BufferType::UniformBuffer:
			return true;
		case BufferType::TransformFeedbackBuffer:
			return true;
		default:
			return false;
		}

	}



	enum BufferHint
	{
		StaticDraw = GL_STATIC_DRAW,          // Data will not change often
		DynamicDraw = GL_DYNAMIC_DRAW,         // Data will change frequently
		StreamDraw = GL_STREAM_DRAW,          // Data will change every frame
		StaticRead = GL_STATIC_READ,          // Data will be read by the CPU
		DynamicRead = GL_DYNAMIC_READ,         // Data will be read by the CPU frequently
		StreamRead = GL_STREAM_READ,          // Data will be read by the CPU every frame
		StaticCopy = GL_STATIC_COPY,          // Data will be copied from one buffer to another
		DynamicCopy = GL_DYNAMIC_COPY,         // Data will be copied from one buffer to another frequently
		StreamCopy = GL_STREAM_COPY           // Data will be copied from one buffer to another every frame
	};


	enum StorageHints
	{
		DynamicStorage = GL_DYNAMIC_STORAGE_BIT,
		ReadMap = GL_MAP_READ_BIT, 
		WriteMap = GL_MAP_WRITE_BIT, 
		PresistantMap = GL_MAP_PERSISTENT_BIT,
		CoherentMap = GL_MAP_COHERENT_BIT, 
		ClientStorage = GL_CLIENT_STORAGE_BIT, // hint 
		FlushMap = GL_MAP_FLUSH_EXPLICIT_BIT
	};



	class Buffer
	{
	public:
		Buffer();
		~Buffer();
		Buffer(const Buffer&) = delete;              // copying would make two owners of one GL name
		Buffer& operator=(const Buffer&) = delete;
		Buffer(Buffer&& other) noexcept;
		Buffer& operator=(Buffer&& other) noexcept;

		void Destroy();
		void Bind();
		void Unbind();

		void Write(void* data, size_t offset = 0, size_t size = -1);
		void DataReallocate(size_t newSize);

		void* GetMappedPointer(StorageHints flags, size_t offset = 0, size_t size = -1);
		void UnMap();

		void Flush(size_t offset, size_t size);
		void FlushAll();


		unsigned int GetRendererID() const { return m_RendererID; }
		BufferType GetType() const { return m_Type; }
		size_t GetSize() const { return m_Size; }

		void StorageInit(BufferType type, StorageHints usage, void* data, size_t size);
		void DataInit(BufferType type, BufferHint usage, void* data, size_t size);


		void BindBase(unsigned int bindingPoint, BufferType hint);
		void BindRange(unsigned int bindingPoint, size_t offset, size_t size, BufferType hint);
		void BindOwnBase(BufferType hint);

		void Reallocate(size_t newSize) = delete;

		inline BufferHint GetBufferUsage() const { return m_BufferUsageChache; }
		inline StorageHints GetStorageUsage() const { return m_StorageUsageChache; }
		inline unsigned int GetBindingPoint() const { return m_BindingPoint; }

		inline bool isStorage() const { return m_IsStorage; }


	protected:
		unsigned int m_RendererID = -1;
		BufferType m_Type = BufferType::ArrayBuffer;
		size_t m_Size = 0;
		StorageHints m_StorageUsageChache = (StorageHints)0;
		BufferHint m_BufferUsageChache = BufferHint::StaticDraw;
		unsigned int m_BindingPoint = -1;

		bool m_IsStorage = false;
	};











	

	// _______ PER VERTEX BUFFERS _______

	class VertexBufferElement
	{
	public:
		unsigned int location;		// location in shader
		unsigned int count;
		unsigned int type;			// GL_FLOAT, GL_INT
		unsigned int size;			// size in bytes

		// optional (aggregate init with 4 values still works)
		bool asInteger = false;		// true: glVertexArrayAttribIFormat, the shader input must be an int/uint type
		bool normalized = false;	// true: integer data is normalised to 0..1 / -1..1 for float shader inputs
	};

	class VertexBuffer : public Buffer
	{
	public:
		VertexBuffer();

		void AddElement(unsigned int location, unsigned int count, unsigned int type, unsigned int size);
		void AddElement(const VertexBufferElement& element);
		void SetLayout(const std::vector<VertexBufferElement>& layout, size_t totalSize = -1);
		void SetInstanceDivisor(unsigned int divisor) { m_InstanceDivisor = divisor; }
		void PushLayout(const std::vector<VertexBufferElement>& layout);

		void RemoveAllElements();

		void DataInit(BufferHint usage, void* data, size_t size);
		void StorageInit(StorageHints usage, void* data, size_t size);


		std::vector<VertexBufferElement> GetElements() const { return m_Elements; }
		unsigned int GetInstanceDivisor() const { return m_InstanceDivisor; }
		size_t GetLayoutSize() const { return m_LayoutSize; }
		size_t GetCount() const { return m_LayoutSize ? m_Size / m_LayoutSize : 0; }
	private:
		size_t m_LayoutSize = 0;
		unsigned int m_InstanceDivisor = 0;
		std::vector<VertexBufferElement> m_Elements;  // Maybe in future we won't need it here
	};







	class IndexBuffer : public Buffer
	{
	public:
		void Init(BufferHint usage, void* data, size_t size);

		BufferHint GetUsage() const { return m_Usage; }
		size_t GetCount() const { return m_Size / sizeof(unsigned int); }
	private:
		BufferHint m_Usage = BufferHint::StaticDraw;
	};

	class ArrayObject
	{
		struct VertexBufferSegment
		{
			VertexBufferSegment(const VertexBuffer* buffer, size_t offset, size_t size, bool SoA)
				: buffer(buffer), offset(offset), size(size), SoA(SoA)
			{

			}
			const VertexBuffer* buffer;
			size_t offset;
			size_t size;

			bool SoA = false;
		};

	public:
		ArrayObject();
		~ArrayObject();
		ArrayObject(const ArrayObject&) = delete;
		ArrayObject& operator=(const ArrayObject&) = delete;
		ArrayObject(ArrayObject&& other) noexcept;
		ArrayObject& operator=(ArrayObject&& other) noexcept;

		void Init();

		void Destroy();

		void Reset();

		void Compile(); 

		void AddVertexBuffer(const VertexBuffer* element, size_t offset = 0, size_t size = -1, bool SoA = false);

		void AddIndexBuffer(const Buffer* element);

		void Bind() const;

		void Unbind() const;

		std::vector<VertexBufferSegment> GetVertexBuffers() const { return m_VertexBuffers; }
		IndexBuffer* GetIndexBuffer() const { return m_IndexBuffer; }
		unsigned int GetRendererID() const { return m_RendererID; }
	private:
		
		std::vector<VertexBufferSegment> m_VertexBuffers;
		IndexBuffer* m_IndexBuffer = nullptr;
		unsigned int m_RendererID = -1;


		friend class FrameArrayObject;
	};





	class FrameArrayObject
	{
	public:

		void Init(int frameCount)
		{
			m_FrameCount = (frameCount);
			m_ArrayObjects.clear();
			m_ArrayObjects.resize(frameCount);

			for (int i = 0; i < frameCount; i++)
			{
				m_ArrayObjects[i].Init();
			}

		}

		void AddVertexBuffer(const VertexBuffer* element, bool segmentize, bool SoA = false)
		{
			if (segmentize)
			{
				size_t segmentSize = element->GetSize() / m_FrameCount;
				size_t offset = 0;

				for (int i = 0; i < m_FrameCount; i++)
				{
					m_ArrayObjects[i].AddVertexBuffer(element, offset, segmentSize, SoA);
					offset += segmentSize;
				}
			}
			else
			{
				for (int i = 0; i < m_FrameCount; i++)
				{
					m_ArrayObjects[i].AddVertexBuffer(element);
				}
			}
		}

		void AddIndexBuffer(const Buffer* element)
		{
			for (int i = 0; i < m_FrameCount; i++)
			{
				m_ArrayObjects[i].AddIndexBuffer(element);
			}
		}

		void Compile()
		{
			for (auto& arrayObject : m_ArrayObjects)
			{
				arrayObject.Compile();
			}
		}

		void Destroy()
		{
			for (auto& arrayObject : m_ArrayObjects)
			{
				arrayObject.Destroy();
			}
		}

		inline ArrayObject& GetArrayObject(int frameIndex)
		{
			if (frameIndex < 0 || frameIndex >= m_FrameCount)
				throw std::out_of_range("Frame index out of range");
			return m_ArrayObjects[frameIndex];
		}

		inline int GetFrameCount() const { return m_FrameCount; }

		inline std::vector<ArrayObject>& GetArrayObjects() { return m_ArrayObjects; }

	private:
		int m_FrameCount = 0;
		std::vector<ArrayObject> m_ArrayObjects;
		
	};




	// _______ STORAGE BUFFERS _______





	// We will only have two frame for now, we will scale to a ring later
	// Automatically splits the total storage into half for now, 
	// We will impliment it after loading some basic models and running some physics
	//class RingStorageBuffer : public Buffer
	//{
	//public:
	//	RingStorageBuffer();
	//	~RingStorageBuffer();

	//protected:

	//	void Init()
	//	{
	//		m_Size = m_Size / m_Frames;
	//		m_Pointers.reserve(m_Frames);
	//	}


	//	void MapFrame(int i, StorageHints flags)
	//	{
	//		UnMap();
	//		m_Pointers[i] = Buffer::GetMappedPointer(flags, i * m_Size, m_Size);
	//	}

	//	void MapFrames(StorageHints flags)
	//	{
	//		for (int i = 0; i < m_Frames; i++)
	//			m_Pointers[i] = Buffer::GetMappedPointer(flags, i * m_Size, m_Size);
	//	}

	//	void NextFrame()
	//	{
	//		m_FrameInUse++;
	//		//if (m_FrameInUse < )
	//	}


	//private:
	//	using Buffer::GetMappedPointer;

	//	std::vector<void*> m_Pointers;

	//	int m_FrameInUse = 0;
	//	int m_Frames = 2;
	//};







	class ShaderStorageBuffer : public Buffer
	{
	public:
		void Init(StorageHints usage, void* data, size_t size);


	private:
	};










	class UnifromStorageBuffer : public Buffer
	{
	public:
		void Init(StorageHints usage, void* data, size_t size);


	private:
		
	};













}
