#include"Core.h"

namespace lunar
{

	bool Core::Init(int version, int minor)
	{
		if (m_IsInitialized)
		{
			LUNAR_LOG("Core is already initialized");
			return true;
		}


		if (!glfwInit())
		{
			LUNAR_ERROR("Failed to initialize GLFW");
			return false;
		}


		glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, version);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, minor);
		glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

		m_IsInitialized = true;
		return true;
	}

	void Core::Terminate()
	{
		if (m_Window)
		{
			glfwDestroyWindow(m_Window);
			m_Window = nullptr;
		}
		if (m_IsInitialized)
			glfwTerminate();

		m_IsInitialized = false;
		m_IsWindowCreated = false;
		m_GLEWInitialized = false;
	}


	bool Core::CreateWindow(int width, int height, const std::string& title)
	{
		if (!m_IsInitialized)
		{
			LUNAR_ERROR("Core::CreateWindow: call Core::Init first");
			return false;
		}

		m_Window = glfwCreateWindow(width, height, title.c_str(), nullptr, nullptr);
		if (!m_Window)
		{
			LUNAR_ERROR("Failed to create GLFW window");
			glfwTerminate();
			m_IsInitialized = false;
			return false;
		}
		m_IsWindowCreated = true;
		return true;
	}

	bool Core::MakeContextCurrent(GLFWwindow* window)
	{
		glfwMakeContextCurrent(window);

		if (m_GLEWInitialized == false)
		{
			// Needed so GLEW loads every entry point of a core-profile context
			glewExperimental = GL_TRUE;
			const GLenum glewResult = glewInit();
			if (glewResult != GLEW_OK)
			{
				LUNAR_ERROR("Failed to initialize GLEW: " << reinterpret_cast<const char*>(glewGetErrorString(glewResult)));
				return false;
			}
			m_GLEWInitialized = true;

			// glewInit leaves a harmless GL_INVALID_ENUM behind on core profiles, drop it
			// so it is not blamed on the first real GL_CHECK_ERROR
			while (glGetError() != GL_NO_ERROR) {}
		}
		return true;
	}

	void Core::SwapBuffers(GLFWwindow* window)
	{
		glfwSwapBuffers(window);
	}

	void Core::SetViewPort(int width, int height)
	{
		glViewport(0, 0, width, height);
	}

	bool Core::IsWindowAlive()
	{
		return m_Window && !glfwWindowShouldClose(m_Window);
	}

	void Core::PollEvents()
	{
		glfwPollEvents();
	}

	void Core::SwapBuffers()
	{
		if (m_Window) glfwSwapBuffers(m_Window);
	}


	GLFWwindow* Core::m_Window = nullptr;
	bool Core::m_IsInitialized = false;
	bool Core::m_IsWindowCreated = false;
	bool Core::m_GLEWInitialized = false;



}
