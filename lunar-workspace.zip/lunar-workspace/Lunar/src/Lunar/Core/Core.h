#pragma once

#include<GL/glew.h>
#include<GLFW/glfw3.h>


#include<iostream>
#include<vector>
#include<list>
#include<string>
#include<math.h>
#include<unordered_map>
#include<type_traits>
#include<thread>
#include<array>
#include<atomic>
#include<memory>
#include<algorithm>
#include<stdexcept>
#include<initializer_list>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cstddef>

#include<glm/glm.hpp>


// do/while(0) so the macros are safe inside if/else without braces
#define LUNAR_LOG(x) do { std::cout << x << std::endl; } while (0)
#define LUNAR_WARN(x) do { std::cout << x << std::endl; } while (0)
#define LUNAR_ERROR(x) do { std::cout << x << std::endl; } while (0)

// LUNAR_ASSERT(cond) / LUNAR_ASSERT_MSG(cond, stream-expression)
// Debug builds (NDEBUG not defined): a failed condition prints file:line and the condition, then breaks into the
// debugger (or traps when none is attached). Release builds: compiled out, the condition is NOT evaluated.
#if defined(_MSC_VER)
	#define LUNAR_DEBUGBREAK() __debugbreak()
#elif defined(__GNUC__) || defined(__clang__)
	#define LUNAR_DEBUGBREAK() __builtin_trap()
#else
	#define LUNAR_DEBUGBREAK() std::abort()
#endif

#ifndef NDEBUG
	#define LUNAR_ASSERT(cond) \
		do { if (!(cond)) { std::cerr << "LUNAR_ASSERT failed: " #cond " (" << __FILE__ << ":" << __LINE__ << ")" << std::endl; LUNAR_DEBUGBREAK(); } } while (0)
	#define LUNAR_ASSERT_MSG(cond, msg) \
		do { if (!(cond)) { std::cerr << "LUNAR_ASSERT failed: " #cond " - " << msg << " (" << __FILE__ << ":" << __LINE__ << ")" << std::endl; LUNAR_DEBUGBREAK(); } } while (0)
#else
	#define LUNAR_ASSERT(cond)          do { (void)sizeof(!(cond)); } while (0)
	#define LUNAR_ASSERT_MSG(cond, msg) do { (void)sizeof(!(cond)); } while (0)
#endif


#define GL_CHECK_ERROR()                                      \
    do {                                                      \
        GLenum err = glGetError();                            \
        if (err != GL_NO_ERROR) {                             \
            printf("OpenGL error 0x%X at %s:%d\n",             \
                   err, __FILE__, __LINE__);                  \
        }                                                     \
    } while (0)



namespace lunar
{
	class WindowUserData
	{
	public:
		size_t width, height;
		bool isFullScreen, isOnFocus;
	};

	class Core
	{
	public:
		// All three return false (and log the reason) when they fail; true means the step is done / was already done.
		static bool Init(int version = 4, int minor = 6);
		static void Terminate();
		static bool CreateWindow(int width, int height, const std::string& title);
		static bool MakeContextCurrent(GLFWwindow* window);   // also loads the GL entry points (GLEW) on the first call
		static void SwapBuffers(GLFWwindow* window);
		static void SwapBuffers();
		static void PollEvents();
		static void SetViewPort(int width, int height);
		static bool IsWindowAlive();

		Core() = delete;
		bool operator==(const Core& other) const = delete;


		static GLFWwindow* GetWindow() { return m_Window; }

	private:
		static GLFWwindow* m_Window;
		static bool m_IsInitialized;
		static bool m_IsWindowCreated;
		static bool m_GLEWInitialized;

	};


}
