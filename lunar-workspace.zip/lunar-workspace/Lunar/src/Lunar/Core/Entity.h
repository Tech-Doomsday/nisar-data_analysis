#pragma once
#include"Core.h"


namespace lunar
{
	inline size_t _entityComponentIDCounter()
	{
		static std::atomic<size_t> next{ 0 };
		return next++;
	}

	// One stable small integer per component type
	template<class T>
	inline size_t componentIDCounter()
	{
		static const size_t id = _entityComponentIDCounter();
		return id;
	}


	class Entity
	{
	public:
		size_t id = -1;
		std::vector<void*> components;

		inline bool IsValid() const { return id != (size_t)-1; }

		template<class _T>
		_T* GetComponent()
		{
			const size_t cid = componentIDCounter<_T>();
			if (components.size() <= cid)
				components.resize(cid + 1, nullptr);

			return static_cast<_T*>(components[cid]);
		}

		template<class _T>
		void SetComponent(_T* component)
		{
			const size_t cid = componentIDCounter<_T>();
			if (components.size() <= cid)
				components.resize(cid + 1, nullptr);

			components[cid] = component;
		}


		inline operator size_t() const { return id; }
	};
}
