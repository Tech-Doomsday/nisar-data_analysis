#include "Scene.h"

namespace lunar
{
	// (This file used to declare a global `namespace Scene {}`, which collided with lunar::Scene
	//  as soon as a user wrote `using namespace lunar;`.)
}
