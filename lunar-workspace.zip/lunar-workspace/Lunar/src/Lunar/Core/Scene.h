#pragma once
#include "Core.h"
#include "Buffer.h"
#include "Shape.h"
#include "Entity.h"
#include "../Utils/Storage.h"
#include "Shader.h"


namespace lunar
{



	class IndirectDrawCommand
	{
	public:
		unsigned int count;	// Number of indices to be rendered     
		unsigned int instanceCount;	// Number of instances to be rendered	
		unsigned int firstIndex;	// Starting index in the index buffer 
		unsigned int baseVertex;	// Added to each index before fetching from the vertex buffer
		unsigned int baseInstance;	// Added to each instance ID before fetching from the instance buffer
	};


	// Stable small integer per unit type. Only used as an index into the *per scene* table
	// (the unit id itself is now per scene, it used to be a static shared by every Scene<A,B>).
	inline std::atomic<size_t>& _unitTypeCounter()
	{
		static std::atomic<size_t> next{ 0 };
		return next;
	}

	template<class T>
	inline size_t unitTypeIndex()
	{
		static const size_t id = _unitTypeCounter().fetch_add(1);
		return id;
	}



	class BufferChainManager
	{
	public:
		// Must be called after the buffer has been intellized
		void Init(Buffer* buffer, int frame_count)
		{
			if (!buffer || buffer->GetRendererID() == (unsigned int)-1 || frame_count <= 0)
			{
				LUNAR_ERROR("BufferChainManager::Init: buffer is not initialised");
				return;
			}
			m_Buffer = (buffer);
			m__FrameCount = (frame_count);
			m_PresentFrame = (0);
			m_PerFrameSize = buffer->GetSize() / frame_count;
		}


		void Tick()
		{
			m_PresentFrame++;
			if (m_PresentFrame >= m__FrameCount) m_PresentFrame = 0;
		}

		void* GetMappedPointer(StorageHints flags, int frame_no)
		{
			return m_Buffer->GetMappedPointer(flags, frame_no * m_PerFrameSize, m_PerFrameSize);
		}

		inline Buffer* GetBuffer() { return m_Buffer; }

	private:
		Buffer* m_Buffer = nullptr;
		int m__FrameCount = 0;
		int m_PresentFrame = 0;
		size_t m_PerFrameSize = 0;

	};




	enum class SlotState
	{
		Free = 0,
		Written = 1,
		InFlight = 2 //Used by GPU, waiting for fence to be signaled
	};

	class FrameStats
	{
	public:
		std::atomic<SlotState> state{ SlotState::Free };
		GLsync fence = nullptr;
	};

	class SceneSSBO
	{
	public:
		void* mappedPointer = nullptr;
		Buffer* bufferPtr = nullptr;
		size_t capacity = 0;
	};







	// Threading contract:
	//   Init / AddUnit / AddShaderStorage / Render*  ........ the thread that owns the GL context
	//   UpdateStart .. UpdateEnd, AddEntity, RemoveEntity ..... the update thread (no GL calls inside)
	// The two sides only meet through the per-frame slot state (release / acquire).
	// An update loop that has no free slot can park on WaitForUpdateSlot() instead of sleep-polling UpdateStart();
	// RenderStart() wakes it when it frees a slot (C++20 atomic wait / notify).
	// Where a unit lives in the instance buffers: entities [start, start + capacity) of the combined entity range.
	// The live entities are packed at the front: [start, start + count), count == the unit's draw command instanceCount.
	// Every unit owns its own segment, so adding / removing entities of one unit never touches another unit's memory.
	struct UnitSegment
	{
		size_t start = 0;
		size_t capacity = 0;
	};

	template<class InstanceVertexBufferData, class InstanceStorageBufferData>
	class Scene
	{
	private:
		static constexpr int _MaxTypeIndex = 256;

		// -1 when the unit type was never added to THIS scene
		template<class T>
		inline int FindUnit() const
		{
			const size_t t = unitTypeIndex<T>();
			if (t >= (size_t)_MaxTypeIndex) return -1;
			return m_UnitOfType[t];
		}


	public:

		// Frame slots in the ring (UpdateChache::frameNo is in [0, RingSize))
		static constexpr int RingSize = 3;

		struct UpdateChache
		{
			IndirectDrawCommand* indirectDrawBufferPtr;
			InstanceVertexBufferData* instanceVertexBufferDataPtr;
			InstanceStorageBufferData* instanceStorageBufferDataPtr;
			FrameStats* stats;
			int frameNo;
		};

		struct RenderChache
		{
			int frameNo;
			FrameStats* stats;

			operator bool() { return frameNo == -1 ? false : true; }
		};


		Scene()
		{
			m_UnitOfType.fill(-1);
			m_IndirectDrawCommandVector.fill(IndirectDrawCommand{ 0, 0, 0, 0, 0 });
		}

		Scene(const Scene&) = delete;
		Scene& operator=(const Scene&) = delete;

		~Scene()
		{
			// fences that were never consumed
			for (int i = 0; i < _FrameCount; i++)
			{
				if (m_FrameStats[i].fence)
				{
					glDeleteSync(m_FrameStats[i].fence);
					m_FrameStats[i].fence = nullptr;
				}
			}
			// GL objects are released by the members' own destructors
		}

		// We may pass number of unit we will have in the template argument, as we will already know how many kinds of entities we will have in our game, setting to 20 just for now
		//
		// instanceStorageSize = bytes of the instance VERTEX buffer of ONE frame. The entity capacity is derived from it;
		// the instance STORAGE buffer (SSBO) is then sized for exactly that many InstanceStorageBufferData structs
		// (it used to reuse instanceStorageSize, so a bigger struct than the vertex entity overflowed it).
		bool Init(const std::initializer_list<VertexBufferElement>& VertexBufferLayout, const std::initializer_list<VertexBufferElement>& InstanceVertexBufferLayout, int unitCountEstimation, size_t instanceStorageSize = 1024 * 1024, int reservedUnitCount = 1)
		{
			if (isIntellized)
			{
				LUNAR_ERROR("Scene already intellized");
				return false;
			}

			if (unitCountEstimation <= 0 || reservedUnitCount < 0 || reservedUnitCount + unitCountEstimation > _MaxUnitCount)
			{
				LUNAR_ERROR("Given unit count exceeded max unit count");
				return false;
			}

			if (sizeof(InstanceStorageBufferData) == 0)
			{
				LUNAR_ERROR("InstanceStorageBufferData must not be empty");
				return false;
			}

			isIntellized = true;

			// Vertex Buffer and Index Buffer
			m_CombinedVertexBuffer.DataInit(BufferHint::DynamicDraw, nullptr, 1024 * 1024);
			m_CombinedVertexBuffer.SetLayout(VertexBufferLayout);
			m_CombinedIndexBuffer.Init(BufferHint::DynamicDraw, nullptr, 1024 * 1024);


			m_IDBsize = sizeof(IndirectDrawCommand) * (_MaxUnitCount);
			m_IDBtotalSize = m_IDBsize * _FrameCount;
			m_IndirectDrawBuffer.Init(m_ShaderStorageCreate_flag, nullptr, m_IDBtotalSize);


			m_InstanceVertexBuffer.SetLayout(InstanceVertexBufferLayout);
			m_InstanceVertexBuffer.SetInstanceDivisor(1);
			const size_t ivbLayoutSize = m_InstanceVertexBuffer.GetLayoutSize();
			if (ivbLayoutSize == 0 || instanceStorageSize < ivbLayoutSize)
			{
				LUNAR_ERROR("Scene::Init: instance vertex layout is empty or instanceStorageSize is too small");
				isIntellized = false;
				return false;
			}

			m_TotalEntityCap = instanceStorageSize / ivbLayoutSize;
			m_UnitSlots = (size_t)(reservedUnitCount + unitCountEstimation);
			m_EntityPerUnit = m_TotalEntityCap / m_UnitSlots;
			m_ReservedUnitCount = reservedUnitCount;
			if (m_EntityPerUnit == 0)
			{
				LUNAR_ERROR("Scene::Init: instanceStorageSize is too small for the given unit count");
				isIntellized = false;
				return false;
			}

			// exactly cap entities per frame: SoA blocks of the vertex buffer are cap * elementSize long
			m_IVBsize = m_TotalEntityCap * ivbLayoutSize;
			m_IVBtotalSize = m_IVBsize * _FrameCount;
			m_InstanceVertexBuffer.StorageInit(m_ShaderStorageCreate_flag, nullptr, m_IVBtotalSize);


			// SSBO: one slice per frame, every slice start must satisfy the SSBO offset alignment so that it can be
			// bound with glBindBufferRange (the shader then sees a plain instances[] array per frame)
			GLint align = 0;
			glGetIntegerv(GL_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT, &align);
			if (align <= 0) align = 256;
			const size_t isbBytes = m_TotalEntityCap * sizeof(InstanceStorageBufferData);
			m_ISBsize = ((isbBytes + (size_t)align - 1) / (size_t)align) * (size_t)align;
			m_ISBtotalSize = m_ISBsize * _FrameCount;
			m_InstanceStorageBuffer.Init(m_ShaderStorageCreate_flag, nullptr, m_ISBtotalSize); // We will have multiple ssbo, just usingone for now, we will have array of ssbo poiinter in the renderer pointer struct in future


			size_t idb_offset = 0;
			size_t isb_offset = 0;
			size_t ivb_offset = 0;

			char* isb_ptr = (char*)m_InstanceStorageBuffer.GetMappedPointer(m_ShaderStorageMapping_flag, isb_offset, m_ISBtotalSize);
			char* idb_ptr = (char*)m_IndirectDrawBuffer.GetMappedPointer(m_ShaderStorageMapping_flag, idb_offset, m_IDBtotalSize);
			char* ivb_ptr = (char*)m_InstanceVertexBuffer.GetMappedPointer(m_ShaderStorageMapping_flag, ivb_offset, m_IVBtotalSize);

			if (!isb_ptr || !idb_ptr || !ivb_ptr)
			{
				LUNAR_ERROR("Scene::Init: persistent mapping failed");
				isIntellized = false;
				return false;
			}

			for (int i = 0; i < _FrameCount; i++)
			{
				m_FrameStats[i].fence = nullptr;
				m_FrameStats[i].state.store(SlotState::Free);
				m_RenderBufferPointers[i].indirectDrawBufferPtr = (IndirectDrawCommand*)(idb_ptr + idb_offset);
				m_RenderBufferPointers[i].instanceStorageBufferDataPtr = (InstanceStorageBufferData*)(isb_ptr + isb_offset);
				m_RenderBufferPointers[i].instanceVertexBufferDataPtr = (InstanceVertexBufferData*)(ivb_ptr + ivb_offset);
				m_RenderBufferPointers[i].frameNo = i;
				m_RenderBufferPointers[i].stats = &m_FrameStats[i];

				isb_offset += m_ISBsize;
				ivb_offset += m_IVBsize;
				idb_offset += m_IDBsize;
			}



			m_CombinedArrayObject.Init(_FrameCount);
			m_CombinedArrayObject.AddVertexBuffer(&m_CombinedVertexBuffer, false, false);

			m_CombinedArrayObject.AddVertexBuffer(&m_InstanceVertexBuffer, true, true);

			m_CombinedArrayObject.AddIndexBuffer(&m_CombinedIndexBuffer);
			m_CombinedArrayObject.Compile();

			GL_CHECK_ERROR();
			return true;
		}


		void Refresh()
		{

		}


		// Registers a unit (an object kind). Units are numbered in the order they are added, which is also the
		// order they are drawn. Fails (returns false, nothing is modified) when the scene is full or the mesh
		// does not fit / does not match the combined vertex layout.
		//
		// `capacity` = how many entities the unit can hold. 0 = the default share (entityPerUnit, as before).
		// Segments are handed out one after the other, so units with different capacities are fine as long as the
		// sum fits into the entity capacity of the scene (GetTotalEntityCap()).
		template<class _Identifier>
		bool AddUnit(bool flush = true, size_t capacity = 0)
		{
			if (!isIntellized)
			{
				LUNAR_ERROR("Scene::AddUnit: scene is not intellized");
				return false;
			}

			const size_t typeIdx = unitTypeIndex<_Identifier>();
			if (typeIdx >= (size_t)_MaxTypeIndex)
			{
				LUNAR_ERROR("Scene::AddUnit: too many distinct unit types in the program");
				return false;
			}
			if (m_UnitOfType[typeIdx] != -1)
			{
				LUNAR_ERROR("Scene::AddUnit: this unit was already added to the scene");
				return false;
			}
			if (m_Units >= m_UnitSlots || m_Units >= (size_t)_MaxUnitCount)
			{
				LUNAR_ERROR("Scene::AddUnit: more units than (estimated + reserved) given to Scene::Init");
				return false;
			}
			const size_t unit_capacity = capacity ? capacity : m_EntityPerUnit;
			if (m_NextUnitStart + unit_capacity > m_TotalEntityCap)
			{
				LUNAR_ERROR("Scene::AddUnit: not enough entity capacity left for this unit");
				return false;
			}

			Object<_Identifier>();
			ShapeData& shape = Object<_Identifier>::ShapeData;

			const size_t vertexBytes = shape.GetVertexDataStorage().GetStride();
			const size_t indexBytes = shape.GetIndexDataStorage().GetStride();
			const size_t layoutSize = m_CombinedVertexBuffer.GetLayoutSize();

			if (vertexBytes == 0 || indexBytes == 0)
			{
				LUNAR_ERROR("Scene::AddUnit: the unit's ShapeData is empty (Object<T>::Init was not provided?)");
				return false;
			}
			if (layoutSize == 0 || vertexBytes % layoutSize != 0)
			{
				LUNAR_ERROR("Scene::AddUnit: vertex data is not a whole number of vertices of the combined layout");
				return false;
			}
			if (indexBytes % sizeof(unsigned int) != 0)
			{
				LUNAR_ERROR("Scene::AddUnit: index data is not a whole number of indices");
				return false;
			}
			{
				const std::vector<VertexBufferElement> shapeLayout = shape.GetVertexLayout();
				if (!shapeLayout.empty())
				{
					size_t s = 0;
					for (const VertexBufferElement& e : shapeLayout) s += e.size;
					if (s != layoutSize)
					{
						LUNAR_ERROR("Scene::AddUnit: the ShapeData layout does not match the combined vertex buffer layout");
						return false;
					}
				}
			}

			const size_t vertexStride = m_CombinedShapeData.GetVertexDataStorage().GetStride();
			const size_t indexStride = m_CombinedShapeData.GetIndexDataStorage().GetStride();
			if (vertexStride + vertexBytes > m_CombinedVertexBuffer.GetSize() || indexStride + indexBytes > m_CombinedIndexBuffer.GetSize())
			{
				LUNAR_ERROR("Scene::AddUnit: combined vertex / index buffer is full");
				return false;
			}

			const size_t unit_id = m_Units;
			const size_t unit_entity_start = m_NextUnitStart;

			IndirectDrawCommand command;
			command.baseInstance = (unsigned int)unit_entity_start;
			command.firstIndex = (unsigned int)(indexStride / sizeof(unsigned int));
			command.count = (unsigned int)(indexBytes / sizeof(unsigned int));
			command.baseVertex = (unsigned int)(vertexStride / layoutSize);
			command.instanceCount = 0;
			m_IndirectDrawCommandVector[unit_id] = command;

			m_CombinedIndexBuffer.Write(shape.GetIndexData(), indexStride, indexBytes);
			m_CombinedVertexBuffer.Write(shape.GetVertexData(), vertexStride, vertexBytes);

			m_CombinedShapeData.GetVertexDataStorage().Push(shape.GetVertexData(), vertexBytes);
			m_CombinedShapeData.GetIndexDataStorage().Push(shape.GetIndexData(), indexBytes);

			m_UnitOfType[typeIdx] = (int)unit_id;
			m_Segments[unit_id] = UnitSegment{ unit_entity_start, unit_capacity };
			m_NextUnitStart += unit_capacity;
			m_Units++;

			return true;
		}







		void FlushChanges() // We will need incase we want change the shader input layout during runtime or something
		{
			m_CombinedArrayObject.Compile();
		}




		// Returns an invalid Entity (IsValid() == false) when the unit is unknown or already holds
		// its maximum number of entities. (It used to hand out the id of the last entity again.)
		template<class _Identifier>
		Entity AddEntity() // For now we will have only one ssbo for storing per instance data, in future, we will develop versitile ssbo per instance attribute storing system, where entities may have different data from each other
		{
			const int unit_id = FindUnit<_Identifier>();
			if (unit_id < 0)
			{
				LUNAR_ERROR("Scene::AddEntity: the unit of this entity was not added to the scene");
				return Entity{};
			}

			const size_t slot = PushEntity(unit_id);
			if (slot == (size_t)-1)
			{
				LUNAR_ERROR("Scene::AddEntity: unit is full");   // TODO: reallocation / second drawcall for the unit
				return Entity{};
			}

			Entity e;
			e.id = slot;
			return e;
		}

		// Adds up to `count` entities, writes their handles to `out` (optional, must hold `count` items).
		// Returns how many were really added.
		template<class _Identifier>
		size_t AddEntities(size_t count, Entity* out = nullptr)
		{
			size_t added = 0;
			for (; added < count; added++)
			{
				Entity e = AddEntity<_Identifier>();
				if (!e.IsValid()) break;
				if (out) out[added] = e;
			}
			return added;
		}


		// Removes the LAST instance of the unit (keeps the instanced range dense); the caller moves the data of
		// the last entity into `entityID` first (swap-remove). SceneStorage (Impl/SceneStorage.h) does exactly that.
		template<class _Identifier>
		void RemoveEntity(size_t entityID, UpdateChache* pointers)
		{
			const int unit_id = FindUnit<_Identifier>();
			if (unit_id < 0)
			{
				LUNAR_ERROR("Scene::RemoveEntity: the unit of this entity was not added to the scene");
				return;
			}

			if (m_IndirectDrawCommandVector[unit_id].instanceCount == 0)
			{
				LUNAR_ERROR("Scene::RemoveEntity: unit has no entities");
				return;
			}
			PopEntity(unit_id);
		}


		// ---- unit-id API (the unit as a runtime number instead of a template tag; SceneStorage uses these) ----
		// Update thread. A unit id is the order of AddUnit calls (== draw order), -1 if the type is not in this scene.
		template<class _Identifier>
		inline int GetUnitId() const { return FindUnit<_Identifier>(); }

		inline const UnitSegment& GetSegment(int unit_id) const { return m_Segments[unit_id]; }
		inline size_t GetUnitEntityCount(int unit_id) const { return m_IndirectDrawCommandVector[unit_id].instanceCount; }

		// Appends one entity to the unit: returns its slot (index in the combined entity range) or (size_t)-1 when full.
		inline size_t PushEntity(int unit_id)
		{
			IndirectDrawCommand& command = m_IndirectDrawCommandVector[unit_id];
			const UnitSegment& seg = m_Segments[unit_id];
			if (command.instanceCount >= seg.capacity) return (size_t)-1;
			return seg.start + command.instanceCount++;
		}

		// Empties the unit (instance count 0).
		inline void ResetUnit(int unit_id) { m_IndirectDrawCommandVector[unit_id].instanceCount = 0; }

		// Drops the last entity of the unit (the data move is up to the caller / SceneStorage).
		inline void PopEntity(int unit_id)
		{
			IndirectDrawCommand& command = m_IndirectDrawCommandVector[unit_id];
			if (command.instanceCount > 0) command.instanceCount -= 1;
		}


		// Removes `end - start` entities from the end of the unit's range
		template<class _Identifier>
		void RemoveEntityRange(size_t start, size_t end, UpdateChache* pointers)
		{
			const int unit_id = FindUnit<_Identifier>();
			if (unit_id < 0 || end < start)
			{
				LUNAR_ERROR("Scene::RemoveEntityRange: invalid unit or range");
				return;
			}
			IndirectDrawCommand* command = &m_IndirectDrawCommandVector[unit_id];
			const size_t n = end - start;
			command->instanceCount = n >= command->instanceCount ? 0 : (unsigned int)(command->instanceCount - n);
		}





		// Creates an extra shader storage buffer, `size` bytes PER FRAME (the buffer is size * frames long, persistently mapped).
		// Returns nullptr when the index is out of range or already used.
		Buffer* AddShaderStorage(int index, size_t size)
		{
			if (index < 0 || index >= _MaxBufferStorageCount)
			{
				LUNAR_ERROR("Given index exceeded max buffer storage count");
				return nullptr;
			}
			if (m_BufferStorages[index].GetRendererID() != (unsigned int)-1)
			{
				LUNAR_ERROR("Scene::AddShaderStorage: index already used");
				return nullptr;
			}
			m_BufferStorages[index].StorageInit(BufferType::ShaderStorage, m_ShaderStorageCreate_flag, nullptr, size * _FrameCount);
			return &m_BufferStorages[index];
		}


		bool BindStorageBufferToSlot(unsigned int bindingPoint, Buffer* buffer)
		{
			if (!buffer) return false;
			buffer->BindBase(bindingPoint, BufferType::ShaderStorage);

			return true;
		}





		// Render side. The cursor only moves on RenderEnd(): a slot that is still owned by the GPU is simply retried
		// (the old code skipped it, which desynchronised the render cursor from the update cursor and could deadlock).
		RenderChache RenderStart()
		{
			RenderChache chache;
			FrameStats& frameStats = m_FrameStats[frame_i];
			SlotState slotState = frameStats.state.load(std::memory_order_acquire);

			chache.stats = &frameStats;
			chache.frameNo = frame_i;

			if (slotState == SlotState::InFlight)
			{
				GLenum waitResult = glClientWaitSync(frameStats.fence, GL_SYNC_FLUSH_COMMANDS_BIT, 0);
				if (waitResult == GL_ALREADY_SIGNALED || waitResult == GL_CONDITION_SATISFIED)
				{
					// The fence has been signaled, the slot can be written again
					glDeleteSync(frameStats.fence);
					frameStats.fence = nullptr;
					frameStats.state.store(SlotState::Free, std::memory_order_release);
					SignalUpdate();
					slotState = SlotState::Free;
				}
				else if (waitResult == GL_WAIT_FAILED)
				{
					LUNAR_ERROR("glClientWaitSync failed, fence was corrupted");
					glDeleteSync(frameStats.fence);
					frameStats.fence = nullptr;
					frameStats.state.store(SlotState::Free, std::memory_order_release);
					SignalUpdate();
					slotState = SlotState::Free;
				}
				else
				{
					// GPU still busy with this slot: stay on it, try again on the next call
					chache.frameNo = -1;
					return chache;
				}
			}

			if (slotState == SlotState::Written)
			{
				return chache;
			}
			chache.frameNo = -1;
			return chache;
		}

		void RenderEnd()
		{
			m_VisibleFrame = -1;
			frame_i = (frame_i + 1) % _FrameCount;
		}


		// Makes the update thread's writes of this frame visible to the GPU: explicit flush of the three
		// persistently mapped scene buffers plus a client-mapped barrier, which also covers extra buffers
		// created with AddShaderStorage and written through a persistent mapping. Call it before using those
		// extra buffers in a compute pass; RenderFrame calls it as well.
		void MakeUpdatesVisible(const RenderChache& chache)
		{
			if (m_VisibleFrame == chache.frameNo) return;   // already done for this frame (RenderEnd resets it)
			m_VisibleFrame = chache.frameNo;

			m_InstanceStorageBuffer.Flush(m_ISBsize * chache.frameNo, m_ISBsize);
			m_InstanceVertexBuffer.Flush(m_IVBsize * chache.frameNo, m_IVBsize);
			m_IndirectDrawBuffer.Flush(m_IDBsize * chache.frameNo, m_IDBsize);
			glMemoryBarrier(GL_CLIENT_MAPPED_BUFFER_BARRIER_BIT);
		}


		void RenderFrame(const Shader& shader, RenderChache chache)
		{
			if (!chache || m_Units == 0) return;

			// TODO: add a fast calculation if shader formate will match given ivb and isb structure

			MakeUpdatesVisible(chache);

			// This frame's slice of the instance SSBO appears at the binding point as a plain instances[] array
			// (before, the whole 3-frame buffer was bound once and every frame read frame 0's data)
			if (m_ISBBindingPoint != (unsigned int)-1)
				m_InstanceStorageBuffer.BindRange(m_ISBBindingPoint, m_ISBsize * chache.frameNo, m_ISBsize, BufferType::ShaderStorage);

			shader.Bind();
			m_CombinedArrayObject.GetArrayObject(chache.frameNo).Bind();
			glBindBuffer(GL_DRAW_INDIRECT_BUFFER, m_IndirectDrawBuffer.GetRendererID());
			glMultiDrawElementsIndirect(GL_TRIANGLES, GL_UNSIGNED_INT, (void*)(m_IDBsize * chache.frameNo), (GLsizei)m_Units, 0);
		}

		void RenderFence(RenderChache& state)
		{
			if (state.stats->fence) glDeleteSync(state.stats->fence);
			state.stats->fence = glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
			state.stats->state.store(SlotState::InFlight, std::memory_order_release);
		}

		inline UpdateChache* UpdateStart()
		{
			FrameStats& frameStats = m_FrameStats[frame_j];

			if (frameStats.state.load(std::memory_order_acquire) != SlotState::Free)
			{
				std::this_thread::yield();
				return nullptr;
			}

			return &m_RenderBufferPointers[frame_j];
		}

		// Update thread only. Blocks (no CPU, no polling) until UpdateStart() can succeed, i.e. until the render side has
		// freed the slot the update cursor points at. Returns true when UpdateStart() will succeed now, false when woken
		// by InterruptUpdateWait() (the update loop should then check whether it is supposed to stop).
		bool WaitForUpdateSlot()
		{
			for (;;)
			{
				// Ticket first, condition second: a slot freed (and signalled) in between changes the ticket,
				// so the wait below returns immediately and no wake-up can be lost.
				const uint32_t ticket = m_UpdateSignal.load(std::memory_order_acquire);
				if (m_FrameStats[frame_j].state.load(std::memory_order_acquire) == SlotState::Free) return true;
				if (m_UpdateWake.load(std::memory_order_acquire)) return false;
				m_UpdateSignal.wait(ticket, std::memory_order_acquire);
			}
		}

		// Any thread. Makes WaitForUpdateSlot() return false, now and on later calls, so the update thread can shut down.
		void InterruptUpdateWait()
		{
			m_UpdateWake.store(true, std::memory_order_release);
			SignalUpdate();
		}

		// Any thread. Re-arms WaitForUpdateSlot() after an InterruptUpdateWait().
		void ClearUpdateInterrupt() { m_UpdateWake.store(false, std::memory_order_release); }

		inline void UpdateIndirectDrawCommands(UpdateChache* pointer)
		{
			memcpy(pointer->indirectDrawBufferPtr, m_IndirectDrawCommandVector.data(), m_IndirectDrawCommandVector.size() * sizeof(IndirectDrawCommand));
		}



		// Function will be used only if SoB enabled
		// Writes the elements of ONE unit. `_src` points at the unit's own first element (local entity 0) and must hold
		// instanceCount * element_size bytes.
		// DISCLAMER: the element_offset_in_struct must be managed with aligment issues (tightly packed struct)
		//
		//   per frame slice:  [ element 0 of ALL entities ][ element 1 of ALL entities ] ...   (SoA)
		//   unit u inside a block starts at   u * entityPerUnit * element_size
		//   (it used  element_offset_in_struct * start  before, only right for the first unit)
		template<typename _Identifier>
		inline void UpdateUnitIBVelement(UpdateChache* pointer, size_t element_offset_in_struct, size_t element_size, void* _src) //TODO: don't take element_offset in future, we will calculate automatically
		{
			const int unit_id = FindUnit<_Identifier>();
			if (unit_id < 0)
			{
				LUNAR_ERROR("Scene::UpdateUnitIBVelement: unit was not added to the scene");
				return;
			}
			UpdateUnitIBVelementAt(pointer, unit_id, element_offset_in_struct, element_size, _src);
		}

		// Same, the unit given by its id (see GetUnitId)
		inline void UpdateUnitIBVelementAt(UpdateChache* pointer, int unit_id, size_t element_offset_in_struct, size_t element_size, void* _src)
		{
			UpdateIBVelementSlots(pointer, element_offset_in_struct, element_size,
				m_Segments[unit_id].start, m_IndirectDrawCommandVector[unit_id].instanceCount, _src);
		}

		// Writes `count` consecutive entities (global slots first_slot ...) of one element array; `_src` points at the first.
		inline void UpdateIBVelementSlots(UpdateChache* pointer, size_t element_offset_in_struct, size_t element_size, size_t first_slot, size_t count, void* _src)
		{
			const size_t element_start = m_TotalEntityCap * element_offset_in_struct + element_size * first_slot;
			const size_t element_bytes = count * element_size;

			if (element_start + element_bytes > m_IVBsize)
			{
				LUNAR_ERROR("Scene::UpdateUnitIBVelement: element does not fit into the instance vertex buffer slice");
				return;
			}

			memcpy((char*)pointer->instanceVertexBufferDataPtr + element_start, _src, element_bytes);
		}



		// Updates the whole element buffer of a frame, even storage of unintellized elements, provided memory must have same size as the element buffer, or get access violation error
		// Function will be used only if SoB enabled
		// DISCLAMER: the element_offset_in_struct must be managed with aligment issues
		inline void UpdateIBVelement(UpdateChache* pointer, size_t element_offset_in_struct, size_t element_size, void* _src) //TODO: don't take element_offset in future, we will calculate automatically
		{
			const size_t element_start = m_TotalEntityCap * element_offset_in_struct;

			const size_t element_stride = m_TotalEntityCap * element_size;

			if (element_start + element_stride > m_IVBsize)
			{
				LUNAR_ERROR("Scene::UpdateIBVelement: element does not fit into the instance vertex buffer slice");
				return;
			}

			memcpy((char*)pointer->instanceVertexBufferDataPtr + element_start, _src, element_stride);

		}


		// `offset` and `stride` are in bytes inside this frame's instance storage slice (offset was ignored before,
		// and an out of range copy was only reported, not prevented)
		//TODO: we will have multiple sb, so must impliment logic for that		
		inline void UpdateISB(UpdateChache* pointer, size_t offset, size_t stride, void* _src) // Pass sb id, or indexing system in future
		{
			if (m_ISBsize < stride + offset)
			{
				LUNAR_ERROR("[ERROR] Provided ISB data will overrite data of next frame");
				return;
			}

			memcpy((char*)pointer->instanceStorageBufferDataPtr + offset, _src, stride);
		}


		inline void UpdateEnd(UpdateChache* ret)
		{
			ret->stats->state.store(SlotState::Written, std::memory_order_release);
			frame_j = (frame_j + 1) % _FrameCount;
		}







		// The instance SSBO is bound to this point, one frame slice per RenderFrame
		void SetShaderInstanceStorageBufferBindingPoint(unsigned int bindingPoint)
		{
			m_ISBBindingPoint = bindingPoint;
			m_InstanceStorageBuffer.BindRange(bindingPoint, 0, m_ISBsize, BufferType::ShaderStorage);
		}


		ShapeData& GetCombinedShapeData() { return m_CombinedShapeData; }
		size_t GetDrawUnitCount() const { return m_Units; }


		inline size_t GetTotalEntityCap() const { return m_TotalEntityCap; }
		inline size_t GetEntityPerUnit() const { return m_EntityPerUnit; }   // default capacity of a unit
		inline size_t GetReservedUnitCount() const { return m_ReservedUnitCount; }
		inline size_t GetUnits() const { return m_Units; }
		inline size_t GetIDBsize() const { return m_IDBsize; }
		inline size_t GetIDBtotalSize() const { return m_IDBtotalSize; }
		inline size_t GetISBsize() const { return m_ISBsize; }
		inline size_t GetISBtotalSize() const { return m_ISBtotalSize; }
		inline size_t GetIVBsize() const { return m_IVBsize; }
		inline size_t GetIVBtotalSize() const { return m_IVBtotalSize; }

		// How many entities of the unit are currently alive (update thread)
		template<class _Identifier>
		inline size_t GetEntityCount() const
		{
			const int unit_id = FindUnit<_Identifier>();
			return unit_id < 0 ? 0 : m_IndirectDrawCommandVector[unit_id].instanceCount;
		}


	private:
		StorageHints m_ShaderStorageCreate_flag = (StorageHints)(StorageHints::WriteMap | StorageHints::PresistantMap);
		StorageHints m_ShaderStorageMapping_flag = (StorageHints)(StorageHints::WriteMap | StorageHints::PresistantMap | StorageHints::FlushMap);


		ShapeData m_CombinedShapeData;

		ShaderStorageBuffer m_IndirectDrawBuffer;


		VertexBuffer m_CombinedVertexBuffer;
		IndexBuffer m_CombinedIndexBuffer;


		FrameArrayObject m_CombinedArrayObject;



		VertexBuffer m_InstanceVertexBuffer;


		ShaderStorageBuffer m_InstanceStorageBuffer; // We are having just one shader storage for extra instance attributes, we will have multiple in future in a flexible system







		inline const static int _FrameCount = RingSize;
		inline const static int _MaxUnitCount = 20;
		inline const static int _MaxBufferStorageCount = 10;


		size_t m_TotalEntityCap = 0;
		size_t m_EntityPerUnit = 0;
		size_t m_ReservedUnitCount = 0;
		size_t m_UnitSlots = 0;
		size_t m_Units = 0;
		size_t m_NextUnitStart = 0;     // first entity slot not yet handed to a unit
		size_t m_IDBsize = 0;
		size_t m_IDBtotalSize = 0;
		size_t m_ISBsize = 0;
		size_t m_ISBtotalSize = 0;
		size_t m_IVBsize = 0;
		size_t m_IVBtotalSize = 0;
		unsigned int m_ISBBindingPoint = -1;

		std::array<int, _MaxTypeIndex> m_UnitOfType;
		std::array<IndirectDrawCommand, _MaxUnitCount> m_IndirectDrawCommandVector;
		std::array<UnitSegment, _MaxUnitCount> m_Segments;


		std::array<Buffer, _MaxBufferStorageCount> m_BufferStorages; // We aren't having thousands of ssbo in a scene lol
		std::array<std::array<SceneSSBO, _MaxBufferStorageCount>, _FrameCount> m_BufferStorageDat;



		FrameStats m_FrameStats[_FrameCount];
		UpdateChache m_RenderBufferPointers[_FrameCount];

		// Event count for WaitForUpdateSlot(): bumped (and notified) every time the update side may be able to proceed.
		std::atomic<uint32_t> m_UpdateSignal{ 0 };
		std::atomic<bool> m_UpdateWake{ false };

		void SignalUpdate()
		{
			m_UpdateSignal.fetch_add(1, std::memory_order_release);
			m_UpdateSignal.notify_one();
		}


		int frame_i = 0;   // render thread only
		int frame_j = 0;   // update thread only
		int m_VisibleFrame = -1;   // render thread only



		bool isIntellized = false;


	};
}
