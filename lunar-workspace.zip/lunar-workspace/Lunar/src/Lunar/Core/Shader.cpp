#include"Shader.h"



namespace lunar
{
	ShaderFragment::ShaderFragment(ShaderType type, const std::string& source)
		: m_Type(type), m_Source(source)
	{
		GLenum shaderType;
		switch (type)
		{
		case ShaderType::VertexShader:
			shaderType = GL_VERTEX_SHADER;
			break;
		case ShaderType::FragmentShader:
			shaderType = GL_FRAGMENT_SHADER;
			break;
		case ShaderType::ComputeShader:
			shaderType = GL_COMPUTE_SHADER;
			break;
		default:
			shaderType = GL_VERTEX_SHADER;
			LUNAR_WARN("Unknown shader type, defaulting to vertex shader.");
			break;
		}
		m_RendererID = glCreateShader(shaderType);
		const char* src = source.c_str();
		glShaderSource(m_RendererID, 1, &src, nullptr);
		glCompileShader(m_RendererID);
		int success;
		glGetShaderiv(m_RendererID, GL_COMPILE_STATUS, &success);
		if (!success)
		{
			char infoLog[4096];
			glGetShaderInfoLog(m_RendererID, 4096, nullptr, infoLog);
			std::cout << "ERROR::SHADER::COMPILATION_FAILED\n" << infoLog << std::endl;
		}
	}






	void ShaderFragment::Release()
	{
		if (m_RendererID)
		{
			glDeleteShader(m_RendererID);
			m_RendererID = 0;
		}
	}

	Shader::Shader()
	{
	}

	Shader::~Shader()
		{
			Destroy();
		}

	void Shader::AddFragment(ShaderType type, const std::string& source)
		{
			m_Fragments.emplace_back(type, source);
		}

	void Shader::Compile()
		{
			if (m_RendererID)
			{
				// compiling twice used to leak the first program
				glDeleteProgram(m_RendererID);
				m_RendererID = 0;
			}

			m_RendererID = glCreateProgram();
			for (const auto& fragment : m_Fragments)
			{
				if (fragment.GetRendererID())
					glAttachShader(m_RendererID, fragment.GetRendererID());
			}
			glLinkProgram(m_RendererID);
			int success = 0;
			glGetProgramiv(m_RendererID, GL_LINK_STATUS, &success);
			if (!success)
			{
				char infoLog[4096];
				glGetProgramInfoLog(m_RendererID, 4096, nullptr, infoLog);
				std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
			}

			// the program keeps its own copy of the binaries: detach and delete the stage objects now
			for (auto& fragment : m_Fragments)
			{
				if (fragment.GetRendererID())
					glDetachShader(m_RendererID, fragment.GetRendererID());
				fragment.Release();
			}
		}


	void Shader::Destroy()
	{
			for (auto& fragment : m_Fragments)
			{
				fragment.Release();
			}
			if (m_RendererID)
			{
				glDeleteProgram(m_RendererID);
				m_RendererID = 0;
			}
	}


	void Shader::Bind() const
	{
			glUseProgram(m_RendererID);
	}

	void Shader::Unbind() const
	{
			glUseProgram(0);
	}


}

