#pragma once
#include "Core.h"


namespace lunar
{
	enum class ShaderType
	{
		VertexShader = GL_VERTEX_SHADER,
		FragmentShader = GL_FRAGMENT_SHADER,
		ComputeShader = GL_COMPUTE_SHADER,
	};

	class ShaderFragment
	{
	public:
		ShaderFragment(ShaderType type, const std::string& source);
		
		ShaderType GetType() const { return m_Type; }
		unsigned int GetRendererID() const { return m_RendererID; }
		const std::string& GetSource() const { return m_Source; }

		// deletes the GL shader object (done after linking, a linked program no longer needs it)
		void Release();

	private:
		ShaderType m_Type;
		std::string m_Source;
		unsigned int m_RendererID = 0;

	};



	// TODO: have shander information and layout information in this class, so that we can have a more flexible shader system, and will be used for debugging and shader reflection
	class ShaderLayout
	{
	public:
		

	private:
	};


	class Shader
	{
	public:
		Shader();
		~Shader();
		Shader(const Shader&) = delete;             // a copy would delete the same GL program twice
		Shader& operator=(const Shader&) = delete;

		void AddFragment(ShaderType type, const std::string& source);

		void Compile();
		void Destroy();
		void Bind() const;
		void Unbind() const;

		unsigned int GetRendererID() const { return m_RendererID; }
		std::vector<ShaderFragment> GetFragments() const { return m_Fragments; }
	private:

		ShaderLayout m_Layout;
		std::vector<ShaderFragment> m_Fragments;
		unsigned int m_RendererID = 0;
	};
}