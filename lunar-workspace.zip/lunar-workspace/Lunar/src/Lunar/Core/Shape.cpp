#include "Shape.h"


namespace lunar
{
	ShapeData::ShapeData(const std::string& name)
		: m_Name(name)
	{

	}

	ShapeData::~ShapeData()
	{

	}

	void ShapeData::Init(void* vertices, size_t vertexSize, void* indices, size_t indexSize)
	{
		m_VertexData.Init(vertexSize, vertices);
		m_IndexData.Init(indexSize, indices);
	}
	
	void ShapeData::Init(const HeapStorage& vertices, const HeapStorage& indices)
	{
		m_VertexData = vertices;
		m_IndexData = indices;
	}


	void ShapeData::Destroy()
	{
		m_VertexData.Destroy();
		m_IndexData.Destroy();
	}


}