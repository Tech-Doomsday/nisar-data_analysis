#pragma once
#include "Core.h"
#include "Buffer.h"
#include "../Utils/Storage.h"


namespace lunar
{


	class ShapeData
	{
	public:
		ShapeData(const std::string& name = "Untitled ShapeData");
		~ShapeData();

		void Init(const HeapStorage& vertices, const HeapStorage& indices);
		void Init(void* vertices, size_t vertexSize, void* indices, size_t indexSize);
		void Destroy();		
		void SetName(const std::string& name) { m_Name = name; }

		void* GetVertexData() const { return m_VertexData.GetData<void>(); }
		void* GetIndexData() const { return m_IndexData.GetData<void>(); }

		inline HeapStorage& GetVertexDataStorage() { return m_VertexData; }
		inline HeapStorage& GetIndexDataStorage() { return m_IndexData; }

		size_t GetIndicesCount() const { return m_IndexData.GetStride() / sizeof(unsigned int); }

		void SetVertexLayout(const std::vector<VertexBufferElement>& layout) { m_VertexLayout = layout; }
		std::vector<VertexBufferElement> GetVertexLayout() const { return m_VertexLayout; }

		const std::string& GetName() { return m_Name; }
	protected:

		HeapStorage m_VertexData;
		HeapStorage m_IndexData;

		std::vector<VertexBufferElement> m_VertexLayout;

		std::string m_Name;
	};


	// TODO: have more kinds of data like, bone data, animation data, etc...
	template<class _Name>
	class Object
	{
	public:
		Object()
		{
			if (!m_Intellized)
			{
				m_Intellized = true;
				Init();
			}
		}


		// defined in user side, for example in CommonShapes.h
		static void Init();


		inline static lunar::ShapeData ShapeData;   // qualified so the member may share the type's name on every compiler
	private:
		inline static bool m_Intellized;
	};




	//template<class _Name>
	//ShapeData Object<_Name>::ShapeData;

	//template<class _Name>
	//bool Object<_Name>::m_Intellized = false;

}