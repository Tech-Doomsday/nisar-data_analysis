#pragma once
#include "EventBus.h"
#include "Events.h"

// ─────────────────────────────────────────────────────────────────────────────
//  EventAdapter
//
//  Drop-in replacement for Lenz::EventAdapter (that is what Lenz's Camera derived
//  from). Override only the On*() handlers you care about; return true to consume.
//
//      class FlyCamera : public lunar::EventAdapter {
//          bool OnKeyPressed(lunar::events::KeyPressed& e) override { ...; return false; }
//      };
//      cam.SubscribeEvents(app.Events());
//
//  Fixed compared to Lenz:
//    * the destructor unsubscribes (a destroyed adapter can no longer be called)
//    * consuming works: returning true stops propagation, returning false can no
//      longer overwrite an earlier listener's "consumed"
//    * covers every event, including scroll / typed / focus
//
//  Modules do not need this, Module::Listen<E>() does the same job per event.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	class EventAdapter
	{
	public:
		virtual ~EventAdapter() { UnsubscribeEvents(); }

		void SubscribeEvents(EventBus& bus, int priority = 0)
		{
			UnsubscribeEvents();
			using namespace events;
			m_Subs.Add(bus.On<KeyPressed>([this](KeyPressed& e) { return OnKeyPressed(e); }, priority));
			m_Subs.Add(bus.On<KeyReleased>([this](KeyReleased& e) { return OnKeyReleased(e); }, priority));
			m_Subs.Add(bus.On<KeyTyped>([this](KeyTyped& e) { return OnKeyTyped(e); }, priority));
			m_Subs.Add(bus.On<MouseButtonPressed>([this](MouseButtonPressed& e) { return OnMouseButtonPressed(e); }, priority));
			m_Subs.Add(bus.On<MouseButtonReleased>([this](MouseButtonReleased& e) { return OnMouseButtonReleased(e); }, priority));
			m_Subs.Add(bus.On<MouseMoved>([this](MouseMoved& e) { return OnMouseMoved(e); }, priority));
			m_Subs.Add(bus.On<MouseScrolled>([this](MouseScrolled& e) { return OnMouseScrolled(e); }, priority));
			m_Subs.Add(bus.On<WindowClosed>([this](WindowClosed& e) { return OnWindowClosed(e); }, priority));
			m_Subs.Add(bus.On<WindowResized>([this](WindowResized& e) { return OnWindowResized(e); }, priority));
			m_Subs.Add(bus.On<FramebufferResized>([this](FramebufferResized& e) { return OnFramebufferResized(e); }, priority));
			m_Subs.Add(bus.On<WindowFocus>([this](WindowFocus& e) { return OnWindowFocus(e); }, priority));
		}

		void UnsubscribeEvents() { m_Subs.Clear(); }

		virtual bool OnKeyPressed(events::KeyPressed&) { return false; }
		virtual bool OnKeyReleased(events::KeyReleased&) { return false; }
		virtual bool OnKeyTyped(events::KeyTyped&) { return false; }
		virtual bool OnMouseButtonPressed(events::MouseButtonPressed&) { return false; }
		virtual bool OnMouseButtonReleased(events::MouseButtonReleased&) { return false; }
		virtual bool OnMouseMoved(events::MouseMoved&) { return false; }
		virtual bool OnMouseScrolled(events::MouseScrolled&) { return false; }
		virtual bool OnWindowClosed(events::WindowClosed&) { return false; }
		virtual bool OnWindowResized(events::WindowResized&) { return false; }
		virtual bool OnFramebufferResized(events::FramebufferResized&) { return false; }
		virtual bool OnWindowFocus(events::WindowFocus&) { return false; }

	private:
		SubscriptionList m_Subs;
	};
}
