#pragma once
#include <algorithm>
#include <atomic>
#include <cassert>
#include <climits>
#include <cstdint>
#include <functional>
#include <memory>
#include <thread>
#include <type_traits>
#include <utility>
#include <vector>

// ─────────────────────────────────────────────────────────────────────────────
//  EventBus  (main thread)
//
//  What changed compared to Lenz::EventBus
//    * listeners are ordered: higher priority first, registration order among equals
//      (Lenz used an unordered_map, so "registration order" was not actually true)
//    * a handler that returns true CONSUMES the event and the bus stops there
//      (Lenz called every listener no matter what)
//    * subscribing / unsubscribing from inside a handler is safe
//    * On<E>() returns an RAII Subscription: dropping it unsubscribes. No IDs to
//      keep, no Off<E>() to forget, no dangling `this` in a std::function
//    * it is an instance (Application::Events()), not a process-wide static
//    * a Subscription may outlive the bus; it simply does nothing then
//
//  Handlers are `bool(E&)` ("true = consumed") or `void(E&)` ("never consumes").
//
//  Threading: a bus belongs to the thread that created it (debug builds assert
//  it). Cross-thread traffic goes through EventQueue / InputRelay instead.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	template<class E>
	concept EventType = std::is_class_v<E> && std::is_copy_constructible_v<E> && !std::is_const_v<E>;

	namespace detail
	{
		inline std::atomic<size_t>& EventTypeCounter()
		{
			static std::atomic<size_t> next{ 0 };
			return next;
		}

		template<class E>
		inline size_t EventTypeIndex()
		{
			static const size_t id = EventTypeCounter().fetch_add(1);
			return id;
		}

		struct IChannel
		{
			virtual ~IChannel() = default;
			virtual void Remove(uint32_t id) = 0;
		};

		template<class E>
		struct Channel final : IChannel
		{
			struct Listener
			{
				uint32_t id = 0;
				int priority = 0;
				std::function<bool(E&)> fn;
				bool dead = false;
			};

			std::vector<Listener> listeners;   // sorted: priority descending, stable
			std::vector<Listener> pendingAdd;  // subscribed while an Emit was running
			int emitDepth = 0;
			bool dirty = false;

			void Add(Listener l)
			{
				if (emitDepth > 0) { pendingAdd.push_back(std::move(l)); return; }
				Insert(std::move(l));
			}

			void Remove(uint32_t id) override
			{
				for (Listener& l : pendingAdd)
					if (l.id == id) { l.dead = true; dirty = true; }
				for (Listener& l : listeners)
					if (l.id == id)
					{
						if (emitDepth > 0) { l.dead = true; dirty = true; }   // erased once the outermost Emit ends
						else { Erase(id); }
						return;
					}
			}

			bool Emit(E& e)
			{
				struct Guard
				{
					Channel& c;
					explicit Guard(Channel& ch) : c(ch) { ++c.emitDepth; }
					~Guard() { if (--c.emitDepth == 0) c.Flush(); }
				} guard(*this);

				// the vector is not touched while emitDepth > 0, so indices and references stay valid
				for (size_t i = 0, n = listeners.size(); i < n; ++i)
				{
					Listener& l = listeners[i];
					if (l.dead) continue;
					if (l.fn(e)) return true;
				}
				return false;
			}

		private:
			void Insert(Listener l)
			{
				// after every listener with priority >= l.priority
				auto it = std::upper_bound(listeners.begin(), listeners.end(), l.priority,
					[](int p, const Listener& x) { return p > x.priority; });
				listeners.insert(it, std::move(l));
			}

			void Erase(uint32_t id)
			{
				listeners.erase(std::remove_if(listeners.begin(), listeners.end(),
					[id](const Listener& l) { return l.id == id; }), listeners.end());
			}

			void Flush()
			{
				if (dirty)
				{
					auto dead = [](const Listener& l) { return l.dead; };
					listeners.erase(std::remove_if(listeners.begin(), listeners.end(), dead), listeners.end());
					pendingAdd.erase(std::remove_if(pendingAdd.begin(), pendingAdd.end(), dead), pendingAdd.end());
					dirty = false;
				}
				if (!pendingAdd.empty())
				{
					std::vector<Listener> add;
					add.swap(pendingAdd);
					for (Listener& l : add) Insert(std::move(l));
				}
			}
		};

		struct BusCore
		{
			std::vector<std::unique_ptr<IChannel>> channels;   // indexed by EventTypeIndex<E>()
			uint32_t nextID = 1;
		};
	}


	// Move-only handle. Destroying / Reset()ing it removes the listener.
	class Subscription
	{
	public:
		Subscription() = default;
		Subscription(const Subscription&) = delete;
		Subscription& operator=(const Subscription&) = delete;
		Subscription(Subscription&& o) noexcept { Steal(o); }
		Subscription& operator=(Subscription&& o) noexcept
		{
			if (this != &o) { Reset(); Steal(o); }
			return *this;
		}
		~Subscription() { Reset(); }

		void Reset()
		{
			if (m_Id != 0)
				if (auto core = m_Core.lock())
					if (m_Channel < core->channels.size() && core->channels[m_Channel])
						core->channels[m_Channel]->Remove(m_Id);
			m_Core.reset();
			m_Id = 0;
		}

		// Keep the listener alive for as long as the bus lives.
		void Detach() { m_Core.reset(); m_Id = 0; }

		bool Active() const { return m_Id != 0 && !m_Core.expired(); }
		explicit operator bool() const { return Active(); }

	private:
		friend class EventBus;
		Subscription(std::weak_ptr<detail::BusCore> core, size_t channel, uint32_t id)
			: m_Core(std::move(core)), m_Channel(channel), m_Id(id) {}

		void Steal(Subscription& o)
		{
			m_Core = std::move(o.m_Core);
			m_Channel = o.m_Channel;
			m_Id = o.m_Id;
			o.m_Core.reset();
			o.m_Id = 0;
		}

		std::weak_ptr<detail::BusCore> m_Core;
		size_t m_Channel = 0;
		uint32_t m_Id = 0;
	};


	// A bag of Subscriptions (what a module / layer keeps).
	class SubscriptionList
	{
	public:
		void Add(Subscription s) { m_Subs.push_back(std::move(s)); }
		void Clear() { m_Subs.clear(); }
		size_t Size() const { return m_Subs.size(); }
	private:
		std::vector<Subscription> m_Subs;
	};


	class EventBus
	{
	public:
		static constexpr int LowestPriority = INT_MIN;

		EventBus() : m_Core(std::make_shared<detail::BusCore>()), m_Owner(std::this_thread::get_id()) {}
		EventBus(const EventBus&) = delete;
		EventBus& operator=(const EventBus&) = delete;

		// Higher `priority` is called first; equal priorities in registration order.
		template<EventType E, class Fn>
		[[nodiscard]] Subscription On(Fn&& fn, int priority = 0)
		{
			AssertOwner();
			static_assert(std::is_invocable_v<Fn&, E&>, "handler must be callable as bool(E&) or void(E&)");
			using R = std::invoke_result_t<Fn&, E&>;
			static_assert(std::is_void_v<R> || std::is_convertible_v<R, bool>, "handler must return bool or void");

			auto& ch = GetChannel<E>();
			typename detail::Channel<E>::Listener l;
			l.id = m_Core->nextID++;
			l.priority = priority;
			if constexpr (std::is_void_v<R>)
				l.fn = [f = std::forward<Fn>(fn)](E& e) mutable { f(e); return false; };
			else
				l.fn = [f = std::forward<Fn>(fn)](E& e) mutable { return static_cast<bool>(f(e)); };

			const uint32_t id = l.id;
			ch.Add(std::move(l));
			return Subscription(m_Core, detail::EventTypeIndex<E>(), id);
		}

		// Calls the listeners on a private copy. Returns true when one of them consumed it.
		template<class E>
		bool Emit(E&& event)
		{
			using T = std::remove_cvref_t<E>;
			static_assert(EventType<T>);
			AssertOwner();

			const size_t idx = detail::EventTypeIndex<T>();
			if (idx >= m_Core->channels.size() || !m_Core->channels[idx]) return false;

			T local(std::forward<E>(event));
			return static_cast<detail::Channel<T>&>(*m_Core->channels[idx]).Emit(local);
		}

		template<EventType E, class... Args>
		bool EmitArgs(Args&&... args)
		{
			return Emit(E{ std::forward<Args>(args)... });
		}

		template<EventType E>
		size_t ListenerCount() const
		{
			const size_t idx = detail::EventTypeIndex<E>();
			if (idx >= m_Core->channels.size() || !m_Core->channels[idx]) return 0;
			size_t n = 0;
			for (auto& l : static_cast<detail::Channel<E>&>(*m_Core->channels[idx]).listeners) n += l.dead ? 0 : 1;
			return n;
		}

	private:
		template<class E>
		detail::Channel<E>& GetChannel()
		{
			const size_t idx = detail::EventTypeIndex<E>();
			if (idx >= m_Core->channels.size()) m_Core->channels.resize(idx + 1);
			if (!m_Core->channels[idx]) m_Core->channels[idx] = std::make_unique<detail::Channel<E>>();
			return static_cast<detail::Channel<E>&>(*m_Core->channels[idx]);
		}

		void AssertOwner() const
		{
			assert(m_Owner == std::this_thread::get_id() && "EventBus is main-thread only; use EventQueue to cross threads");
		}

		std::shared_ptr<detail::BusCore> m_Core;
		std::thread::id m_Owner;
	};
}
