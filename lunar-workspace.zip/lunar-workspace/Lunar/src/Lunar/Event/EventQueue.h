#pragma once
#include <atomic>
#include <cstddef>
#include <memory>
#include <type_traits>
#include <utility>

// ─────────────────────────────────────────────────────────────────────────────
//  SpscQueue<T, Capacity>
//
//  Lock-free single-producer / single-consumer ring buffer. This is how events
//  cross from the main thread (GLFW) to the update thread without a mutex or a
//  pile of atomics: the producer calls TryPush, the consumer calls TryPop.
//
//  Capacity must be a power of two. Storage is heap allocated once, nothing is
//  allocated while pushing / popping.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	template<class T, size_t Capacity = 1024>
	class SpscQueue
	{
		static_assert(Capacity >= 2 && (Capacity & (Capacity - 1)) == 0, "Capacity must be a power of two");
		static_assert(std::is_default_constructible_v<T> && std::is_move_assignable_v<T>);

	public:
		SpscQueue() : m_Buffer(std::make_unique<T[]>(Capacity)) {}
		SpscQueue(const SpscQueue&) = delete;
		SpscQueue& operator=(const SpscQueue&) = delete;

		static constexpr size_t GetCapacity() { return Capacity; }

		// producer thread only. False when the queue is full.
		bool TryPush(T value)
		{
			const size_t tail = m_Tail.load(std::memory_order_relaxed);
			if (tail - m_Head.load(std::memory_order_acquire) >= Capacity) return false;
			m_Buffer[tail & Mask] = std::move(value);
			m_Tail.store(tail + 1, std::memory_order_release);
			return true;
		}

		// consumer thread only. False when the queue is empty.
		bool TryPop(T& out)
		{
			const size_t head = m_Head.load(std::memory_order_relaxed);
			if (head == m_Tail.load(std::memory_order_acquire)) return false;
			out = std::move(m_Buffer[head & Mask]);
			m_Head.store(head + 1, std::memory_order_release);
			return true;
		}

		// approximate from any thread
		size_t SizeApprox() const
		{
			return m_Tail.load(std::memory_order_acquire) - m_Head.load(std::memory_order_acquire);
		}

	private:
		static constexpr size_t Mask = Capacity - 1;

		std::unique_ptr<T[]> m_Buffer;
		alignas(64) std::atomic<size_t> m_Head{ 0 };   // consumer
		alignas(64) std::atomic<size_t> m_Tail{ 0 };   // producer
	};
}
