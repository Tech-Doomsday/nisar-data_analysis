#pragma once
#include <cstdint>
#include <variant>

#include "../Input/KeyCodes.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Platform events.
//
//  Plain aggregates, no base class, no virtuals, no macros (same idea as Lenz).
//  One difference: the `consumed` flag is no longer a field of every event.
//  A listener says "handled" by returning true, and the bus stops there.
//
//  All of them are trivially copyable, so they can be queued between threads.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar::events
{
	// ── Window ───────────────────────────────────────────────────────────────
	struct WindowClosed {};                                        // the user asked to close; consume it to veto
	struct WindowResized { uint32_t width = 0, height = 0; };      // window size in screen coordinates
	struct FramebufferResized { uint32_t width = 0, height = 0; }; // size in pixels (what glViewport wants)
	struct WindowMoved { int x = 0, y = 0; };
	struct WindowFocus { bool focused = false; };
	struct WindowIconified { bool iconified = false; };

	// ── Keyboard ─────────────────────────────────────────────────────────────
	struct KeyPressed  { Key key = Key::Space; int scancode = 0; int mods = 0; bool repeat = false; };
	struct KeyReleased { Key key = Key::Space; int scancode = 0; int mods = 0; };
	struct KeyTyped    { uint32_t codepoint = 0; };                // text input (unicode code point)

	// ── Mouse ────────────────────────────────────────────────────────────────
	struct MouseMoved           { double x = 0, y = 0, dx = 0, dy = 0; };   // position + delta since the previous move
	struct MouseButtonPressed   { MouseButton button = MouseButton::Left; int mods = 0; };
	struct MouseButtonReleased  { MouseButton button = MouseButton::Left; int mods = 0; };
	struct MouseScrolled        { double xOffset = 0, yOffset = 0; };

	// Every platform event in one type. The window produces these, the application
	// visits them and hands the concrete type to the bus.
	using Event = std::variant<
		WindowClosed, WindowResized, FramebufferResized, WindowMoved, WindowFocus, WindowIconified,
		KeyPressed, KeyReleased, KeyTyped,
		MouseMoved, MouseButtonPressed, MouseButtonReleased, MouseScrolled>;
}
