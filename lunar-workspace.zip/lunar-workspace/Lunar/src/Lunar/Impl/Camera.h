#pragma once
#include "../Core/Core.h"
#include "../Core/Buffer.h"


namespace lunar
{
	class Camera : public UnifromStorageBuffer
	{
	public:

		Camera()
		{

		}

		// Init() below hides the base class Init(usage, data, size); bring it back
		using UnifromStorageBuffer::Init;

		void Init()
		{
		}


	private:
	};
}
