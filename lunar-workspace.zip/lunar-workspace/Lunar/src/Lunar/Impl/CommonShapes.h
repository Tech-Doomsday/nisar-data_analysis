#pragma once
#include "../Core/Scene.h"


namespace lunar
{
	// Tag for Scene::AddUnit<Cube>(). Mesh: unit cube, vertex = { x, y, z } (layout {location 0, 3 x GL_FLOAT}).
	struct Cube {};

	template<> inline void Object<Cube>::Init()
	{
		float vertices[] =
		{
			-0.5f, -0.5f, -0.5f,
			 0.5f, -0.5f, -0.5f,
			 0.5f,  0.5f, -0.5f,
			-0.5f,  0.5f, -0.5f,
			-0.5f, -0.5f,  0.5f,
			 0.5f, -0.5f,  0.5f,
			 0.5f,  0.5f,  0.5f,
			-0.5f,  0.5f,  0.5f,
		};

		unsigned int indices[] =
		{
			0, 1, 2,  2, 3, 0,   // back
			4, 6, 5,  6, 4, 7,   // front
			0, 3, 7,  7, 4, 0,   // left
			1, 5, 6,  6, 2, 1,   // right
			0, 4, 5,  5, 1, 0,   // bottom
			3, 2, 6,  6, 7, 3,   // top
		};

		ShapeData.Init(vertices, sizeof(vertices), indices, sizeof(indices));
		ShapeData.SetVertexLayout({ {0, 3, GL_FLOAT, sizeof(float) * 3} });
	}
}
