#pragma once
#include <utility>

#include "../App/FrameGate.h"

// ─────────────────────────────────────────────────────────────────────────────
//  SceneGate<SceneT>  -  connects Application's loops to a lunar::Scene.
//
//      using GameScene = lunar::Scene<IVBData, ISBData>;
//      auto& gate = *app.SetGate(std::make_unique<lunar::SceneGate<GameScene>>(scene));
//
//  Between AcquireUpdate() and ReleaseUpdate() (update thread) Update() is the
//  slot to write into. Between AcquireRender() and ReleaseRender() (main thread)
//  Render() is the slot to draw. It only calls the Scene's own API, in the same
//  order the hand-written loop in the Rift demo did:
//
//      update:  UpdateStart  ... write ...  UpdateEnd
//      render:  RenderStart  ... draw ... swap ...  RenderFence, RenderEnd
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	template<class SceneT>
	class SceneGate final : public FrameGate
	{
	public:
		explicit SceneGate(SceneT& scene) : m_Scene(scene) {}

		bool AcquireUpdate() override
		{
			m_Update = m_Scene.UpdateStart();
			return m_Update != nullptr;
		}

		void ReleaseUpdate() override
		{
			m_Scene.UpdateEnd(m_Update);
			m_Update = nullptr;
		}

		bool AcquireRender() override
		{
			m_Render = m_Scene.RenderStart();
			return static_cast<bool>(m_Render);
		}

		void ReleaseRender() override
		{
			m_Scene.RenderFence(m_Render);
			m_Scene.RenderEnd();
		}

		// Park the update thread until RenderStart() frees the slot (Scene::WaitForUpdateSlot, atomic wait).
		// A Scene without that API keeps the polling back-off.
		bool WaitUpdate() override
		{
			if constexpr (requires(SceneT& s) { s.WaitForUpdateSlot(); })
			{
				m_Scene.WaitForUpdateSlot();
				return true;
			}
			else
			{
				return false;
			}
		}

		void Interrupt() override
		{
			if constexpr (requires(SceneT& s) { s.InterruptUpdateWait(); })
				m_Scene.InterruptUpdateWait();
		}

		SceneT& GetScene() const { return m_Scene; }
		auto* Update() const { return m_Update; }          // update thread only
		auto& Render() { return m_Render; }                // main thread only

	private:
		SceneT& m_Scene;
		decltype(std::declval<SceneT&>().UpdateStart()) m_Update = nullptr;
		decltype(std::declval<SceneT&>().RenderStart()) m_Render{};
	};
}
