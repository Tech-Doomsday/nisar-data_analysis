#pragma once
#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include <vector>

#include "../Core/Scene.h"

// ─────────────────────────────────────────────────────────────────────────────
//  SceneStorage<SceneT>  -  the CPU side of a Scene's entities.
//
//  The Scene owns the GPU buffers, the units and each unit's segment; this class owns the DATA of the entities:
//    * one array per member (SoA), indexed by SLOT = position in the Scene's combined entity range, so a unit's
//      live entities are  [start, start + count)  and a system just loops over that range
//    * one handle table per unit: handle -> slot (and slot -> handle), so a handle stays valid when the
//      entity's data is moved
//    * swap-remove: destroying an entity moves the unit's LAST entity into its slot. Only that unit is touched.
//
//      SceneStorage<GameScene> store(scene);                           // after Scene::Init
//      auto pos   = store.AddGpuColumn<glm::vec3>(offsetof(IVB, pos)); // mirrored into the instance vertex buffer
//      auto color = store.AddGpuColumn<glm::vec4>(offsetof(IVB, color));
//      auto hp    = store.AddCpuColumn<float>();                       // CPU only
//
//      Handle h = store.Create<Bullet>();                              // appended at once, values start at 0
//      store.Get(pos, h)->y = 1.0f;
//
//      Range r = store.RangeOf<Bullet>();                              // update thread, every tick:
//      glm::vec3* P = store.Data(pos);
//      for (uint32_t i = r.begin; i < r.begin + r.count; i++) { P[i].y += dt; if (P[i].y > 1) store.Destroy(store.HandleAt(unit, i)); }
//      store.Flush();                                                  // applies the queued destroys
//      store.Upload(gate.Update());                                    // columns -> this frame's slot + draw commands
//
//  Two ways to hold a unit's entities (decided by the first call on the unit, never mixed):
//    tracked  Create / Destroy / handles           entities are found again by Handle, whatever moves
//    dense    Append / RemoveAt(unit, slot)        no handle tables at all: slots are all you have. Remove while looping
//                                                  BACKWARDS (the swapped-in entity was already visited) or outside loops.
//  Both: ClearUnit(), RangeOf(), Upload(). RemoveAt also works on a tracked unit.
//
//  Columns:  CPU columns can be limited to some units (MaskOf<A, B>()): they are then only moved / zeroed for those.
//            GPU / ISB columns can be marked "does not follow the entity" for games that rebuild that data every frame.
//
//  Upload cost: a GPU / ISB column is copied in full every tick (UploadMode::Always, the default). A column that mostly stays
//  the same can be created with UploadMode::OnChange: it then only copies the 64-entity blocks that changed, per frame slot.
//    * create / remove / move / clear of entities mark their blocks automatically (for columns that follow the entity)
//    * a write through Data() is not seen: declare it with Touch(col) / TouchUnit / TouchRange / TouchAt / Touch(col, handle)
//    * SetVerifyUploads(true) checks every skipped block against a shadow copy and counts a forgotten Touch (UploadViolations())
//
//  Destroy() only queues the handle (swap-remove inside a loop would skip or repeat the moved entity);
//  Flush() applies the queue. Create() appends, which does not disturb a loop that captured its range.
//  DestroyNow() is for code that is not iterating the unit.
//
//  Threading: update thread only (same rule as Scene::AddEntity / UpdateStart). Requests from the main thread
//  (events) go through your own queue, drained in OnUpdate.
//
//  Columns must be added before the first Create(), and after Scene::Init (they are sized to the scene).
//  Units may be added to the Scene at any time; their tables are created on first use.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	// Stable id of one entity. It stays valid while the entity lives, wherever its data is moved to.
	// id = unit (top 8 bits) | id inside the unit. gen separates a dead entity from a new one that reuses the id.
	struct Handle
	{
		uint32_t id = ~0u;
		uint32_t gen = 0;

		bool IsNull() const { return id == ~0u; }
		friend bool operator==(const Handle& a, const Handle& b) { return a.id == b.id && a.gen == b.gen; }
		friend bool operator!=(const Handle& a, const Handle& b) { return !(a == b); }
	};

	// A unit's live entities: slots [begin, begin + count)
	struct Range
	{
		uint32_t begin = 0;
		uint32_t count = 0;
	};

	// How a GPU / ISB column reaches the instance buffers
	enum class UploadMode
	{
		Always,     // the whole live range, every tick (nothing to declare)
		OnChange,   // only the blocks that were touched; writes through Data() must be declared with Touch...()
	};

	using UnitMask = uint32_t;                       // bit u = unit id u
	constexpr UnitMask AllUnits = ~0u;

	template<class T>
	struct Column
	{
		size_t index = (size_t)-1;
		bool IsValid() const { return index != (size_t)-1; }
	};

	template<class SceneT>
	class SceneStorage
	{
	public:
		using UpdateChache = typename SceneT::UpdateChache;
		static constexpr size_t npos = (size_t)-1;

		explicit SceneStorage(SceneT& scene) : m_Scene(scene) {}
		SceneStorage(const SceneStorage&) = delete;
		SceneStorage& operator=(const SceneStorage&) = delete;

		// ── columns ──────────────────────────────────────────────────────────

		// An array that is copied into the instance vertex buffer on Upload(). offsetInStruct = offsetof(IVB, member).
		// followsEntity = false: the values are NOT moved when an entity is removed or cleared on creation. Use it when
		// the game writes this column for every live entity each frame anyway (it saves the copies).
		// upload = UploadMode::OnChange: only touched blocks are copied (see the header comment). Note: with
		// followsEntity = false the column is not marked by create / move either, so Touch whatever you rebuild.
		template<class T>
		Column<T> AddGpuColumn(size_t offsetInStruct, bool followsEntity = true, UploadMode upload = UploadMode::Always)
		{ return AddColumn<T>(Target::Ivb, offsetInStruct, AllUnits, followsEntity, upload); }

		// An array that is copied into the instance storage buffer (SSBO) on Upload(); T is the InstanceStorageBufferData struct.
		template<class T>
		Column<T> AddIsbColumn(bool followsEntity = true, UploadMode upload = UploadMode::Always)
		{ return AddColumn<T>(Target::Isb, 0, AllUnits, followsEntity, upload); }

		// A plain array (velocity, hp, timers ...) that moves with the entities but is never uploaded.
		// `units` limits it to some units (MaskOf<A, B>()), the other units never touch it.
		template<class T>
		Column<T> AddCpuColumn(UnitMask units = AllUnits) { return AddColumn<T>(Target::Cpu, 0, units, true, UploadMode::Always); }

		// Mask of the given unit types (they must be added to the scene already).
		template<class... U>
		UnitMask MaskOf() const
		{
			UnitMask m = 0;
			((m |= UnitBit(m_Scene.template GetUnitId<U>())), ...);
			return m;
		}

		// The array itself, indexed by slot. Valid until the storage is destroyed (arrays never reallocate).
		template<class T>
		T* Data(Column<T> c) { return reinterpret_cast<T*>(m_Cols[c.index].mem.data()); }

		// ── create / destroy ─────────────────────────────────────────────────

		// Appends an entity to the unit. All its column values start at zero. Null handle when the unit is full.
		template<class U>
		Handle Create()
		{
			const int unit = m_Scene.template GetUnitId<U>();
			if (unit < 0)
			{
				LUNAR_ERROR("SceneStorage::Create: the unit was not added to the scene");
				return Handle{};
			}
			return CreateIn(unit);
		}

		Handle CreateIn(int unit)
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return Handle{};
			Unit& u = EnsureUnit(unit);
			if (!SetMode(u, unit, Mode::Tracked, "Create")) return Handle{};

			const size_t slot = m_Scene.PushEntity(unit);
			if (slot == npos) return Handle{};                       // unit is full

			const uint32_t id = u.freeIds.empty() ? u.nextId++ : PopFree(u);
			Entry& e = u.entries[id];
			e.slot = (uint32_t)slot;
			u.idOf[slot - u.start] = id;

			ZeroSlot(unit, slot);
			return Handle{ Pack(unit, id), e.gen };
		}

		// ── dense units (no handles) ─────────────────────────────────────────

		// Appends an entity to the unit and returns its slot (npos when full). All its column values start at zero.
		template<class U>
		size_t Append()
		{
			const int unit = m_Scene.template GetUnitId<U>();
			if (unit < 0)
			{
				LUNAR_ERROR("SceneStorage::Append: the unit was not added to the scene");
				return npos;
			}
			return AppendIn(unit);
		}

		size_t AppendIn(int unit)
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return npos;
			Unit& u = EnsureUnit(unit);
			if (!SetMode(u, unit, Mode::Dense, "Append")) return npos;
			const size_t slot = m_Scene.PushEntity(unit);
			if (slot == npos) return npos;
			ZeroSlot(unit, slot);
			return slot;
		}

		// Swap-remove the entity in `slot` right now: the unit's last entity takes its place. Works on dense AND tracked
		// units. Loop BACKWARDS over the unit when you remove inside the loop (the entity swapped in was already visited).
		bool RemoveAt(int unit, size_t slot)
		{
			if (unit < 0 || (size_t)unit >= m_Units.size() || !m_Units[unit].ready) return false;
			Unit& u = m_Units[unit];
			const size_t count = m_Scene.GetUnitEntityCount(unit);
			if (slot < u.start || slot >= u.start + count) return false;
			if (u.mode == Mode::Tracked) return DestroyNow(HandleAt(unit, slot));

			const size_t last = u.start + count - 1;
			if (slot != last) MoveSlot(unit, slot, last);
			m_Scene.PopEntity(unit);
			return true;
		}

		// Removes every entity of the unit. Handles of a tracked unit become stale (queued destroys of them are ignored).
		void ClearUnit(int unit)
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return;
			if ((size_t)unit < m_Units.size() && m_Units[unit].ready && m_Units[unit].mode == Mode::Tracked)
			{
				Unit& u = m_Units[unit];
				const size_t count = m_Scene.GetUnitEntityCount(unit);
				for (size_t s = u.start; s < u.start + count; ++s)
				{
					const uint32_t id = u.idOf[s - u.start];
					Entry& e = u.entries[id];
					e.slot = kNone; e.gen++;
					u.freeIds.push_back(id);
				}
			}
			m_Scene.ResetUnit(unit);
		}

		template<class U>
		void Clear() { ClearUnit(m_Scene.template GetUnitId<U>()); }

		// Queued: the entity stays alive until Flush(). Safe inside a loop over the unit. A stale / null handle is ignored.
		void Destroy(Handle h)
		{
			if (!h.IsNull()) m_Queue.push_back(h);
		}

		// Applies the queued destroys (swap-remove each). Call once per tick, after the systems ran.
		void Flush()
		{
			for (const Handle& h : m_Queue) DestroyNow(h);
			m_Queue.clear();
		}

		// Swap-remove right now: the unit's last entity takes this slot. Do not call it while looping over that unit.
		// False when the handle is stale or null.
		bool DestroyNow(Handle h)
		{
			Unit* up = FindUnitOf(h);
			if (!up) return false;
			Unit& u = *up;
			const int unit = UnitOf(h.id);
			Entry& e = u.entries[LocalId(h.id)];
			if (e.slot == kNone || e.gen != h.gen) return false;

			const size_t count = m_Scene.GetUnitEntityCount(unit);
			const size_t hole = e.slot;
			const size_t last = u.start + count - 1;

			if (hole != last)
			{
				MoveSlot(unit, hole, last);                           // last -> hole, every column of this unit
				const uint32_t moved = u.idOf[last - u.start];
				u.idOf[hole - u.start] = moved;
				u.entries[moved].slot = (uint32_t)hole;
			}

			e.slot = kNone;
			e.gen++;
			u.freeIds.push_back(LocalId(h.id));
			m_Scene.PopEntity(unit);
			return true;
		}

		// ── lookup ───────────────────────────────────────────────────────────

		bool IsAlive(Handle h) const
		{
			const Unit* u = FindUnitOf(h);
			if (!u) return false;
			const Entry& e = u->entries[LocalId(h.id)];
			return e.slot != kNone && e.gen == h.gen;
		}

		// Slot of the entity (index into the column arrays), npos when the handle is stale or null.
		size_t SlotOf(Handle h) const
		{
			const Unit* u = FindUnitOf(h);
			if (!u) return npos;
			const Entry& e = u->entries[LocalId(h.id)];
			return (e.slot != kNone && e.gen == h.gen) ? e.slot : npos;
		}

		// The element of this entity, nullptr when the handle is stale. Costs one table lookup; loops use Data() + slots.
		template<class T>
		T* Get(Column<T> c, Handle h)
		{
			const size_t slot = SlotOf(h);
			return slot == npos ? nullptr : Data(c) + slot;
		}

		// The handle of the entity that lives in `slot` of `unit` (for loops that decide to destroy slot i).
		Handle HandleAt(int unit, size_t slot) const
		{
			if (unit < 0 || (size_t)unit >= m_Units.size() || !m_Units[unit].ready) return Handle{};
			const Unit& u = m_Units[unit];
			if (u.mode != Mode::Tracked) return Handle{};            // dense units have no handles
			if (slot < u.start || slot >= u.start + m_Scene.GetUnitEntityCount(unit)) return Handle{};
			const uint32_t id = u.idOf[slot - u.start];
			return Handle{ Pack(unit, id), u.entries[id].gen };
		}

		// ── ranges ───────────────────────────────────────────────────────────

		// Live entities of a unit as slots [begin, begin + count). Units are independent: one range per unit.
		Range RangeOfUnit(int unit) const
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return Range{};
			return Range{ (uint32_t)m_Scene.GetSegment(unit).start, (uint32_t)m_Scene.GetUnitEntityCount(unit) };
		}

		template<class U>
		Range RangeOf() const { return RangeOfUnit(m_Scene.template GetUnitId<U>()); }

		template<class U>
		int UnitId() const { return m_Scene.template GetUnitId<U>(); }

		size_t UnitCount() const { return m_Scene.GetUnits(); }

		// ── declaring writes (UploadMode::OnChange columns; ignored by Always columns) ──────────────

		// Everything live in every unit may have changed.
		template<class T>
		void Touch(Column<T> c)
		{
			for (size_t unit = 0; unit < m_Scene.GetUnits(); ++unit) TouchUnit(c, (int)unit);
		}

		// Everything live in one unit may have changed.
		template<class T>
		void TouchUnit(Column<T> c, int unit)
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return;
			MarkRel(m_Cols[c.index], unit, 0, m_Scene.GetUnitEntityCount(unit));
		}

		// `count` entities starting at global slot `firstSlot` of the unit may have changed.
		template<class T>
		void TouchRange(Column<T> c, int unit, size_t firstSlot, size_t count)
		{
			if (unit < 0 || (size_t)unit >= m_Scene.GetUnits()) return;
			const size_t start = m_Scene.GetSegment(unit).start;
			if (firstSlot < start) return;
			MarkRel(m_Cols[c.index], unit, firstSlot - start, firstSlot - start + count);
		}

		template<class T>
		void TouchAt(Column<T> c, int unit, size_t slot) { TouchRange(c, unit, slot, 1); }

		// The entity of this handle (nothing when the handle is stale).
		template<class T>
		void Touch(Column<T> c, Handle h)
		{
			const size_t slot = SlotOf(h);
			if (slot != npos) TouchAt(c, UnitOf(h.id), slot);
		}

		// ── upload bookkeeping ───────────────────────────────────────────────

		// Bytes copied into the instance buffers by the last Upload() (columns only).
		size_t LastUploadBytes() const { return m_LastUploadBytes; }

		// Debug: keep a shadow copy of what each frame slot holds and check every block an OnChange column skips.
		// A skipped block that differs from the CPU array means a write was not declared with Touch. Costs O(live) per tick.
		void SetVerifyUploads(bool on) { m_Verify = on; }
		size_t UploadViolations() const { return m_Violations; }

		// ── upload ───────────────────────────────────────────────────────────

		// Update thread, between the gate's UpdateStart / UpdateEnd. Copies the live range of every unit, one memcpy
		// per (unit, GPU column), and the draw commands (their instance counts changed with Create / Flush).
		// OnChange columns copy only their touched blocks.
		void Upload(UpdateChache* slot)
		{
			if (!slot) return;
			m_LastUploadBytes = 0;
			const int ring = slot->frameNo;
			const size_t units = m_Scene.GetUnits();
			for (size_t unit = 0; unit < units; unit++)
			{
				const size_t count = m_Scene.GetUnitEntityCount((int)unit);
				if (count == 0) continue;
				const size_t start = m_Scene.GetSegment((int)unit).start;

				for (Col& c : m_Cols)
				{
					if (c.target == Target::Cpu) continue;
					if (c.upload == UploadMode::OnChange) { UploadDirty(slot, ring, (int)unit, start, count, c); continue; }
					CopyToSlot(slot, c, (int)unit, start, count);
				}
			}
			m_Scene.UpdateIndirectDrawCommands(slot);
		}

	private:
		static constexpr uint32_t kNone = ~0u;
		static constexpr int kRing = SceneT::RingSize;
		static constexpr int kMaxUnits = 32;
		static constexpr size_t kBlockShift = 6;             // 64 entities per dirty bit
		enum class Target { Cpu, Ivb, Isb };
		enum class Mode { Unset, Tracked, Dense };

		struct Col
		{
			std::vector<std::byte> mem;      // capacity * size bytes, zeroed
			size_t size = 0;
			Target target = Target::Cpu;
			size_t gpuOffset = 0;            // offsetof(IVB, member), Ivb columns only
			UnitMask units = AllUnits;       // the units that use this column
			bool follows = true;             // moved / zeroed with the entity
			UploadMode upload = UploadMode::Always;
			// OnChange only: [ring slot][unit] -> one bit per block of 64 entities of the unit that must be copied into that slot
			std::vector<uint64_t> dirty[kRing][kMaxUnits];
			std::vector<std::byte> shadow[kRing];   // verify mode: what that frame slot holds
		};

		struct Entry { uint32_t slot = kNone; uint32_t gen = 0; };   // indexed by id

		struct Unit
		{
			bool ready = false;
			Mode mode = Mode::Unset;
			size_t start = 0;
			std::vector<Entry> entries;      // id   -> slot + generation
			std::vector<uint32_t> idOf;      // slot - start -> id
			std::vector<uint32_t> freeIds;
			uint32_t nextId = 0;
			std::vector<uint32_t> active;    // columns that follow this unit's entities (moved / zeroed), built on first use
			bool activeValid = false;
		};

		template<class T>
		Column<T> AddColumn(Target target, size_t gpuOffset, UnitMask units, bool follows, UploadMode upload)
		{
			static_assert(std::is_trivially_copyable_v<T>, "column elements are moved with memcpy");
			const size_t cap = m_Scene.GetTotalEntityCap();
			if (cap == 0)
			{
				LUNAR_ERROR("SceneStorage::AddColumn: the scene is not initialised yet (call Scene::Init first)");
				return Column<T>{};
			}
			for (size_t unit = 0; unit < m_Scene.GetUnits(); unit++)
				if (m_Scene.GetUnitEntityCount((int)unit) != 0)
				{
					LUNAR_ERROR("SceneStorage::AddColumn: columns must be added before the first entity exists");
					return Column<T>{};
				}
			Col c;
			c.size = sizeof(T);
			c.target = target;
			c.gpuOffset = gpuOffset;
			c.units = units;
			c.follows = follows;
			c.upload = upload;
			c.mem.assign(cap * sizeof(T), std::byte{ 0 });
			m_Cols.push_back(std::move(c));
			for (Unit& u : m_Units) u.activeValid = false;
			return Column<T>{ m_Cols.size() - 1 };
		}

		Unit& EnsureUnit(int unit)
		{
			if ((size_t)unit >= m_Units.size()) m_Units.resize((size_t)unit + 1);
			Unit& u = m_Units[unit];
			if (!u.ready)
			{
				const UnitSegment& seg = m_Scene.GetSegment(unit);
				u.start = seg.start;
				u.ready = true;
			}
			return u;
		}

		// The first Create / Append decides how the unit is held; the other way is refused afterwards.
		bool SetMode(Unit& u, int unit, Mode wanted, const char* what)
		{
			if (u.mode == wanted) return true;
			if (u.mode != Mode::Unset)
			{
				LUNAR_ERROR("SceneStorage::" << what << ": this unit is already used the other way (tracked Create/Destroy vs dense Append/RemoveAt)");
				return false;
			}
			u.mode = wanted;
			if (wanted == Mode::Tracked)                           // handle tables only for tracked units
			{
				const size_t capacity = m_Scene.GetSegment(unit).capacity;
				u.entries.assign(capacity, Entry{});
				u.idOf.assign(capacity, 0);
				u.freeIds.reserve(capacity);
			}
			return true;
		}

		static UnitMask UnitBit(int unit) { return unit >= 0 && unit < 32 ? (UnitMask(1) << unit) : 0; }

		const std::vector<uint32_t>& ActiveColumns(int unit)
		{
			Unit& u = m_Units[unit];
			if (!u.activeValid)
			{
				const UnitMask bit = UnitBit(unit);
				u.active.clear();
				for (size_t i = 0; i < m_Cols.size(); ++i)
					if (m_Cols[i].follows && (m_Cols[i].units & bit)) u.active.push_back((uint32_t)i);
				u.activeValid = true;
			}
			return u.active;
		}

		void MoveSlot(int unit, size_t dst, size_t src)
		{
			const size_t rel = dst - m_Units[unit].start;
			for (uint32_t ci : ActiveColumns(unit))
			{
				Col& c = m_Cols[ci];
				CopyElem(c, dst, src);
				if (c.upload == UploadMode::OnChange) MarkRel(c, unit, rel, rel + 1);
			}
		}

		void ZeroSlot(int unit, size_t slot)
		{
			const size_t rel = slot - m_Units[unit].start;
			for (uint32_t ci : ActiveColumns(unit))
			{
				Col& c = m_Cols[ci];
				ZeroElem(c, slot);
				if (c.upload == UploadMode::OnChange) MarkRel(c, unit, rel, rel + 1);
			}
		}

		// ── dirty blocks ─────────────────────────────────────────────────────

		size_t DirtyWords(int unit) const
		{
			const size_t blocks = (m_Scene.GetSegment(unit).capacity + 63) >> kBlockShift;
			return (blocks + 63) >> 6;
		}

		// Sets bits b0..b1 (inclusive)
		static void SetBits(std::vector<uint64_t>& v, size_t b0, size_t b1)
		{
			const size_t w0 = b0 >> 6, w1 = b1 >> 6;
			const uint64_t m0 = ~0ull << (b0 & 63);
			const uint64_t m1 = (b1 & 63) == 63 ? ~0ull : ((1ull << ((b1 & 63) + 1)) - 1);
			if (w0 == w1) { v[w0] |= (m0 & m1); return; }
			v[w0] |= m0;
			for (size_t w = w0 + 1; w < w1; ++w) v[w] = ~0ull;
			v[w1] |= m1;
		}

		// Entities [relBegin, relEnd) of the unit (relative to its start) must be copied into EVERY frame slot.
		void MarkRel(Col& c, int unit, size_t relBegin, size_t relEnd)
		{
			if (c.upload != UploadMode::OnChange || relEnd <= relBegin || unit >= kMaxUnits) return;
			const size_t capacity = m_Scene.GetSegment(unit).capacity;
			if (relBegin >= capacity) return;
			if (relEnd > capacity) relEnd = capacity;
			const size_t words = DirtyWords(unit);
			const size_t b0 = relBegin >> kBlockShift, b1 = (relEnd - 1) >> kBlockShift;
			for (int r = 0; r < kRing; ++r)
			{
				std::vector<uint64_t>& v = c.dirty[r][unit];
				if (v.size() != words) v.assign(words, 0);
				SetBits(v, b0, b1);
			}
		}

		void CopyToSlot(UpdateChache* slot, Col& c, int unit, size_t firstSlot, size_t n)
		{
			(void)unit;
			std::byte* src = c.mem.data() + firstSlot * c.size;
			if (c.target == Target::Ivb) m_Scene.UpdateIBVelementSlots(slot, c.gpuOffset, c.size, firstSlot, n, src);
			else                         m_Scene.UpdateISB(slot, firstSlot * c.size, n * c.size, src);
			m_LastUploadBytes += n * c.size;
		}

		void UploadDirty(UpdateChache* slot, int ring, int unit, size_t start, size_t count, Col& c)
		{
			if (unit >= kMaxUnits) { CopyToSlot(slot, c, unit, start, count); return; }
			std::vector<uint64_t>& bits = c.dirty[ring][unit];
			if (bits.empty()) bits.assign(DirtyWords(unit), 0);
			if (m_Verify) VerifyClean(c, ring, start, count, bits);

			const size_t blocks = (count + 63) >> kBlockShift;
			size_t b = 0;
			while (b < blocks)
			{
				const uint64_t word = bits[b >> 6] >> (b & 63);
				if (word == 0) { b = ((b >> 6) + 1) << 6; continue; }
				b += (size_t)std::countr_zero(word);
				if (b >= blocks) break;
				size_t e = b;                                        // end of this run of dirty blocks
				while (e < blocks && ((bits[e >> 6] >> (e & 63)) & 1)) ++e;
				const size_t relBegin = b << kBlockShift;
				const size_t relEnd = std::min(e << kBlockShift, count);
				CopyToSlot(slot, c, unit, start + relBegin, relEnd - relBegin);
				if (m_Verify)
					std::memcpy(c.shadow[ring].data() + (start + relBegin) * c.size, c.mem.data() + (start + relBegin) * c.size, (relEnd - relBegin) * c.size);
				b = e;
			}
			std::fill(bits.begin(), bits.end(), 0);
		}

		// verify mode: every live entity in a block that is NOT going to be copied must equal what the slot already holds
		void VerifyClean(Col& c, int ring, size_t start, size_t count, const std::vector<uint64_t>& bits)
		{
			std::vector<std::byte>& sh = c.shadow[ring];
			if (sh.empty()) sh.assign(m_Scene.GetTotalEntityCap() * c.size, std::byte{ 0 });
			for (size_t rel = 0; rel < count; ++rel)
			{
				const size_t blk = rel >> kBlockShift;
				if ((bits[blk >> 6] >> (blk & 63)) & 1) continue;            // dirty: will be copied
				const size_t off = (start + rel) * c.size;
				if (std::memcmp(c.mem.data() + off, sh.data() + off, c.size) != 0)
				{
					if (m_Violations++ == 0)
						LUNAR_ERROR("SceneStorage: an UploadMode::OnChange column was written without Touch (slot " << (start + rel) << ")");
				}
			}
		}

		static uint32_t PopFree(Unit& u) { const uint32_t id = u.freeIds.back(); u.freeIds.pop_back(); return id; }
		static uint32_t Pack(int unit, uint32_t id) { return ((uint32_t)unit << 24) | id; }
		static int UnitOf(uint32_t packed) { return (int)(packed >> 24); }
		static uint32_t LocalId(uint32_t packed) { return packed & 0x00FFFFFFu; }

		Unit* FindUnitOf(Handle h) { return const_cast<Unit*>(static_cast<const SceneStorage*>(this)->FindUnitOf(h)); }
		const Unit* FindUnitOf(Handle h) const
		{
			if (h.IsNull()) return nullptr;
			const int unit = UnitOf(h.id);
			if ((size_t)unit >= m_Units.size() || !m_Units[unit].ready) return nullptr;
			const Unit& u = m_Units[unit];
			return LocalId(h.id) < u.entries.size() ? &u : nullptr;
		}

		// element copy / clear with a compile-time size for the common element sizes
		static void CopyElem(Col& c, size_t dst, size_t src)
		{
			std::byte* d = c.mem.data() + dst * c.size;
			const std::byte* s = c.mem.data() + src * c.size;
			switch (c.size)
			{
			case 4:  std::memcpy(d, s, 4);  break;
			case 8:  std::memcpy(d, s, 8);  break;
			case 12: std::memcpy(d, s, 12); break;
			case 16: std::memcpy(d, s, 16); break;
			case 32: std::memcpy(d, s, 32); break;
			case 64: std::memcpy(d, s, 64); break;
			default: std::memcpy(d, s, c.size); break;
			}
		}

		static void ZeroElem(Col& c, size_t slot)
		{
			std::memset(c.mem.data() + slot * c.size, 0, c.size);
		}

		SceneT& m_Scene;
		std::vector<Col> m_Cols;
		std::vector<Unit> m_Units;
		std::vector<Handle> m_Queue;
		size_t m_LastUploadBytes = 0;
		bool m_Verify = false;
		size_t m_Violations = 0;
	};
}
