#verson 460 core


// per vertex attributes | passed from the vertex buffer
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aCol;
layout(location = 2) in vec3 aNor;
layout(location = 3) in vec3 aLor; 


// per instance attributes | passted from the instance buffer
layout(location = 4) in vec3 aPos;
layout(location = 5) in vec3 aCol;
layout(location = 6) in vec3 aNor;
layout(location = 7) in vec3 aLor;



layout(std140, binding = 0) uniform ubo 
{
	mat4 model;
	mat4 view;
	mat4 projection;
} ubo;


struct MorePerInstaceData
{
	vec3 pos;
	vec3 col;
	vec3 nor;
	vec3 lor;
};


layout(std140, binding = 1) readonly buffer instanceSSBO
{
	MorePerInstaceData moreData[];
} ssbo1;



layout(std140, binding = 2) uniform ubo2
{
	MorePerInstaceData moreData[];
} ssbo2;

flat out uint vEntityIndex;

main()
{
	vEntityIndex = gl_InstanceID;
};



