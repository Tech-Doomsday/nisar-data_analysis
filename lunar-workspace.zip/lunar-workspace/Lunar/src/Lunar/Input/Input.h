#pragma once
#include <bitset>
#include <cstdint>
#include <variant>
#include <vector>

#include <glm/glm.hpp>

#include "KeyCodes.h"
#include "../Event/Events.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Input  -  per-tick input snapshot, owned by the update thread.
//
//  The application feeds it once at the start of every update tick, from the
//  events the main thread relayed (see InputRelay). Everything here is plain
//  data read by one thread: no atomics, no locks.
//
//      void OnUpdate(const UpdateContext& ctx) override
//      {
//          if (ctx.input.Pressed(Key::Space))   Fire();          // edge: went down this tick
//          if (ctx.input.Down(Key::A))          MoveLeft(ctx.dt); // level: is held right now
//          glm::dvec2 d = ctx.input.MouseDelta();
//      }
//
//  Pressed() / Released() are true for the tick in which the event happened, even
//  when the key went down AND up again inside that same tick (a quick tap is not
//  lost, which a "bit is set while held" mask cannot guarantee).
//
//  Mouse position is in window coordinates, origin top-left, y down (GLFW's).
//  WindowMetrics::CursorToFramebuffer() converts it to framebuffer pixels, y up.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	using InputEvent = std::variant<
		events::KeyPressed, events::KeyReleased, events::KeyTyped,
		events::MouseMoved, events::MouseButtonPressed, events::MouseButtonReleased, events::MouseScrolled,
		events::WindowFocus>;

	class Input
	{
	public:
		// ── queries ──────────────────────────────────────────────────────────
		bool Down(Key k) const { return Test(m_KeyDown, k); }
		bool Pressed(Key k) const { return Test(m_KeyPressed, k); }
		bool Released(Key k) const { return Test(m_KeyReleased, k); }

		bool Down(MouseButton b) const { return Test(m_BtnDown, b); }
		bool Pressed(MouseButton b) const { return Test(m_BtnPressed, b); }
		bool Released(MouseButton b) const { return Test(m_BtnReleased, b); }

		bool AnyDown() const { return m_KeyDown.any() || m_BtnDown.any(); }

		glm::dvec2 MousePosition() const { return m_MousePos; }
		glm::dvec2 MouseDelta() const { return m_MouseDelta; }      // moved during this tick
		glm::dvec2 Scroll() const { return m_Scroll; }              // scrolled during this tick
		const std::vector<uint32_t>& Typed() const { return m_Typed; }   // text typed during this tick
		bool HasFocus() const { return m_Focused; }

		// ── engine side ──────────────────────────────────────────────────────
		void BeginTick()
		{
			m_KeyPressed.reset(); m_KeyReleased.reset();
			m_BtnPressed.reset(); m_BtnReleased.reset();
			m_MouseDelta = glm::dvec2(0.0);
			m_Scroll = glm::dvec2(0.0);
			m_Typed.clear();
		}

		void Apply(const InputEvent& ev)
		{
			std::visit([this](const auto& e) { Apply(e); }, ev);
		}

		void Apply(const events::KeyPressed& e)
		{
			if (e.repeat) return;                    // auto-repeat is for text (KeyTyped), not for game input
			const size_t i = static_cast<size_t>(e.key);
			if (i >= KeyCount || m_KeyDown[i]) return;
			m_KeyDown.set(i); m_KeyPressed.set(i);
		}

		void Apply(const events::KeyReleased& e)
		{
			const size_t i = static_cast<size_t>(e.key);
			if (i >= KeyCount || !m_KeyDown[i]) return;   // release of a key we never saw go down
			m_KeyDown.reset(i); m_KeyReleased.set(i);
		}

		void Apply(const events::MouseButtonPressed& e)
		{
			const size_t i = static_cast<size_t>(e.button);
			if (i >= MouseButtonCount || m_BtnDown[i]) return;
			m_BtnDown.set(i); m_BtnPressed.set(i);
		}

		void Apply(const events::MouseButtonReleased& e)
		{
			const size_t i = static_cast<size_t>(e.button);
			if (i >= MouseButtonCount || !m_BtnDown[i]) return;
			m_BtnDown.reset(i); m_BtnReleased.set(i);
		}

		void Apply(const events::MouseMoved& e)
		{
			m_MousePos = { e.x, e.y };
			m_MouseDelta += glm::dvec2(e.dx, e.dy);
		}

		void Apply(const events::MouseScrolled& e) { m_Scroll += glm::dvec2(e.xOffset, e.yOffset); }
		void Apply(const events::KeyTyped& e) { m_Typed.push_back(e.codepoint); }

		void Apply(const events::WindowFocus& e)
		{
			m_Focused = e.focused;
			if (!e.focused) ReleaseAll();            // the release events go to the window that took focus
		}

		// Everything that is held is let go (and reported as Released this tick).
		void ReleaseAll()
		{
			m_KeyReleased |= m_KeyDown;
			m_BtnReleased |= m_BtnDown;
			m_KeyDown.reset();
			m_BtnDown.reset();
		}

	private:
		template<size_t N, class K>
		static bool Test(const std::bitset<N>& bits, K k)
		{
			const size_t i = static_cast<size_t>(k);
			return i < N && bits[i];
		}

		std::bitset<KeyCount> m_KeyDown, m_KeyPressed, m_KeyReleased;
		std::bitset<MouseButtonCount> m_BtnDown, m_BtnPressed, m_BtnReleased;
		glm::dvec2 m_MousePos{ 0.0 }, m_MouseDelta{ 0.0 }, m_Scroll{ 0.0 };
		std::vector<uint32_t> m_Typed;
		bool m_Focused = true;
	};
}
