#pragma once
#include <atomic>
#include <cstdint>
#include <type_traits>

#include "Input.h"
#include "../Event/EventQueue.h"

// ─────────────────────────────────────────────────────────────────────────────
//  InputRelay  -  main thread  ->  update thread
//
//  The main thread offers every input event after the EventBus has seen it,
//  together with whether a listener consumed it. The update thread drains the
//  queue into its Input snapshot at the start of a tick.
//
//  Consumption rules (so a UI layer on the main thread can "own" the mouse):
//    consumed press / typed / scroll   -> the game never sees it
//    releases and focus changes        -> always relayed (so nothing gets stuck down)
//    mouse motion                      -> always relayed (the position is state, not an action)
//
//  Mouse motion and scroll are coalesced per frame (Flush), so a 1000 Hz mouse
//  cannot flood the queue. If the queue ever does overflow, the next Drain
//  releases everything that is held instead of trusting a half-seen state.
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	class InputRelay
	{
	public:
		// main thread ─────────────────────────────────────────────────────────
		template<class E>
		void Offer(const E& e, bool consumed)
		{
			using namespace events;
			if constexpr (std::is_same_v<E, MouseMoved>)
			{
				if (!m_HasMove) m_Move = e;
				else { m_Move.x = e.x; m_Move.y = e.y; m_Move.dx += e.dx; m_Move.dy += e.dy; }
				m_HasMove = true;
			}
			else if constexpr (std::is_same_v<E, MouseScrolled>)
			{
				if (consumed) return;
				if (!m_HasScroll) m_Scroll = e;
				else { m_Scroll.xOffset += e.xOffset; m_Scroll.yOffset += e.yOffset; }
				m_HasScroll = true;
			}
			else if constexpr (std::is_same_v<E, KeyReleased> || std::is_same_v<E, WindowFocus>)
			{
				FlushPending();
				Push(InputEvent{ e });
			}
			else if constexpr (std::is_same_v<E, MouseButtonReleased>)
			{
				FlushPending();                      // keep the click position right
				Push(InputEvent{ e });
			}
			else if constexpr (std::is_same_v<E, KeyPressed> || std::is_same_v<E, KeyTyped> || std::is_same_v<E, MouseButtonPressed>)
			{
				if (consumed) return;
				FlushPending();
				Push(InputEvent{ e });
			}
			// every other event type is not input: ignored
		}

		// end of the frame's event polling
		void Flush() { FlushPending(); }

		// update thread ───────────────────────────────────────────────────────
		void Drain(Input& input)
		{
			input.BeginTick();
			InputEvent ev;
			while (m_Queue.TryPop(ev)) input.Apply(ev);
			if (m_Overflow.exchange(false, std::memory_order_acq_rel)) input.ReleaseAll();
		}

		uint64_t Dropped() const { return m_Dropped.load(std::memory_order_relaxed); }

	private:
		void FlushPending()
		{
			if (m_HasMove) { Push(InputEvent{ m_Move }); m_HasMove = false; }
			if (m_HasScroll) { Push(InputEvent{ m_Scroll }); m_HasScroll = false; }
		}

		void Push(InputEvent ev)
		{
			if (!m_Queue.TryPush(std::move(ev)))
			{
				m_Dropped.fetch_add(1, std::memory_order_relaxed);
				m_Overflow.store(true, std::memory_order_release);
			}
		}

		SpscQueue<InputEvent, 4096> m_Queue;
		events::MouseMoved m_Move{};
		events::MouseScrolled m_Scroll{};
		bool m_HasMove = false, m_HasScroll = false;     // main thread only

		std::atomic<bool> m_Overflow{ false };
		std::atomic<uint64_t> m_Dropped{ 0 };
	};
}
