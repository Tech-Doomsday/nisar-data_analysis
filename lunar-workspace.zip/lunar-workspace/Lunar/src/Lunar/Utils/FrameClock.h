#pragma once
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <thread>

// ─────────────────────────────────────────────────────────────────────────────
//  FrameClock / FpsCounter / Backoff
//
//  FrameClock replaces Lenz::Timestep. Differences:
//    * one instance per loop (render loop, update loop). Lenz kept the time in
//      statics shared by everything, which cannot work with two threads
//    * double precision total time, steady_clock instead of glfwGetTime
//    * the first Tick() after Reset() returns 0 (Lenz returned "time since
//      glfwInit" as the first delta, i.e. the whole load time)
//    * delta is clamped to maxDelta (a debugger pause or a window drag does not
//      become a 3 second simulation step)
// ─────────────────────────────────────────────────────────────────────────────

namespace lunar
{
	class FrameClock
	{
		using Clock = std::chrono::steady_clock;

	public:
		explicit FrameClock(float maxDelta = 0.05f) : m_MaxDelta(maxDelta) { Reset(); }

		void Reset()
		{
			m_Last = Clock::now();
			m_Delta = 0.0f;
			m_Time = 0.0;
			m_Ticks = 0;
			m_First = true;
		}

		// call once per frame / tick; returns the (clamped) delta in seconds
		float Tick()
		{
			const auto now = Clock::now();
			const float raw = m_First ? 0.0f : std::chrono::duration<float>(now - m_Last).count();
			m_First = false;
			m_Last = now;
			m_Delta = (m_MaxDelta > 0.0f) ? (std::min)(raw, m_MaxDelta) : raw;
			m_Time += m_Delta;
			++m_Ticks;
			return m_Delta;
		}

		float Delta() const { return m_Delta; }
		double Time() const { return m_Time; }          // sum of the (clamped) deltas
		uint64_t Ticks() const { return m_Ticks; }
		void SetMaxDelta(float d) { m_MaxDelta = d; }

	private:
		Clock::time_point m_Last;
		float m_MaxDelta;
		float m_Delta = 0.0f;
		double m_Time = 0.0;
		uint64_t m_Ticks = 0;
		bool m_First = true;
	};


	// frames per second, refreshed every `interval` seconds
	class FpsCounter
	{
		using Clock = std::chrono::steady_clock;

	public:
		explicit FpsCounter(double interval = 0.5) : m_Interval(interval), m_Start(Clock::now()) {}

		void Frame() { ++m_Frames; }

		// true when a new value was produced
		bool Update()
		{
			const auto now = Clock::now();
			const double el = std::chrono::duration<double>(now - m_Start).count();
			if (el < m_Interval) return false;
			m_Fps = m_Frames / el;
			m_Frames = 0;
			m_Start = now;
			return true;
		}

		double Fps() const { return m_Fps; }

	private:
		double m_Interval;
		Clock::time_point m_Start;
		uint32_t m_Frames = 0;
		double m_Fps = 0.0;
	};


	// What a loop does while it has nothing to do (no free frame slot / nothing to draw):
	// give the CPU away a little more with every consecutive miss.
	class Backoff
	{
	public:
		void Reset() { m_Misses = 0; }

		void Pause()
		{
			++m_Misses;
			if (m_Misses < 64) std::this_thread::yield();
			else std::this_thread::sleep_for(std::chrono::microseconds(100));
		}

	private:
		uint32_t m_Misses = 0;
	};
}
