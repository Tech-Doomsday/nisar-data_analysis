#include "Log.h"

#include <atomic>
#include <memory>
#include <mutex>

#include <plog/Appenders/ColorConsoleAppender.h>
#include <plog/Formatters/TxtFormatter.h>
#include <plog/Initializers/RollingFileInitializer.h>

namespace lunar
{
	namespace
	{
		std::mutex g_Mutex;
		std::atomic<bool> g_Initialized{ false };
		std::unique_ptr<plog::RollingFileAppender<plog::TxtFormatter>> g_File;
		std::unique_ptr<plog::ColorConsoleAppender<plog::TxtFormatter>> g_Console;

		plog::Severity ToPlog(LogLevel l)
		{
			switch (l)
			{
			case LogLevel::Trace: return plog::verbose;
			case LogLevel::Debug: return plog::debug;
			case LogLevel::Info:  return plog::info;
			case LogLevel::Warn:  return plog::warning;
			case LogLevel::Error: return plog::error;
			case LogLevel::Fatal: return plog::fatal;
			default:              return plog::none;
			}
		}
	}

	void Log::Init(const LogConfig& config)
	{
		std::lock_guard<std::mutex> lock(g_Mutex);

		if (g_Initialized.load())
		{
			if (auto* logger = plog::get()) logger->setMaxSeverity(ToPlog(config.level));
			return;
		}

		plog::Logger<PLOG_DEFAULT_INSTANCE_ID>& logger = plog::init(ToPlog(config.level));

		if (config.file)
		{
			const std::string path = config.directory.empty() ? config.fileName : config.directory + "/" + config.fileName;
			g_File = std::make_unique<plog::RollingFileAppender<plog::TxtFormatter>>(path.c_str(), config.maxFileSize, config.maxFiles);
			logger.addAppender(g_File.get());
		}
		if (config.console)
		{
			g_Console = std::make_unique<plog::ColorConsoleAppender<plog::TxtFormatter>>();
			logger.addAppender(g_Console.get());
		}

		g_Initialized.store(true);
	}

	void Log::SetLevel(LogLevel level)
	{
		if (auto* logger = plog::get()) logger->setMaxSeverity(ToPlog(level));
	}

	bool Log::IsInitialized()
	{
		return g_Initialized.load(std::memory_order_acquire);
	}
}
