#pragma once
#include <cstddef>
#include <cstdlib>
#include <string>

#include <plog/Log.h>

// ─────────────────────────────────────────────────────────────────────────────
//  Logging  (plog under the hood, like Lenz)
//
//    LN_TRACE / LN_DEBUG / LN_INFO / LN_WARN / LN_ERROR / LN_FATAL(<< stream expression)
//    LN_ASSERT(cond)  /  LN_ASSERT_MSG(cond, "text" << value)       (debug builds only)
//
//  Differences to Lenz/Log.h
//    * macros do not end in ';' (so `if (x) LN_INFO("a"); else ...` compiles)
//    * no collision between the "debug build" switch and a log macro: the switch
//      is LUNAR_DEBUG (defined when NDEBUG is not), the macro is LN_DEBUG
//    * one assert definition, and it is compiled out in release
//    * safe before Log::Init(): the first log call initialises with defaults
//
//  The old LUNAR_LOG / LUNAR_WARN / LUNAR_ERROR macros of Core.h are untouched.
// ─────────────────────────────────────────────────────────────────────────────

#if !defined(NDEBUG)
	#define LUNAR_DEBUG 1
#endif

namespace lunar
{
	enum class LogLevel { Trace, Debug, Info, Warn, Error, Fatal, None };

	struct LogConfig
	{
#ifdef LUNAR_DEBUG
		LogLevel level = LogLevel::Debug;
#else
		LogLevel level = LogLevel::Info;
#endif
		bool console = true;
		bool file = true;
		std::string directory = "logs";
		std::string fileName = "lunar.log";
		size_t maxFileSize = 10 * 1024 * 1024;
		int maxFiles = 5;
	};

	class Log
	{
	public:
		// Only the first call configures the appenders; later calls only change the level.
		static void Init(const LogConfig& config = LogConfig{});
		static void SetLevel(LogLevel level);
		static bool IsInitialized();

		// called by the macros
		static void Ensure() { if (!IsInitialized()) Init(); }
	};
}

#define LN_TRACE(...)  do { ::lunar::Log::Ensure(); PLOG_VERBOSE << __VA_ARGS__; } while (0)
#define LN_DEBUG(...)  do { ::lunar::Log::Ensure(); PLOG_DEBUG   << __VA_ARGS__; } while (0)
#define LN_INFO(...)   do { ::lunar::Log::Ensure(); PLOG_INFO    << __VA_ARGS__; } while (0)
#define LN_WARN(...)   do { ::lunar::Log::Ensure(); PLOG_WARNING << __VA_ARGS__; } while (0)
#define LN_ERROR(...)  do { ::lunar::Log::Ensure(); PLOG_ERROR   << __VA_ARGS__; } while (0)
#define LN_FATAL(...)  do { ::lunar::Log::Ensure(); PLOG_FATAL   << __VA_ARGS__; } while (0)

#if defined(_MSC_VER)
	#define LN_DEBUGBREAK() __debugbreak()
#elif defined(__GNUC__) || defined(__clang__)
	#define LN_DEBUGBREAK() __builtin_trap()
#else
	#define LN_DEBUGBREAK() std::abort()
#endif

#ifdef LUNAR_DEBUG
	#define LN_ASSERT(cond)           do { if (!(cond)) { LN_FATAL("Assertion failed: " #cond); LN_DEBUGBREAK(); } } while (0)
	#define LN_ASSERT_MSG(cond, ...)  do { if (!(cond)) { LN_FATAL("Assertion failed: " #cond " - " << __VA_ARGS__); LN_DEBUGBREAK(); } } while (0)
#else
	#define LN_ASSERT(cond)           do { } while (0)
	#define LN_ASSERT_MSG(cond, ...)  do { } while (0)
#endif
