#include "Storage.h"


namespace lunar
{
	HeapStorage::HeapStorage()
	{
	}

	HeapStorage::~HeapStorage()
	{
		Destroy();
	}

	HeapStorage::HeapStorage(const HeapStorage& other)
	{
		*this = other;
	}

	HeapStorage::HeapStorage(HeapStorage&& other) noexcept
	{
		*this = std::move(other);
	}

	HeapStorage& HeapStorage::operator=(const HeapStorage& other)
	{
		if (this == &other) return *this;
		Destroy();
		m_GrowthFactor = other.m_GrowthFactor;
		if (other.m_Size)
		{
			m_Data = malloc(other.m_Size);
			if (!m_Data) { LUNAR_ERROR("HeapStorage: out of memory"); return *this; }
			memcpy(m_Data, other.m_Data, other.m_Size);
			m_Size = other.m_Size;
			m_Stride = other.m_Stride;
		}
		return *this;
	}

	HeapStorage& HeapStorage::operator=(HeapStorage&& other) noexcept
	{
		if (this == &other) return *this;
		Destroy();
		m_Data = other.m_Data;
		m_Size = other.m_Size;
		m_Stride = other.m_Stride;
		m_GrowthFactor = other.m_GrowthFactor;
		other.m_Data = nullptr;
		other.m_Size = 0;
		other.m_Stride = 0;
		return *this;
	}

	void HeapStorage::Init(size_t size, void* data)
	{
		Destroy();   // re-Init no longer leaks the old block

		if (size == 0) return;

		m_Data = malloc(size);
		if (!m_Data) { LUNAR_ERROR("HeapStorage: out of memory"); return; }
		m_Size = size;
		m_Stride = 0;

		if (data)
		{
			memcpy(m_Data, data, size);
			m_Stride = size;
		}
		else
		{
			memset(m_Data, 0, size);
		}
	}

	void HeapStorage::Resize(size_t newSize)
	{
		if (newSize > m_Size)
		{
			void* grown = realloc(m_Data, newSize);
			if (!grown) { LUNAR_ERROR("HeapStorage: out of memory"); return; }   // old block stays valid
			m_Data = grown;
			m_Size = newSize;
		}
		else
		{
			LUNAR_WARN("Given size is smaller than the present size");
		}
	}

	void HeapStorage::Paste(size_t offset, void* data, size_t size)
	{
		const size_t end = offset + size;

		if (end > m_Size)
		{
			// never smaller than what is needed, even when the growth factor is ~1
			size_t target = (size_t)((double)end * (double)m_GrowthFactor);
			if (target < end) target = end;
			Resize(target);
			if (end > m_Size) return;   // allocation failed
		}

		// pasting past the used bytes would leave an uninitialised gap, zero it
		if (offset > m_Stride)
			memset((char*)m_Data + m_Stride, 0, offset - m_Stride);

		memcpy((char*)m_Data + offset, data, size);

		if (end > m_Stride) m_Stride = end;
	}

	void HeapStorage::Push(void* data, size_t size)
	{
		// append after the USED bytes (previously this used the capacity and left gaps)
		Paste(m_Stride, data, size);
	}

	void HeapStorage::Clear()
	{
		m_Stride = 0;
	}

	void HeapStorage::Destroy()
	{
		if (m_Data)
		{
			free(m_Data);
			m_Data = nullptr;
		}
		m_Size = 0;
		m_Stride = 0;
	}
}
