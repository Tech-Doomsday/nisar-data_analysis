#pragma once
#include "../Core/Core.h"




namespace lunar
{
	// Growable CPU-side byte storage.
	//   GetSize()   = allocated capacity in bytes
	//   GetStride() = bytes actually in use (what Push / Paste have filled)
	class HeapStorage
	{
	public:
		HeapStorage();
		HeapStorage(const HeapStorage& other);
		HeapStorage(HeapStorage&& other) noexcept;
		HeapStorage& operator=(const HeapStorage& other);
		HeapStorage& operator=(HeapStorage&& other) noexcept;
		~HeapStorage();

		void Init(size_t size, void* data);
		void Resize(size_t newSize);
		void Paste(size_t offset, void* data, size_t size);
		void Push(void* data, size_t size); // appends right after the used bytes, grows capacity if needed
		void Clear();                       // forgets the used bytes, keeps the capacity
		void Destroy();
		inline void* GetData() { return m_Data; }
		template<class _T>
		inline _T* GetData() const { return (_T*)m_Data; }
		inline size_t GetSize() const { return m_Size; }
		inline size_t GetStride() const { return m_Stride; }
		inline float GetGrowthFactor() const { return m_GrowthFactor; }

		void SetGrowthIndex(float growth) { m_GrowthFactor = growth < 1.0f ? 1.0f : growth; }

	private:
		void* m_Data = nullptr;
		size_t m_Size = 0;
		size_t m_Stride = 0;
		float m_GrowthFactor = 1.5f;
	};
}
