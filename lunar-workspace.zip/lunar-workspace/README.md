# Lunar workspace

```
Lunar/            static library (engine only)          -> libLunar / Lunar.lib
  src/Lunar.h, src/LunarApp.h, src/Lunar/...
  src/Lunar/Impl/SceneStorage.h   entity data (SoA), handles, swap-remove, per-unit ranges
TestGame/         simplest app on Lunar, debug the engine here   (old main-temp.cpp)
RocketShooter/    the rocket shooter game (Lunar Rift)           (src/Game/*, RiftModule)
tests/            headless tests (stubbed GL/GLFW), see tests/README.txt
docs/             Lenz-to-Lunar-port.md
```

## Build

1. `copy config.example.txt config.local.txt` and set `CMAKE_EXE` / `VCPKG_ROOT` (machine paths live only there).
2. `generate.bat` -> build files in `build/` (`generate_here.bat` generates into the current folder instead).
3. Open the solution. F5 starts **TestGame**; set **RocketShooter** as the startup project to run the game.

## Adding another game / app

```
MyGame/CMakeLists.txt:
    file(GLOB_RECURSE SOURCES CONFIGURE_DEPENDS "src/*.cpp" "src/*.h")
    add_executable(MyGame ${SOURCES})
    target_link_libraries(MyGame PRIVATE Lunar)
```
then `add_subdirectory(MyGame)` in the root `CMakeLists.txt`. In code: `#include "LunarApp.h"` and `LUNAR_MAIN(MyApp)`.

## Entities: SceneStorage

The Scene owns the GPU buffers and one **segment** per unit (`AddUnit<T>(flush, capacity)`, capacities may differ).
`SceneStorage<Scene>` owns the CPU data of the entities: one array per member, indexed by slot, live entities packed at the
front of each unit's segment. See `TestGame/src/main.cpp` for the whole pattern:

```cpp
Handle h = store.Create<Bullet>();          // append, values start at 0
Range  r = store.RangeOf<Bullet>();         // slots [begin, begin + count): loop over store.Data(column)
store.Destroy(h);  store.Flush();           // queued, then swap-remove per unit: handles of other entities stay valid
store.Upload(gate.Update());                // live ranges -> this frame's GPU slot
```
Update thread only. `tests/storage_tests.cpp` covers it.

A unit is either **tracked** (`Create` / `Destroy` / handles, as above) or **dense** (`Append` / `RemoveAt(unit, slot)`, no handle
tables; remove while looping backwards). RocketShooter's units are dense. CPU columns can be limited to some units
(`AddCpuColumn<T>(store.MaskOf<A, B>())`), and GPU columns can be marked "does not follow the entity" when the game rebuilds that
data every frame (`AddGpuColumn<T>(offset, false)`). `tests/world_diff.cpp` runs the real RocketShooter `World` deterministically
and hashes every frame, to check a change leaves the game's behaviour identical.

**Upload cost.** A GPU / ISB column is copied in full every tick by default. `UploadMode::OnChange` (`AddGpuColumn<T>(offset, true, UploadMode::OnChange)`)
copies only the 64-entity blocks that changed: create / remove / move mark blocks automatically, writes through `Data()` are declared
with `Touch(col, handle)` / `TouchRange(col, unit, firstSlot, count)` / `Touch(col)`. `store.LastUploadBytes()` shows what a tick copied and
`store.SetVerifyUploads(true)` reports a forgotten `Touch`. Each of the 3 frame slots keeps its own dirty set, so changes that sit
next to each other in a unit are cheap and scattered changes less so (keep fast-moving things in their own unit).
