#pragma once
// 3x5 pixel font, 15 chars per glyph, rows top->bottom, '1' = lit.
namespace game
{
	inline const char* Glyph(char c)
	{
		if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
		switch (c)
		{
		case '0': return "111101101101111"; case '1': return "010110010010111";
		case '2': return "111001111100111"; case '3': return "111001111001111";
		case '4': return "101101111001001"; case '5': return "111100111001111";
		case '6': return "111100111101111"; case '7': return "111001001001001";
		case '8': return "111101111101111"; case '9': return "111101111001111";
		case 'A': return "010101111101101"; case 'B': return "110101110101110";
		case 'C': return "011100100100011"; case 'D': return "110101101101110";
		case 'E': return "111100110100111"; case 'F': return "111100110100100";
		case 'G': return "011100101101011"; case 'H': return "101101111101101";
		case 'I': return "111010010010111"; case 'J': return "001001001101010";
		case 'K': return "101101110101101"; case 'L': return "100100100100111";
		case 'M': return "101111111101101"; case 'N': return "110101101101101";
		case 'O': return "010101101101010"; case 'P': return "110101110100100";
		case 'Q': return "010101101110011"; case 'R': return "110101110101101";
		case 'S': return "011100010001110"; case 'T': return "111010010010010";
		case 'U': return "101101101101111"; case 'V': return "101101101101010";
		case 'W': return "101101111111101"; case 'X': return "101101010101101";
		case 'Y': return "101101010010010"; case 'Z': return "111001010100111";
		case ':': return "000010000010000"; case '-': return "000000111000000";
		case '.': return "000000000000010"; case '!': return "010010010000010";
		default:  return nullptr;
		}
	}
}
