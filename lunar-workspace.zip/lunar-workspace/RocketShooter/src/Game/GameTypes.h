#pragma once
#ifndef NOMINMAX
#define NOMINMAX   // keep std::min/max usable if a Windows header sneaks in
#endif
// ============================================================================
//  LUNAR RIFT - shared types / constants.
//  Everything here is "dev knows the game up front": the unit list, the
//  per-unit entity cap and the byte sizes are compile-time constants, the engine
//  is sized from them and nothing is allocated beyond them.
// ============================================================================
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <string>
#include <memory>
#include <chrono>

#include "Lunar/Core/Core.h"
#include "Lunar/Core/Buffer.h"
#include "Lunar/Core/Shader.h"
#include "Lunar/Core/Scene.h"

namespace game
{
	using glm::vec2;
	using glm::vec3;
	using glm::vec4;

	constexpr float PI = 3.14159265358979f;
	constexpr float TAU = 6.28318530717959f;

	// Playfield in world units, origin in the middle, +y up. Screen == world (fixed 16:9, letterboxed).
	constexpr float WORLD_W = 1600.0f;
	constexpr float WORLD_H = 900.0f;

	// ---- GPU particle system (independent buffer + compute shader) -----------
	constexpr int    MAX_PARTICLES = 16384;          // multiple of the compute local size (256)
	constexpr int    MAX_EMIT = 50;                  // emit commands per frame
	constexpr size_t EVENT_SLICE = 4096;             // bytes per frame in the events SSBO (256-aligned for BindRange)

	// ---- Unit (object kind) table. ORDER == AddUnit order == draw order -------
	struct KPickup {};
	struct KAsteroid {};
	struct KDrone {};
	struct KGunner {};
	struct KEnemyBullet {};
	struct KPlayerBullet {};
	struct KPlayer {};
	struct KRing {};
	struct KHud {};

	enum Unit : size_t
	{
		U_PICKUP = 0, U_ASTEROID, U_DRONE, U_GUNNER, U_EBULLET, U_PBULLET, U_PLAYER, U_RING, U_HUD,
		U_COUNT
	};

	// Material table indices (static SSBO read by the entity fragment shader)
	enum Mat : int
	{
		M_FLAT = 0, M_PLAYER, M_PBULLET, M_EBULLET, M_ASTEROID, M_DRONE, M_GUNNER, M_PICKUP, M_RING,
		M_COUNT
	};

	// Memory budget ------------------------------------------------------------
	constexpr int    ENTITY_PER_UNIT = 512;          // default capacity of every unit (AddUnit<T>(true, n) can give one unit its own)
	constexpr int    RESERVED_UNITS = 1;             // headroom slice for a unit added later
	constexpr size_t TOTAL_ENTITIES = (size_t)ENTITY_PER_UNIT * (U_COUNT + RESERVED_UNITS);
	constexpr size_t INSTANCE_BYTES_PER_ENTITY = 32; // IVB: vec4 + vec4  |  ISB: vec4 + vec4
	constexpr size_t INSTANCE_STORAGE_BYTES = TOTAL_ENTITIES * INSTANCE_BYTES_PER_ENTITY;

	// ---- Per-instance vertex data (Scene IVB, structure-of-arrays) -------------
	struct IVBData
	{
		vec4 xform;   // x, y, rotation, uniform scale
		vec4 color;   // tint rgba
	};

	// ---- Per-instance storage data (Scene ISB, std430 struct in the shader) ---
	struct ISBData
	{
		vec4 a;       // x: material id, y: flash 0..1, z: alpha, w: pulse phase
		vec4 b;       // x: unused, y: hud flag (1 = ignore camera shake), zw: unused
	};
	static_assert(sizeof(IVBData) == INSTANCE_BYTES_PER_ENTITY, "IVB per-entity size must match the budget");
	static_assert(sizeof(ISBData) == INSTANCE_BYTES_PER_ENTITY, "ISB per-entity size must match the budget");

	// ---- Scene UBO (std140) ---------------------------------------------------
	struct FrameData
	{
		glm::mat4 viewProj;
		glm::mat4 hudProj;
		vec4 timeInfo;       // x time, y dt, z flash, w -
		vec4 camInfo;        // x,y parallax offset, z world W, w world H
		int32_t ints[4];     // x: first entity index of this frame's ISB slice, y: frame no
	};
	static_assert(sizeof(FrameData) % 16 == 0, "std140");

	// ---- Static material table (SSBO) ------------------------------------------
	struct Material
	{
		vec4 core;
		vec4 rim;
		vec4 style;          // x rim exponent (0 = flat), y pulse speed, z pulse amount, w brightness
	};

	// ---- GPU particles ------------------------------------------------------------
	struct Particle
	{
		vec2 pos;
		vec2 vel;
		vec4 color;
		vec4 misc;           // life, maxLife, size, drag
	};
	static_assert(sizeof(Particle) == 48, "Particle layout must match the std430 struct");

	struct EmitCmd
	{
		vec4 posVel;         // xy position, zw inherited velocity
		vec4 color;
		vec4 shape;          // x angle, y spread, z speedMin, w speedMax
		vec4 life;           // x lifeMin, y lifeMax, z size, w drag
		uint32_t range[4];   // x first particle index (ring), y count, z seed, w -
	};
	static_assert(sizeof(EmitCmd) == 80, "EmitCmd layout must match the std430 struct");

	struct EmitBlock
	{
		uint32_t header[4];  // x cmd count, y flags (bit0 = clear all)
		float sim[4];        // x dt, y time
		EmitCmd cmds[MAX_EMIT];
	};
	static_assert(sizeof(EmitBlock) <= EVENT_SLICE, "emit block must fit one slice");

	// Per-frame packet: written by the update thread, read by the render thread
	// (ordering is given by the engine's slot state release/acquire).
	struct FramePacket
	{
		FrameData ubo;
		uint32_t emitCount = 0;
		uint32_t flags = 0;
	};

	using GameScene = lunar::Scene<IVBData, ISBData>;

	// ---- Input (main thread writes, sim thread reads) -----------------------------
	enum KeyBit : uint32_t { K_UP = 1, K_DOWN = 2, K_LEFT = 4, K_RIGHT = 8, K_FIRE = 16, K_NOVA = 32 };
	enum PressBit : uint32_t { P_PAUSE = 1, P_START = 2, P_NOVA = 4 };

	struct Input
	{
		std::atomic<uint32_t> keys{ 0 };
		std::atomic<uint32_t> pressed{ 0 };
		std::atomic<float> mouseX{ 0.0f };   // world coordinates
		std::atomic<float> mouseY{ 0.0f };
	};
}
