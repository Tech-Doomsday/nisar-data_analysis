#pragma once
#include "GameTypes.h"

// ============================================================================
//  One mesh per unit, supplied through the engine's  Object<Tag>::Init()  hook.
//  Vertex = { x, y, edge }  (edge: 0 at the centre, 1 on the rim; drives the neon glow)
// ============================================================================
namespace game
{
	struct MeshBuilder
	{
		std::vector<float> v;
		std::vector<unsigned int> idx;

		unsigned int Vert(float x, float y, float e)
		{
			v.push_back(x); v.push_back(y); v.push_back(e);
			return (unsigned int)(v.size() / 3 - 1);
		}
		void Tri(unsigned a, unsigned b, unsigned c) { idx.push_back(a); idx.push_back(b); idx.push_back(c); }

		// triangle fan around the origin; rim must be star-shaped w.r.t. (0,0)
		void Fan(const std::vector<vec2>& rim, float centerEdge = 0.0f, float rimEdge = 1.0f)
		{
			const unsigned c = Vert(0, 0, centerEdge);
			const unsigned first = (unsigned)(v.size() / 3);
			for (const vec2& p : rim) Vert(p.x, p.y, rimEdge);
			const unsigned n = (unsigned)rim.size();
			for (unsigned i = 0; i < n; i++) Tri(c, first + i, first + (i + 1) % n);
		}

		void Ring(int segs, float inner, float innerEdge, float outerEdge)
		{
			const unsigned first = (unsigned)(v.size() / 3);
			for (int i = 0; i < segs; i++)
			{
				const float a = TAU * i / segs;
				Vert(std::cos(a), std::sin(a), outerEdge);
				Vert(std::cos(a) * inner, std::sin(a) * inner, innerEdge);
			}
			for (int i = 0; i < segs; i++)
			{
				const unsigned o0 = first + 2 * i, i0 = o0 + 1;
				const unsigned o1 = first + 2 * ((i + 1) % segs), i1 = o1 + 1;
				Tri(o0, i0, o1); Tri(i0, i1, o1);
			}
		}

		void Commit(lunar::ShapeData& s)
		{
			s.Init(v.data(), v.size() * sizeof(float), idx.data(), idx.size() * sizeof(unsigned int));
			s.SetVertexLayout({ {0, 2, GL_FLOAT, sizeof(float) * 2}, {3, 1, GL_FLOAT, sizeof(float) * 1} });
		}
	};

	inline std::vector<vec2> Polygon(int n, float r, float rot = 0.0f)
	{
		std::vector<vec2> p;
		for (int i = 0; i < n; i++) { float a = rot + TAU * i / n; p.push_back({ std::cos(a) * r, std::sin(a) * r }); }
		return p;
	}

	inline void BuildPlayer(lunar::ShapeData& s)  { MeshBuilder m; m.Fan({ {1.0f,0.0f},{-0.8f,0.7f},{-0.4f,0.0f},{-0.8f,-0.7f} }); m.Commit(s); }
	inline void BuildPBullet(lunar::ShapeData& s) { MeshBuilder m; m.Fan({ {1.0f,0.0f},{0.0f,0.35f},{-1.0f,0.0f},{0.0f,-0.35f} }); m.Commit(s); }
	inline void BuildEBullet(lunar::ShapeData& s) { MeshBuilder m; m.Fan(Polygon(10, 1.0f)); m.Commit(s); }
	inline void BuildDrone(lunar::ShapeData& s)   { MeshBuilder m; m.Fan({ {1.0f,0.0f},{0.0f,0.7f},{-0.8f,0.45f},{-0.4f,0.0f},{-0.8f,-0.45f},{0.0f,-0.7f} }); m.Commit(s); }
	inline void BuildGunner(lunar::ShapeData& s)  { MeshBuilder m; m.Fan(Polygon(6, 1.0f)); m.Commit(s); }
	inline void BuildHud(lunar::ShapeData& s)     { MeshBuilder m; m.Fan({ {1,1},{-1,1},{-1,-1},{1,-1} }); m.Commit(s); }
	inline void BuildRing(lunar::ShapeData& s)    { MeshBuilder m; m.Ring(48, 0.90f, 0.5f, 1.0f); m.Commit(s); }

	inline void BuildAsteroid(lunar::ShapeData& s)
	{
		static const float r[12] = { 1.0f, 0.82f, 0.95f, 0.78f, 1.0f, 0.88f, 0.74f, 0.96f, 0.84f, 1.0f, 0.80f, 0.92f };
		std::vector<vec2> rim;
		for (int i = 0; i < 12; i++) { float a = TAU * i / 12; rim.push_back({ std::cos(a) * r[i], std::sin(a) * r[i] }); }
		MeshBuilder m; m.Fan(rim); m.Commit(s);
	}

	inline void BuildPickup(lunar::ShapeData& s)
	{
		std::vector<vec2> rim;
		for (int i = 0; i < 10; i++) { float a = TAU * i / 10 + PI * 0.5f; float r = (i % 2 == 0) ? 1.0f : 0.45f; rim.push_back({ std::cos(a) * r, std::sin(a) * r }); }
		MeshBuilder m; m.Fan(rim); m.Commit(s);
	}
}

// Engine hook: defined "on the user side" exactly as Shape.h describes.
namespace lunar
{
	template<> inline void Object<game::KPlayer>::Init()       { game::BuildPlayer(ShapeData); }
	template<> inline void Object<game::KPlayerBullet>::Init() { game::BuildPBullet(ShapeData); }
	template<> inline void Object<game::KEnemyBullet>::Init()  { game::BuildEBullet(ShapeData); }
	template<> inline void Object<game::KAsteroid>::Init()     { game::BuildAsteroid(ShapeData); }
	template<> inline void Object<game::KDrone>::Init()        { game::BuildDrone(ShapeData); }
	template<> inline void Object<game::KGunner>::Init()       { game::BuildGunner(ShapeData); }
	template<> inline void Object<game::KPickup>::Init()       { game::BuildPickup(ShapeData); }
	template<> inline void Object<game::KRing>::Init()         { game::BuildRing(ShapeData); }
	template<> inline void Object<game::KHud>::Init()          { game::BuildHud(ShapeData); }
}
