#pragma once
#include "GameTypes.h"
#include "Lunar/Impl/SceneStorage.h"

namespace game
{
	using GameStore = lunar::SceneStorage<GameScene>;

	// One unit (object kind) of the game, as a dense swap-remove view of that unit in the SceneStorage.
	//  * the engine side (draw command, instance counts, the instance buffers) lives in the Scene / SceneStorage
	//  * Sim = the game's own simulation data of that kind: one CPU column of the storage, used by this unit only
	//  * index i in [0, Count()) is the local index; its slot in the storage / instance buffers is Start() + i
	// Remove(i) is an immediate swap-remove (the last entity takes slot i): loop BACKWARDS when you remove inside the loop.
	template<class Tag, class Sim>
	class Pool
	{
	public:
		using TagType = Tag;

		// Before any entity exists. Takes the unit's segment (start, capacity) from the scene.
		void Init(GameScene& scene, GameStore& store)
		{
			m_Scene = &scene;
			m_Store = &store;
			m_Unit = scene.template GetUnitId<Tag>();
			const lunar::UnitSegment& seg = scene.GetSegment(m_Unit);
			m_Start = seg.start;
			m_Cap = seg.capacity;
			m_Col = store.template AddCpuColumn<Sim>(store.template MaskOf<Tag>());
			m_Sim = store.Data(m_Col);
		}

		int Add(const Sim& s)
		{
			const size_t slot = m_Store->AppendIn(m_Unit);
			if (slot == GameStore::npos) return -1;             // pool full: caller just drops the spawn
			m_Sim[slot] = s;
			return (int)(slot - m_Start);
		}

		void Remove(int i) { m_Store->RemoveAt(m_Unit, m_Start + (size_t)i); }

		void Clear() { m_Store->ClearUnit(m_Unit); }

		Sim& operator[](int i) { return m_Sim[m_Start + i]; }
		const Sim& operator[](int i) const { return m_Sim[m_Start + i]; }
		int    Count() const { return (int)m_Scene->GetUnitEntityCount(m_Unit); }
		size_t Start() const { return m_Start; }
		size_t Capacity() const { return m_Cap; }

	private:
		GameScene* m_Scene = nullptr;
		GameStore* m_Store = nullptr;
		int m_Unit = -1;
		size_t m_Cap = 0, m_Start = 0;
		lunar::Column<Sim> m_Col;
		Sim* m_Sim = nullptr;                                   // the unit's Sim array, indexed by slot
	};
}
