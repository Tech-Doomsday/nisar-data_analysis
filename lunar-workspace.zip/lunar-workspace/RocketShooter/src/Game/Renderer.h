#pragma once
#include "GameTypes.h"
#include "Shaders.h"

// ============================================================================
//  Everything that touches GL on the render thread, built ONLY from engine
//  classes: Shader, Buffer/UnifromStorageBuffer/VertexBuffer/IndexBuffer,
//  ArrayObject and the Scene's own extra shader-storage buffers.
// ============================================================================
namespace game
{
	struct Viewport { int x, y, w, h; };

	// Fixed 16:9 playfield, letterboxed inside whatever the framebuffer is.
	inline Viewport Letterbox(int fbW, int fbH)
	{
		const float target = WORLD_W / WORLD_H;
		int w = fbW, h = (int)(fbW / target);
		if (h > fbH) { h = fbH; w = (int)(fbH * target); }
		return { (fbW - w) / 2, (fbH - h) / 2, w, h };
	}

	class Renderer
	{
	public:
		// Must run on the thread that owns the GL context, after the scene is initialised.
		void Init(GameScene& scene)
		{
			m_Scene = &scene;

			// -- four independent shader programs --------------------------------
			m_Background.AddFragment(lunar::ShaderType::VertexShader, glsl::bgVS);
			m_Background.AddFragment(lunar::ShaderType::FragmentShader, glsl::bgFS);
			m_Background.Compile();

			m_Entity.AddFragment(lunar::ShaderType::VertexShader, glsl::entityVS);
			m_Entity.AddFragment(lunar::ShaderType::FragmentShader, glsl::entityFS);
			m_Entity.Compile();

			m_ParticleDraw.AddFragment(lunar::ShaderType::VertexShader, glsl::particleVS);
			m_ParticleDraw.AddFragment(lunar::ShaderType::FragmentShader, glsl::particleFS);
			m_ParticleDraw.Compile();

			m_ParticleSim.AddFragment(lunar::ShaderType::ComputeShader, glsl::particleCS);
			m_ParticleSim.Compile();

			// -- scene UBO (own buffer, updated every frame with glBufferSubData) -----
			m_Ubo.Init(lunar::DynamicStorage, nullptr, sizeof(FrameData));
			m_Ubo.BindBase(0, lunar::BufferType::UniformBuffer);

			// -- Scene-owned extra SSBOs ------------------------------------------------
			// #1 static material table, bound once. AddShaderStorage allocates size * frames.
			lunar::Buffer* materials = scene.AddShaderStorage(1, sizeof(Material) * M_COUNT);
			if (!materials) { LUNAR_ERROR("could not create the material buffer"); return; }
			Material* mat = (Material*)materials->GetMappedPointer(lunar::WriteMap, 0, sizeof(Material) * M_COUNT);
			if (mat) { FillMaterials(mat); materials->UnMap(); }
			scene.BindStorageBufferToSlot(2, materials);

			// #2 per-frame GPU events, persistently mapped, one slice per frame in flight.
			m_Events = scene.AddShaderStorage(2, EVENT_SLICE);
			if (!m_Events) { LUNAR_ERROR("could not create the events buffer"); return; }
			m_EventsBase = (char*)m_Events->GetMappedPointer((lunar::StorageHints)(lunar::WriteMap | lunar::PresistantMap), 0, -1);

			// -- independent particle geometry: quad VB + IB, particle VB used per-instance ---
			static float quad[8] = { -1, -1, 1, -1, 1, 1, -1, 1 };
			static unsigned int qidx[6] = { 0, 1, 2, 0, 2, 3 };
			m_QuadVB.DataInit(lunar::StaticDraw, quad, sizeof(quad));
			m_QuadVB.SetLayout({ {0, 2, GL_FLOAT, sizeof(float) * 2} });
			m_QuadIB.Init(lunar::StaticDraw, qidx, sizeof(qidx));

			std::vector<Particle> zero(MAX_PARTICLES);
			std::memset(zero.data(), 0, zero.size() * sizeof(Particle));
			m_PartVB.StorageInit(lunar::DynamicStorage, zero.data(), zero.size() * sizeof(Particle));
			m_PartVB.SetLayout({ {1, 2, GL_FLOAT, sizeof(float) * 2}, {2, 2, GL_FLOAT, sizeof(float) * 2},
								 {3, 4, GL_FLOAT, sizeof(float) * 4}, {4, 4, GL_FLOAT, sizeof(float) * 4} });
			m_PartVB.SetInstanceDivisor(1);

			m_PartVAO.Init();
			m_PartVAO.AddVertexBuffer(&m_QuadVB);
			m_PartVAO.AddVertexBuffer(&m_PartVB);
			m_PartVAO.AddIndexBuffer(&m_QuadIB);
			m_PartVAO.Compile();

			// core profile needs a VAO even for the attribute-less fullscreen triangle
			m_EmptyVAO.Init();
			m_EmptyVAO.Compile();

			glEnable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			glDisable(GL_CULL_FACE);
			GL_CHECK_ERROR();
		}

		// Where the update thread writes the GPU events of a frame slot.
		EmitBlock* EventSlice(int frameNo) { return (EmitBlock*)(m_EventsBase + (size_t)frameNo * EVENT_SLICE); }

		void Draw(const FramePacket& pk, GameScene::RenderChache& rc, int fbW, int fbH)
		{
			// Make the update thread's writes of this frame slot visible (flushes the scene buffers and issues the
			// client-mapped barrier, which also covers the events buffer that the compute pass reads below).
			m_Scene->MakeUpdatesVisible(rc);

			m_Ubo.Write((void*)&pk.ubo, 0, sizeof(FrameData));

			// --- compute: spawn + integrate particles for THIS frame slot -----------------
			m_ParticleSim.Bind();
			m_PartVB.BindBase(1, lunar::BufferType::ShaderStorage);   // an ArrayBuffer used as an SSBO (the hint is honoured now)
			m_Events->BindRange(3, (size_t)rc.frameNo * EVENT_SLICE, EVENT_SLICE, lunar::BufferType::ShaderStorage);
			glDispatchCompute(MAX_PARTICLES / 256, 1, 1);
			glMemoryBarrier(GL_SHADER_STORAGE_BARRIER_BIT | GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT);

			// --- clear the whole window, then draw inside the letterboxed viewport ----------
			glViewport(0, 0, fbW, fbH);
			glClearColor(0, 0, 0, 1);
			glClear(GL_COLOR_BUFFER_BIT);
			const Viewport vp = Letterbox(fbW, fbH);
			glViewport(vp.x, vp.y, vp.w, vp.h);

			glDisable(GL_BLEND);
			m_Background.Bind();
			m_EmptyVAO.Bind();
			glDrawArrays(GL_TRIANGLES, 0, 3);

			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);                       // additive particles
			m_ParticleDraw.Bind();
			m_PartVAO.Bind();
			glDrawElementsInstanced(GL_TRIANGLES, 6, GL_UNSIGNED_INT, nullptr, MAX_PARTICLES);

			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);       // the whole entity world: ONE multi-draw
			m_Scene->RenderFrame(m_Entity, rc);
		}

	private:
		static void FillMaterials(Material* m)
		{
			auto set = [&](int i, vec4 core, vec4 rim, float pow_, float pulseSpeed, float pulseAmt, float bright)
			{ m[i].core = core; m[i].rim = rim; m[i].style = vec4(pow_, pulseSpeed, pulseAmt, bright); };
			set(M_FLAT,     vec4(1, 1, 1, 1),                 vec4(1, 1, 1, 1),                  0.0f, 0, 0,    1.0f);
			set(M_PLAYER,   vec4(0.05f, 0.25f, 0.30f, 1),     vec4(0.45f, 1.0f, 0.90f, 1),       2.0f, 0, 0,    1.25f);
			set(M_PBULLET,  vec4(1.0f, 1.0f, 1.0f, 1),        vec4(0.4f, 1.0f, 0.85f, 1),        1.5f, 0, 0,    1.6f);
			set(M_EBULLET,  vec4(1.0f, 0.9f, 0.7f, 1),        vec4(1.0f, 0.25f, 0.15f, 1),       2.0f, 14, 0.25f, 1.4f);
			set(M_ASTEROID, vec4(0.10f, 0.11f, 0.14f, 1),     vec4(0.62f, 0.68f, 0.80f, 1),      2.5f, 0, 0,    1.0f);
			set(M_DRONE,    vec4(0.25f, 0.03f, 0.18f, 1),     vec4(1.0f, 0.30f, 0.80f, 1),       2.0f, 6, 0.12f, 1.2f);
			set(M_GUNNER,   vec4(0.28f, 0.14f, 0.02f, 1),     vec4(1.0f, 0.70f, 0.20f, 1),       2.0f, 3, 0.15f, 1.25f);
			set(M_PICKUP,   vec4(0.3f, 0.3f, 0.3f, 1),        vec4(1.0f, 1.0f, 1.0f, 1),         1.5f, 5, 0.2f, 1.4f);
			set(M_RING,     vec4(1.0f, 1.0f, 1.0f, 0.15f),    vec4(1.0f, 1.0f, 1.0f, 1.0f),      1.0f, 0, 0,    1.5f);
		}

		GameScene* m_Scene = nullptr;

		lunar::Shader m_Background, m_Entity, m_ParticleDraw, m_ParticleSim;
		lunar::UnifromStorageBuffer m_Ubo;

		lunar::Buffer* m_Events = nullptr;
		char* m_EventsBase = nullptr;

		lunar::VertexBuffer m_QuadVB, m_PartVB;
		lunar::IndexBuffer m_QuadIB;
		lunar::ArrayObject m_PartVAO, m_EmptyVAO;
	};
}
