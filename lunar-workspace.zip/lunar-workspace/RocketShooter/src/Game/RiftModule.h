#pragma once
// ============================================================================
//  LUNAR RIFT as a lunar::Module.
//
//  This is the old hand-written `App` class of main.cpp moved onto the Application layer:
//
//    old App::Init()            ->  RiftModule::OnMount()       (window / context / callbacks are the Application's job now)
//    old OnKey / OnMouseButton  ->  gone: lunar::Input snapshot, mapped to game::Input in MapInput()
//                                   (OnFocus is gone too: Input releases everything when focus is lost)
//    old SimLoop()              ->  RiftModule::OnUpdate()      (the loop, dt clamp and back-off are the Application's)
//    old Run() render half      ->  RiftModule::OnRender()      (poll, RenderStart/Fence/End, swap, title timer, minimised
//                                                                handling are the Application's, via SceneGate)
//    old App::End()             ->  RiftModule::OnUnmount()     (GL still alive; world -> renderer -> scene, same order)
//
//  Compiled and run only against mocks of the Game headers (see docs/Lenz-to-Lunar-port.md); build it once against the real ones.
// ============================================================================
#include "LunarApp.h"

#include "Game/GameTypes.h"
#include "Game/World.h"
#include "Game/Renderer.h"

#include <atomic>
#include <memory>
#include <stdexcept>

namespace game
{
	class RiftModule final : public lunar::Module
	{
	public:
		RiftModule() : Module("Rift", 0) {}

		void OnMount() override
		{
			using lunar::events::KeyPressed;

			// Esc quits. Returning true consumes the key, so the update thread never sees it either.
			Listen<KeyPressed>([this](KeyPressed& e)
			{
				if (e.key != lunar::Key::Escape || e.repeat) return false;
				App().Quit();
				return true;
			});

			// ---- the engine is sized from the game's own numbers (unchanged from the old App::Init) -------------
			m_Scene = std::make_unique<GameScene>();
			if (!m_Scene->Init(
				{ {0, 2, GL_FLOAT, sizeof(float) * 2}, {3, 1, GL_FLOAT, sizeof(float) * 1} },              // mesh vertex: pos, edge
				{ {1, 4, GL_FLOAT, sizeof(float) * 4}, {2, 4, GL_FLOAT, sizeof(float) * 4} },              // instance: xform, color
				(int)U_COUNT, INSTANCE_STORAGE_BYTES, RESERVED_UNITS))
				throw std::runtime_error("Lunar Rift: Scene::Init failed");

			if ((int)m_Scene->GetEntityPerUnit() != ENTITY_PER_UNIT) LUNAR_ERROR("entity-per-unit differs from the game's budget");

			// Unit order == enum Unit == draw order (back to front).
			if (!m_Scene->AddUnit<KPickup>() || !m_Scene->AddUnit<KAsteroid>() || !m_Scene->AddUnit<KDrone>() ||
				!m_Scene->AddUnit<KGunner>() || !m_Scene->AddUnit<KEnemyBullet>() || !m_Scene->AddUnit<KPlayerBullet>() ||
				!m_Scene->AddUnit<KPlayer>() || !m_Scene->AddUnit<KRing>() || !m_Scene->AddUnit<KHud>())
				throw std::runtime_error("Lunar Rift: Scene::AddUnit failed");

			m_Scene->SetShaderInstanceStorageBufferBindingPoint(0);     // instance SSBO -> binding 0

			m_Renderer = std::make_unique<Renderer>();
			m_Renderer->Init(*m_Scene);
			m_World = std::make_unique<World>();
			m_World->Init(*m_Scene);

			// Hand the frame ring to the Application: it drives UpdateStart/End and RenderStart/Fence/End from now on.
			m_Gate = static_cast<lunar::SceneGate<GameScene>*>(
				App().SetGate(std::make_unique<lunar::SceneGate<GameScene>>(*m_Scene)));

			LUNAR_LOG("[Lunar Rift] units: " << m_Scene->GetUnits() << "  entities/unit: " << m_Scene->GetEntityPerUnit()
				<< "  total cap: " << m_Scene->GetTotalEntityCap()
				<< "  instance bytes/frame: VB " << m_Scene->GetIVBsize() << " + SB " << m_Scene->GetISBsize()
				<< "  indirect: " << m_Scene->GetIDBsize());
		}

		// GL objects must die while the context still exists: the Application calls this before it destroys the window.
		void OnUnmount() override
		{
			m_Gate = nullptr;
			m_World.reset();
			m_Renderer.reset();
			m_Scene.reset();
		}

		// ── update thread: one call per free frame slot (SceneGate::AcquireUpdate succeeded) ───────────────────
		void OnUpdate(const lunar::UpdateContext& ctx) override
		{
			GameScene::UpdateChache* u = m_Gate->Update();

			MapInput(ctx);
			m_World->Tick(ctx.dt, m_Input);
			m_World->WriteFrame(u, m_World->packets[u->frameNo], m_Renderer->EventSlice(u->frameNo));

			m_EntityCount.store(m_World->TotalEntities(), std::memory_order_relaxed);
			m_Score.store(m_World->Score(), std::memory_order_relaxed);
			m_Wave.store(m_World->Wave(), std::memory_order_relaxed);
		}

		// ── main thread: a written slot is ours (AcquireRender succeeded); the Application swaps and fences after this ──
		void OnRender(const lunar::RenderContext& ctx) override
		{
			auto& rc = m_Gate->Render();
			m_Renderer->Draw(m_World->packets[rc.frameNo], rc, (int)ctx.window.fbWidth, (int)ctx.window.fbHeight);

			if (ctx.time - m_LastTitle >= 0.5)       // same title text and 0.5 s cadence as before
			{
				m_LastTitle = ctx.time;
				char t[200];
				std::snprintf(t, sizeof t, "Lunar Rift | %.0f fps | %zu entities in %zu draws | score %d  wave %d",
					ctx.fps, (size_t)m_EntityCount.load(), m_Scene->GetUnits(), m_Score.load(), m_Wave.load());
				App().GetWindow().SetTitle(t);
			}
		}

	private:
		// lunar::Input (per-tick snapshot) -> the game's own bit masks.
		void MapInput(const lunar::UpdateContext& ctx)
		{
			using lunar::Key;
			using lunar::MouseButton;
			const lunar::Input& in = ctx.input;

			uint32_t keys = 0, pressed = 0;
			if (in.Down(Key::W) || in.Down(Key::Up))    keys |= K_UP;
			if (in.Down(Key::S) || in.Down(Key::Down))  keys |= K_DOWN;
			if (in.Down(Key::A) || in.Down(Key::Left))  keys |= K_LEFT;
			if (in.Down(Key::D) || in.Down(Key::Right)) keys |= K_RIGHT;
			// Pressed() counts too: a tap that is over before the tick still fires once
			if (in.Down(Key::Space) || in.Pressed(Key::Space) || in.Down(MouseButton::Left) || in.Pressed(MouseButton::Left)) keys |= K_FIRE;

			if (in.Pressed(Key::Space) || in.Pressed(Key::Enter) || in.Pressed(MouseButton::Left)) pressed |= P_START;
			if (in.Pressed(Key::E) || in.Pressed(Key::LeftShift) || in.Pressed(MouseButton::Right)) pressed |= P_NOVA;
			if (in.Pressed(Key::P)) pressed |= P_PAUSE;

			m_Input.keys.store(keys, std::memory_order_relaxed);
			m_Input.pressed.store(pressed, std::memory_order_relaxed);

			// cursor -> framebuffer pixels (y up) -> playfield coordinates inside the letterboxed viewport
			const lunar::WindowMetrics& w = ctx.window;
			if (w.fbWidth > 0 && w.fbHeight > 0)
			{
				const glm::dvec2 p = w.CursorToFramebuffer(in.MousePosition());
				const Viewport vp = Letterbox((int)w.fbWidth, (int)w.fbHeight);
				m_Input.mouseX.store(((float)(p.x - vp.x) / (float)vp.w - 0.5f) * WORLD_W);
				m_Input.mouseY.store(((float)(p.y - vp.y) / (float)vp.h - 0.5f) * WORLD_H);
			}
		}

		std::unique_ptr<GameScene> m_Scene;
		std::unique_ptr<Renderer> m_Renderer;
		std::unique_ptr<World> m_World;
		lunar::SceneGate<GameScene>* m_Gate = nullptr;

		game::Input m_Input;                         // what World::Tick reads; only the update thread touches it now

		std::atomic<size_t> m_EntityCount{ 0 };
		std::atomic<int> m_Score{ 0 }, m_Wave{ 0 };
		double m_LastTitle = 0.0;                    // render thread only
	};
}
