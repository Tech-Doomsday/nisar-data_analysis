#pragma once
// All GLSL for the game. Four independent programs, each built with lunar::Shader:
//   background (VS+FS, no vertex buffers)   entity (VS+FS, driven by the Scene multi-draw)
//   particle draw (VS+FS, own VAO)          particle sim (compute)
namespace game { namespace glsl
{
	// Shared UBO block: binding 0, must match game::FrameData (std140)
	#define LR_FRAME_UBO \
	"layout(std140, binding = 0) uniform FrameData {\n" \
	"    mat4 viewProj;\n" \
	"    mat4 hudProj;\n" \
	"    vec4 timeInfo;\n"  /* x time, y dt, z flash */ \
	"    vec4 camInfo;\n"   /* xy parallax, zw world size */ \
	"    ivec4 ints;\n"     /* x unused, y frame no */ \
	"};\n"

	// ---------------------------------------------------------------- background
	inline const char* bgVS =
	"#version 460 core\n"
	"layout(location = 0) out vec2 vUV;\n"
	"void main() {\n"
	"    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n"
	"    vUV = p;\n"
	"    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
	"}\n";

	inline const char* bgFS =
	"#version 460 core\n"
	"layout(location = 0) in vec2 vUV;\n"
	"layout(location = 0) out vec4 FragColor;\n"
	LR_FRAME_UBO
	"float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }\n"
	"float vnoise(vec2 p) {\n"
	"    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);\n"
	"    float a = hash21(i); float b = hash21(i + vec2(1.0, 0.0));\n"
	"    float c = hash21(i + vec2(0.0, 1.0)); float d = hash21(i + vec2(1.0, 1.0));\n"
	"    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);\n"
	"}\n"
	"float fbm(vec2 p) {\n"
	"    float v = 0.0; float a = 0.5;\n"
	"    for (int i = 0; i < 5; i++) { v += a * vnoise(p); p = p * 2.03 + vec2(17.0, 9.0); a *= 0.5; }\n"
	"    return v;\n"
	"}\n"
	"vec3 starLayer(vec2 uv, float scale, float density, float t, vec2 shift) {\n"
	"    vec2 g = uv * scale + shift;\n"
	"    vec2 id = floor(g); vec2 f = fract(g) - 0.5;\n"
	"    float h = hash21(id);\n"
	"    if (h > density) return vec3(0.0);\n"
	"    vec2 o = vec2(hash21(id + 7.1), hash21(id + 3.7)) - 0.5;\n"
	"    float d = length(f - o * 0.7);\n"
	"    float tw = 0.6 + 0.4 * sin(t * (1.0 + h * 4.0) + h * 40.0);\n"
	"    float s = (1.0 - smoothstep(0.0, 0.09, d)) * tw;\n"
	"    vec3 c = mix(vec3(0.6, 0.75, 1.0), vec3(1.0, 0.85, 0.7), hash21(id + 1.3));\n"
	"    return c * s;\n"
	"}\n"
	"void main() {\n"
	"    float aspect = camInfo.z / camInfo.w;\n"
	"    vec2 uv = vec2(vUV.x * aspect, vUV.y);\n"
	"    vec2 p = (vUV - 0.5) * vec2(aspect, 1.0);\n"
	"    float t = timeInfo.x;\n"
	"    vec2 par = camInfo.xy;\n"
	"    vec3 col = vec3(0.012, 0.015, 0.035);\n"
	"    float n1 = fbm(p * 1.6 + par * 0.0004 + vec2(t * 0.01, 0.0));\n"
	"    float n2 = fbm(p * 2.7 - vec2(t * 0.015, 3.0) + 5.0);\n"
	"    col += vec3(0.10, 0.03, 0.18) * n1 * n1 * 1.6 + vec3(0.02, 0.08, 0.14) * n2 * n2 * 1.2;\n"
	"    col += starLayer(uv, 30.0, 0.30, t, par * 0.0015);\n"
	"    col += starLayer(uv + 3.3, 18.0, 0.22, t * 0.7, par * 0.0030) * 1.3;\n"
	"    col += starLayer(uv + 9.1, 9.0, 0.14, t * 0.5, par * 0.0060) * 1.8;\n"
	"    vec2 mp = p - vec2(0.58, 0.26) - par * 0.00004;\n"
	"    float md = length(mp);\n"
	"    float disc = 1.0 - smoothstep(0.125, 0.13, md);\n"
	"    float shade = clamp(dot(mp / (md + 0.0001), normalize(vec2(-0.6, 0.5))) * 0.5 + 0.5, 0.0, 1.0);\n"
	"    vec3 moon = vec3(0.75, 0.78, 0.85) * (0.35 + 0.65 * shade) * (0.65 + 0.5 * fbm(mp * 18.0));\n"
	"    col = mix(col, moon * 0.8, disc);\n"
	"    col += vec3(0.25, 0.30, 0.50) * (1.0 - smoothstep(0.13, 0.24, md)) * 0.22;\n"
	"    float vig = 1.0 - 0.45 * smoothstep(0.35, 1.1, length(vUV - 0.5) * 2.0);\n"
	"    col *= vig;\n"
	"    col += vec3(0.50, 0.35, 0.60) * timeInfo.z * 0.35;\n"
	"    FragColor = vec4(col, 1.0);\n"
	"}\n";

	// -------------------------------------------------------------------- entity
	// Fed by Scene::RenderFrame (glMultiDrawElementsIndirect):
	//   loc 0 aPos / loc 3 aEdge : combined vertex buffer (per vertex)
	//   loc 1 iXform / loc 2 iColor : instance vertex buffer (SoA, divisor 1)
	//   SSBO 0 : instance storage buffer (the engine binds the slice of the frame being drawn)
	//   SSBO 2 : static material table
	inline const char* entityVS =
	"#version 460 core\n"
	"layout(location = 0) in vec2 aPos;\n"
	"layout(location = 3) in float aEdge;\n"
	"layout(location = 1) in vec4 iXform;\n"
	"layout(location = 2) in vec4 iColor;\n"
	LR_FRAME_UBO
	"struct InstanceData { vec4 a; vec4 b; };\n"
	"layout(std430, binding = 0) readonly buffer InstanceBuffer { InstanceData instances[]; };\n"
	"layout(location = 0) out vec4 vColor;\n"
	"layout(location = 1) out float vEdge;\n"
	"layout(location = 2) flat out vec4 vA;\n"
	"void main() {\n"
	"    int eid = gl_BaseInstance + gl_InstanceID;\n"          // gl_InstanceID does NOT include baseInstance
	"    InstanceData d = instances[eid];\n"
	"    float c = cos(iXform.z); float s = sin(iXform.z);\n"
	"    vec2 p = aPos * iXform.w;\n"
	"    p = vec2(c * p.x - s * p.y, s * p.x + c * p.y) + iXform.xy;\n"
	"    mat4 m = (d.b.y > 0.5) ? hudProj : viewProj;\n"
	"    gl_Position = m * vec4(p, 0.0, 1.0);\n"
	"    vColor = iColor; vEdge = aEdge; vA = d.a;\n"
	"}\n";

	inline const char* entityFS =
	"#version 460 core\n"
	"layout(location = 0) in vec4 vColor;\n"
	"layout(location = 1) in float vEdge;\n"
	"layout(location = 2) flat in vec4 vA;\n"
	"layout(location = 0) out vec4 FragColor;\n"
	LR_FRAME_UBO
	"struct Material { vec4 core; vec4 rim; vec4 style; };\n"
	"layout(std430, binding = 2) readonly buffer Materials { Material mats[]; };\n"
	"void main() {\n"
	"    Material m = mats[int(vA.x + 0.5)];\n"
	"    float e = clamp(vEdge, 0.0, 1.0);\n"
	"    float g = (m.style.x <= 0.0) ? 1.0 : pow(e, m.style.x);\n"
	"    vec3 base = mix(m.core.rgb, m.rim.rgb, g);\n"
	"    float pulse = 1.0 + m.style.z * sin(timeInfo.x * m.style.y + vA.w);\n"
	"    vec3 col = base * vColor.rgb * pulse * m.style.w;\n"
	"    col = mix(col, vec3(1.0), clamp(vA.y, 0.0, 1.0) * 0.85);\n"
	"    float alpha = mix(m.core.a, m.rim.a, g) * vColor.a * vA.z;\n"
	"    FragColor = vec4(col, alpha);\n"
	"}\n";

	// ------------------------------------------------------------ particle draw
	// Own VAO: loc 0 quad corner (per vertex), loc 1..4 Particle (per instance, divisor 1)
	inline const char* particleVS =
	"#version 460 core\n"
	"layout(location = 0) in vec2 aCorner;\n"
	"layout(location = 1) in vec2 iPos;\n"
	"layout(location = 2) in vec2 iVel;\n"
	"layout(location = 3) in vec4 iColor;\n"
	"layout(location = 4) in vec4 iMisc;\n"
	LR_FRAME_UBO
	"layout(location = 0) out vec2 vCorner;\n"
	"layout(location = 1) out vec4 vColor;\n"
	"void main() {\n"
	"    if (iMisc.x <= 0.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vCorner = vec2(0.0); vColor = vec4(0.0); return; }\n"
	"    float t = clamp(iMisc.x / iMisc.y, 0.0, 1.0);\n"
	"    float size = iMisc.z * (0.35 + 0.65 * t);\n"
	"    float sp = length(iVel);\n"
	"    vec2 ax = (sp > 0.001) ? iVel / sp : vec2(1.0, 0.0);\n"
	"    vec2 ay = vec2(-ax.y, ax.x);\n"
	"    float len = size * (1.0 + sp * 0.012);\n"
	"    vec2 world = iPos + ax * aCorner.x * len + ay * aCorner.y * size;\n"
	"    gl_Position = viewProj * vec4(world, 0.0, 1.0);\n"
	"    vCorner = aCorner; vColor = vec4(iColor.rgb, iColor.a * t);\n"
	"}\n";

	inline const char* particleFS =
	"#version 460 core\n"
	"layout(location = 0) in vec2 vCorner;\n"
	"layout(location = 1) in vec4 vColor;\n"
	"layout(location = 0) out vec4 FragColor;\n"
	"void main() {\n"
	"    float r = length(vCorner);\n"
	"    float a = 1.0 - smoothstep(0.0, 1.0, r);\n"
	"    a *= a;\n"
	"    FragColor = vec4(vColor.rgb * 1.5, a * vColor.a);\n"      // blended SRC_ALPHA, ONE (additive)
	"}\n";

	// ------------------------------------------------------------- particle sim
	// One dispatch per frame: spawn (ring ranges assigned on the CPU, no atomics) + integrate.
	inline const char* particleCS =
	"#version 460 core\n"
	"layout(local_size_x = 256) in;\n"
	"struct Particle { vec2 pos; vec2 vel; vec4 color; vec4 misc; };\n"
	"struct EmitCmd { vec4 posVel; vec4 color; vec4 shape; vec4 life; uvec4 range; };\n"
	"layout(std430, binding = 1) buffer Particles { Particle parts[]; };\n"
	"layout(std430, binding = 3) readonly buffer Events { uvec4 header; vec4 sim; EmitCmd cmds[]; };\n"
	"uint pcg(uint v) {\n"
	"    uint state = v * 747796405u + 2891336453u;\n"
	"    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;\n"
	"    return (word >> 22u) ^ word;\n"
	"}\n"
	"float rnd(inout uint s) { s = pcg(s); return float(s) * (1.0 / 4294967296.0); }\n"
	"void main() {\n"
	"    uint N = uint(parts.length());\n"
	"    uint gid = gl_GlobalInvocationID.x;\n"
	"    if (gid >= N) return;\n"
	"    Particle p = parts[gid];\n"
	"    float dt = sim.x;\n"
	"    if ((header.y & 1u) != 0u) { p.misc.x = 0.0; parts[gid] = p; return; }\n"
	"    bool spawned = false;\n"
	"    for (uint c = 0u; c < header.x; c++) {\n"
	"        EmitCmd e = cmds[c];\n"
	"        uint rel = (gid + N - e.range.x) % N;\n"
	"        if (rel < e.range.y) {\n"
	"            uint s = e.range.z * 747796405u + gid * 2891336453u + 12345u;\n"
	"            float r1 = rnd(s); float r2 = rnd(s); float r3 = rnd(s); float r4 = rnd(s);\n"
	"            float ang = e.shape.x + (r1 - 0.5) * e.shape.y;\n"
	"            float spd = mix(e.shape.z, e.shape.w, r2);\n"
	"            float life = mix(e.life.x, e.life.y, r3);\n"
	"            p.pos = e.posVel.xy;\n"
	"            p.vel = e.posVel.zw + vec2(cos(ang), sin(ang)) * spd;\n"
	"            p.misc = vec4(life, life, e.life.z * (0.6 + 0.8 * r4), e.life.w);\n"
	"            p.color = vec4(e.color.rgb * (0.75 + 0.5 * r4), e.color.a);\n"
	"            spawned = true;\n"
	"            break;\n"
	"        }\n"
	"    }\n"
	"    if (!spawned && p.misc.x > 0.0) {\n"
	"        p.vel *= exp(-p.misc.w * dt);\n"
	"        p.pos += p.vel * dt;\n"
	"        p.misc.x -= dt;\n"
	"    }\n"
	"    parts[gid] = p;\n"
	"}\n";
}}
