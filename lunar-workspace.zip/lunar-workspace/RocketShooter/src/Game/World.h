#pragma once
#include "GameTypes.h"
#include "Pool.h"
#include "Meshes.h"
#include "Font.h"

// ============================================================================
//  LUNAR RIFT - the simulation. No GL calls in here: it runs on the update thread,
//  mutates the dense pools and fills one frame slot of the Scene per Tick().
// ============================================================================
namespace game
{
	struct Rng
	{
		uint32_t s = 0x9E3779B9u;
		uint32_t Next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
		float F() { return (Next() >> 8) * (1.0f / 16777216.0f); }
		float R(float a, float b) { return a + (b - a) * F(); }
		int   I(int n) { return (int)(F() * (float)n) % n; }
	};

	struct SPlayer   { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float angle = 0; };
	struct SBullet   { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float life = 0; };
	struct SAsteroid { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float angle = 0, spin = 0, flash = 0, shade = 1; int size = 3, hp = 3; };
	struct SDrone    { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float angle = 0, flash = 0, phase = 0; int hp = 2; };
	struct SGunner   { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float angle = 0, flash = 0, cd = 1.5f, burstT = 0, orbit = 1; int hp = 5, burst = 0; };
	struct SPickup   { vec2 pos{ 0, 0 }, vel{ 0, 0 }; float life = 12, t = 0; int type = 0; };
	struct SRing     { vec2 pos{ 0, 0 }; float t = 0, dur = 1, r0 = 10, r1 = 100; vec4 color{ 1, 1, 1, 1 }; bool follow = false; };
	struct SNone     {};

	enum class State { Title, Playing, GameOver };

	class World
	{
	public:
		// ------------------------------------------------------------------ setup
		void Init(GameScene& scene)
		{
			m_Scene = &scene;
			m_Store = std::make_unique<GameStore>(scene);

			// Render data of every live entity is rebuilt each frame (BuildRender), so these columns do not need to
			// follow an entity when it is removed (followsEntity = false). Upload() copies them into the frame slot.
			m_XfCol  = m_Store->AddGpuColumn<vec4>(offsetof(IVBData, xform), false);
			m_ColCol = m_Store->AddGpuColumn<vec4>(offsetof(IVBData, color), false);
			m_IsbCol = m_Store->AddIsbColumn<ISBData>(false);
			xf = m_Store->Data(m_XfCol); col = m_Store->Data(m_ColCol); isb = m_Store->Data(m_IsbCol);

			pickups.Init(scene, *m_Store);   asteroids.Init(scene, *m_Store);
			drones.Init(scene, *m_Store);    gunners.Init(scene, *m_Store);
			ebullets.Init(scene, *m_Store);  pbullets.Init(scene, *m_Store);
			player.Init(scene, *m_Store);    rings.Init(scene, *m_Store);
			hud.Init(scene, *m_Store);
			m_Rng.s ^= (uint32_t)std::chrono::steady_clock::now().time_since_epoch().count() | 1u;
			ResetToTitle();
		}

		// ------------------------------------------------------------ per-frame tick
		// Returns the real dt that the GPU particle pass should integrate with.
		void Tick(float dt, Input& in)
		{
			const uint32_t keys = in.keys.load(std::memory_order_relaxed);
			const uint32_t pressed = in.pressed.exchange(0, std::memory_order_acq_rel);
			m_Mouse = vec2(in.mouseX.load(std::memory_order_relaxed), in.mouseY.load(std::memory_order_relaxed));
			m_FrameDt = m_Paused ? 0.0f : dt;
			m_Emits.clear();
			m_ClearParticles = false;

			if ((pressed & P_PAUSE) && m_State == State::Playing) m_Paused = !m_Paused;
			if (pressed & P_NOVA) m_NovaRequest = true;

			if (m_State == State::Title && (pressed & P_START)) StartGame();
			else if (m_State == State::GameOver && m_StateT > 1.2f && (pressed & P_START)) StartGame();

			if (!m_Paused)
			{
				m_Acc += dt;
				int n = 0;
				while (m_Acc >= STEP && n < 8) { Step(STEP, keys); m_Acc -= STEP; n++; }
				if (m_Acc > STEP * 8) m_Acc = 0;
			}
			m_Time += dt;
			BuildRender();
		}

		// Fill one frame slot: instance data of every unit, draw commands, GPU events, UBO packet.
		void WriteFrame(GameScene::UpdateChache* u, FramePacket& pk, EmitBlock* evSlice)
		{
			m_Store->Upload(u);     // live range of every unit -> this frame's slot, plus the draw commands

			// GPU particle events for this frame (lives in the per-frame events SSBO)
			EmitBlock blk;
			std::memset(&blk, 0, sizeof(uint32_t) * 8);
			blk.header[0] = (uint32_t)m_Emits.size();
			blk.header[1] = m_ClearParticles ? 1u : 0u;
			blk.sim[0] = m_FrameDt; blk.sim[1] = m_Time;
			for (size_t i = 0; i < m_Emits.size(); i++) blk.cmds[i] = m_Emits[i];
			std::memcpy(evSlice, &blk, offsetof(EmitBlock, cmds) + sizeof(EmitCmd) * m_Emits.size());

			// UBO contents (camera is fixed; shake shifts the world, hud ignores it)
			const float sx = 2.0f / WORLD_W, sy = 2.0f / WORLD_H;
			glm::mat4 vp(1.0f), hp(1.0f);
			vp[0][0] = sx; vp[1][1] = sy; vp[3][0] = -m_ShakeOff.x * sx; vp[3][1] = -m_ShakeOff.y * sy;
			hp[0][0] = sx; hp[1][1] = sy;
			pk.ubo.viewProj = vp; pk.ubo.hudProj = hp;
			pk.ubo.timeInfo = vec4(m_Time, m_FrameDt, m_Flash, 0.0f);
			pk.ubo.camInfo = vec4(m_Player.pos.x + m_Time * 6.0f, m_Player.pos.y, WORLD_W, WORLD_H);
			pk.ubo.ints[0] = 0;
			pk.ubo.ints[1] = u->frameNo; pk.ubo.ints[2] = 0; pk.ubo.ints[3] = 0;
			pk.emitCount = blk.header[0]; pk.flags = blk.header[1];
		}

		size_t TotalEntities() const
		{
			return (size_t)(pickups.Count() + asteroids.Count() + drones.Count() + gunners.Count() + ebullets.Count()
				+ pbullets.Count() + player.Count() + rings.Count() + hud.Count());
		}
		int Score() const { return m_Score; }
		int Wave() const { return m_Wave; }
		void Seed(uint32_t s) { m_Rng.s = s; }       // deterministic runs (replays, tests/world_diff.cpp)

		// one packet per frame slot (update thread writes it before UpdateEnd, render thread reads it after RenderStart)
		FramePacket packets[3];

		// pools are public: the app prints per-unit stats from them
		Pool<KPickup, SPickup>        pickups;
		Pool<KAsteroid, SAsteroid>    asteroids;
		Pool<KDrone, SDrone>          drones;
		Pool<KGunner, SGunner>        gunners;
		Pool<KEnemyBullet, SBullet>   ebullets;
		Pool<KPlayerBullet, SBullet>  pbullets;
		Pool<KPlayer, SPlayer>        player;
		Pool<KRing, SRing>            rings;
		Pool<KHud, SNone>             hud;

	private:
		static constexpr float STEP = 1.0f / 120.0f;

		// ------------------------------------------------------------- state flow
		void ClearAll()
		{
			pickups.Clear(); asteroids.Clear(); drones.Clear(); gunners.Clear(); ebullets.Clear();
			pbullets.Clear(); player.Clear(); rings.Clear(); hud.Clear();
			m_ClearParticles = true;
		}

		void ResetToTitle()
		{
			ClearAll();
			m_State = State::Title; m_StateT = 0; m_Paused = false;
			m_Player = SPlayer{};
		}

		void StartGame()
		{
			ClearAll();
			m_State = State::Playing; m_StateT = 0; m_Paused = false;
			m_Player = SPlayer{};
			SPlayer sp; player.Add(sp);
			m_Hp = 10; m_Invuln = 1.5f; m_FireCd = 0; m_RapidT = m_SpreadT = m_ShieldT = 0; m_Nova = 1;
			m_Score = 0; m_Wave = 0; m_WaveDelay = 0.5f; m_NovaRequest = false; m_Thrust = 0;
			m_SpawnT = 0; m_RemA = m_RemD = m_RemG = 0; m_Shake = 0; m_Flash = 0;
		}

		void StartWave(int n)
		{
			m_Wave = n;
			m_RemA = std::min(3 + n, 10);
			m_RemD = std::min(2 + n + n / 2, 16);
			m_RemG = n >= 2 ? std::min(n - 1, 5) : 0;
			m_SpawnT = 0.3f;
			m_BannerT = 2.2f;
		}

		// ------------------------------------------------------------------- fx
		void Emit(vec2 pos, vec2 vel, vec4 color, float angle, float spread, float spMin, float spMax,
			float lMin, float lMax, float size, float drag, int count)
		{
			if ((int)m_Emits.size() >= MAX_EMIT || count <= 0) return;
			count = std::min(count, MAX_PARTICLES / 8);
			EmitCmd c;
			c.posVel = vec4(pos.x, pos.y, vel.x, vel.y);
			c.color = color;
			c.shape = vec4(angle, spread, spMin, spMax);
			c.life = vec4(lMin, lMax, size, drag);
			c.range[0] = m_EmitCursor; c.range[1] = (uint32_t)count; c.range[2] = m_Rng.Next(); c.range[3] = 0;
			m_EmitCursor = (m_EmitCursor + (uint32_t)count) % (uint32_t)MAX_PARTICLES;
			m_Emits.push_back(c);
		}
		void Explosion(vec2 pos, vec4 color, int count, float speed)
		{
			Emit(pos, vec2(0), color, 0, TAU, speed * 0.15f, speed, 0.35f, 1.0f, 6.0f, 2.2f, count);
			Emit(pos, vec2(0), vec4(1, 0.9f, 0.7f, 1), 0, TAU, speed * 0.1f, speed * 0.5f, 0.2f, 0.5f, 9.0f, 3.0f, count / 4);
		}
		void Sparks(vec2 pos, vec4 color, int count) { Emit(pos, vec2(0), color, 0, TAU, 80, 300, 0.15f, 0.45f, 4.0f, 3.0f, count); }
		void Shake(float a) { m_Shake = std::max(m_Shake, a); }
		void AddRing(vec2 pos, float r0, float r1, float dur, vec4 color, bool follow = false)
		{
			SRing r; r.pos = pos; r.r0 = r0; r.r1 = r1; r.dur = dur; r.color = color; r.follow = follow;
			rings.Add(r);
		}

		// ------------------------------------------------------------------- step
		void Step(float h, uint32_t keys)
		{
			m_StateT += h;
			m_Shake *= std::exp(-7.0f * h);
			m_Flash *= std::exp(-5.0f * h);
			if (m_Shake > 0.05f) m_ShakeOff = vec2(m_Rng.R(-1, 1), m_Rng.R(-1, 1)) * m_Shake; else m_ShakeOff = vec2(0);
			if (m_BannerT > 0) m_BannerT -= h;

			UpdateRings(h);
			UpdateAsteroids(h);

			if (m_State == State::Title)
			{
				m_SpawnT -= h;
				if (m_SpawnT <= 0) { m_SpawnT = 1.2f; if (asteroids.Count() < 7) SpawnAsteroid(3, vec2(0), true); }
				return;
			}
			if (m_State == State::GameOver)
			{
				UpdateDrones(h); UpdateGunners(h); UpdateBullets(h); UpdatePickups(h, false);
				return;
			}

			UpdatePlayer(h, keys);
			UpdateWaves(h);
			UpdateDrones(h);
			UpdateGunners(h);
			UpdateBullets(h);
			UpdatePickups(h, true);
			Collide();
		}

		void UpdatePlayer(float h, uint32_t keys)
		{
			vec2 dir(0);
			if (keys & K_UP) dir.y += 1; if (keys & K_DOWN) dir.y -= 1;
			if (keys & K_LEFT) dir.x -= 1; if (keys & K_RIGHT) dir.x += 1;
			const bool moving = glm::length(dir) > 0.1f;
			if (moving) dir = glm::normalize(dir);
			SPlayer& p = m_Player;
			p.vel += dir * 3000.0f * h;
			p.vel *= std::exp(-4.2f * h);
			const float sp = glm::length(p.vel);
			if (sp > 560.0f) p.vel *= 560.0f / sp;
			p.pos += p.vel * h;
			const float mx = WORLD_W * 0.5f - 24, my = WORLD_H * 0.5f - 24;
			p.pos.x = std::max(-mx, std::min(mx, p.pos.x));
			p.pos.y = std::max(-my, std::min(my, p.pos.y));
			vec2 aim = m_Mouse - p.pos;
			if (glm::length(aim) > 6.0f) p.angle = std::atan2(aim.y, aim.x);
			if (moving) m_Thrust += h;

			m_Invuln = std::max(0.0f, m_Invuln - h);
			m_FireCd = std::max(0.0f, m_FireCd - h);
			m_RapidT = std::max(0.0f, m_RapidT - h);
			m_SpreadT = std::max(0.0f, m_SpreadT - h);
			m_ShieldT = std::max(0.0f, m_ShieldT - h);

			if ((keys & K_FIRE) && m_FireCd <= 0) FirePlayer();
			if (m_NovaRequest) { m_NovaRequest = false; if (m_Nova > 0) TriggerNova(); }

			// shield bubble = one follow-ring while the shield is up
			bool hasShield = false;
			for (int i = rings.Count() - 1; i >= 0; --i)
				if (rings[i].follow) { if (m_ShieldT > 0) hasShield = true; else rings.Remove(i); }
			if (m_ShieldT > 0 && !hasShield) AddRing(p.pos, 34, 34, 1e9f, vec4(0.4f, 0.8f, 1.0f, 0.9f), true);
		}

		void FirePlayer()
		{
			const SPlayer& p = m_Player;
			m_FireCd = m_RapidT > 0 ? 0.065f : 0.12f;
			const int n = m_SpreadT > 0 ? 3 : 1;
			for (int i = 0; i < n; i++)
			{
				const float a = p.angle + (n == 1 ? 0.0f : (i - 1) * 0.17f) + m_Rng.R(-0.015f, 0.015f);
				SBullet b; b.vel = vec2(std::cos(a), std::sin(a)) * 1150.0f + p.vel * 0.25f;
				b.pos = p.pos + vec2(std::cos(p.angle), std::sin(p.angle)) * 26.0f; b.life = 1.0f;
				pbullets.Add(b);
			}
			Emit(p.pos + vec2(std::cos(p.angle), std::sin(p.angle)) * 28.0f, p.vel, vec4(0.5f, 1, 0.9f, 1), p.angle, 0.6f, 100, 380, 0.06f, 0.16f, 3.0f, 4.0f, 3);
		}

		void TriggerNova()
		{
			m_Nova--;
			const vec2 c = m_Player.pos;
			const float R = 480.0f;
			AddRing(c, 20, R, 0.7f, vec4(1, 0.4f, 1, 1));
			AddRing(c, 10, R * 0.7f, 0.5f, vec4(0.6f, 0.9f, 1, 1));
			Emit(c, vec2(0), vec4(1, 0.5f, 1, 1), 0, TAU, 300, 1100, 0.5f, 1.3f, 7.0f, 1.8f, 900);
			Emit(c, vec2(0), vec4(0.6f, 0.9f, 1, 1), 0, TAU, 100, 700, 0.4f, 1.0f, 5.0f, 2.2f, 500);
			Shake(22); m_Flash = 1.0f;
			ebullets.Clear();
			for (int i = asteroids.Count() - 1; i >= 0; --i) if (glm::length(asteroids[i].pos - c) < R) DamageAsteroid(i, 5);
			for (int i = drones.Count() - 1; i >= 0; --i)    if (glm::length(drones[i].pos - c) < R)    DamageDrone(i, 5);
			for (int i = gunners.Count() - 1; i >= 0; --i)   if (glm::length(gunners[i].pos - c) < R)   DamageGunner(i, 5);
		}

		void HurtPlayer(int dmg, vec2 from)
		{
			if (m_Invuln > 0 || player.Count() == 0) return;
			if (m_ShieldT > 0)
			{
				m_Invuln = 0.25f; Shake(5);
				AddRing(m_Player.pos, 34, 70, 0.3f, vec4(0.4f, 0.8f, 1, 1));
				Sparks(from, vec4(0.4f, 0.8f, 1, 1), 14);
				return;
			}
			m_Hp -= dmg; m_Invuln = 1.1f; Shake(16); m_Flash = 0.6f;
			Explosion(m_Player.pos, vec4(1, 0.25f, 0.2f, 1), 40, 380);
			if (m_Hp <= 0)
			{
				m_Hp = 0;
				Explosion(m_Player.pos, vec4(0.4f, 1, 0.9f, 1), 140, 700);
				AddRing(m_Player.pos, 10, 260, 0.9f, vec4(0.4f, 1, 0.9f, 1));
				Shake(30); m_Flash = 1.0f;
				player.Clear();
				m_Hi = std::max(m_Hi, m_Score);
				m_State = State::GameOver; m_StateT = 0;
			}
		}

		// -------------------------------------------------------------- waves/spawns
		vec2 EdgePoint(float margin)
		{
			const float hw = WORLD_W * 0.5f + margin, hh = WORLD_H * 0.5f + margin;
			switch (m_Rng.I(4))
			{
			case 0: return vec2(-hw, m_Rng.R(-hh, hh));
			case 1: return vec2(hw, m_Rng.R(-hh, hh));
			case 2: return vec2(m_Rng.R(-hw, hw), -hh);
			default: return vec2(m_Rng.R(-hw, hw), hh);
			}
		}

		static float AsteroidRadius(int size) { return size == 3 ? 58.0f : size == 2 ? 36.0f : 20.0f; }

		void SpawnAsteroid(int size, vec2 at, bool atEdge)
		{
			SAsteroid a;
			a.size = size; a.hp = size;
			a.pos = atEdge ? EdgePoint(70) : at;
			const vec2 target(m_Rng.R(-300, 300), m_Rng.R(-200, 200));
			vec2 d = target - a.pos; d = glm::normalize(d);
			a.vel = d * m_Rng.R(50.0f, 110.0f) * (size == 1 ? 1.8f : 1.0f);
			a.angle = m_Rng.R(0, TAU); a.spin = m_Rng.R(-1.2f, 1.2f); a.shade = m_Rng.R(0.75f, 1.1f);
			asteroids.Add(a);
		}
		void SpawnDrone()
		{
			SDrone d; d.pos = EdgePoint(40); d.phase = m_Rng.R(0, TAU); drones.Add(d);
		}
		void SpawnGunner()
		{
			SGunner g; g.pos = EdgePoint(50); g.orbit = m_Rng.F() < 0.5f ? 1.0f : -1.0f; g.cd = m_Rng.R(1.0f, 2.2f); gunners.Add(g);
		}

		void UpdateWaves(float h)
		{
			if (m_WaveDelay > 0) { m_WaveDelay -= h; if (m_WaveDelay <= 0) StartWave(m_Wave + 1); return; }
			const int remaining = m_RemA + m_RemD + m_RemG;
			if (remaining > 0)
			{
				m_SpawnT -= h;
				if (m_SpawnT <= 0)
				{
					m_SpawnT = std::max(0.25f, 0.8f - m_Wave * 0.04f);
					int pick = m_Rng.I(remaining);
					if (pick < m_RemA) { SpawnAsteroid(3, vec2(0), true); m_RemA--; }
					else if (pick < m_RemA + m_RemD) { SpawnDrone(); m_RemD--; }
					else { SpawnGunner(); m_RemG--; }
				}
			}
			else if (asteroids.Count() + drones.Count() + gunners.Count() == 0) m_WaveDelay = 2.0f;
		}

		// ------------------------------------------------------------- enemy updates
		void UpdateAsteroids(float h)
		{
			const float hw = WORLD_W * 0.5f, hh = WORLD_H * 0.5f;
			for (int i = 0; i < asteroids.Count(); i++)
			{
				SAsteroid& a = asteroids[i];
				a.pos += a.vel * h; a.angle += a.spin * h; a.flash = std::max(0.0f, a.flash - h * 6.0f);
				const float r = AsteroidRadius(a.size) + 6;
				if (a.pos.x > hw + r) a.pos.x = -hw - r; else if (a.pos.x < -hw - r) a.pos.x = hw + r;
				if (a.pos.y > hh + r) a.pos.y = -hh - r; else if (a.pos.y < -hh - r) a.pos.y = hh + r;
			}
		}

		void UpdateDrones(float h)
		{
			for (int i = 0; i < drones.Count(); i++)
			{
				SDrone& d = drones[i];
				vec2 to = m_Player.pos - d.pos; const float dist = glm::length(to);
				if (dist > 1.0f) to /= dist;
				const float maxSp = 190.0f + m_Wave * 9.0f;
				vec2 side(-to.y, to.x);
				d.vel += (to + side * std::sin(m_Time * 2.0f + d.phase) * 0.6f) * 520.0f * h;
				d.vel *= std::exp(-1.6f * h);
				const float sp = glm::length(d.vel);
				if (sp > maxSp) d.vel *= maxSp / sp;
				d.pos += d.vel * h;
				d.angle = std::atan2(d.vel.y, d.vel.x);
				d.flash = std::max(0.0f, d.flash - h * 6.0f);
			}
		}

		void UpdateGunners(float h)
		{
			for (int i = 0; i < gunners.Count(); i++)
			{
				SGunner& g = gunners[i];
				vec2 to = m_Player.pos - g.pos; const float dist = glm::length(to);
				if (dist > 1.0f) to /= dist;
				vec2 side(-to.y, to.x);
				const float want = 380.0f;
				vec2 steer = to * ((dist - want) * 0.9f) + side * (g.orbit * 110.0f);
				g.vel += steer * 2.2f * h;
				g.vel *= std::exp(-1.8f * h);
				const float sp = glm::length(g.vel);
				if (sp > 170.0f) g.vel *= 170.0f / sp;
				g.pos += g.vel * h;
				g.angle = std::atan2(to.y, to.x);
				g.flash = std::max(0.0f, g.flash - h * 6.0f);

				g.cd -= h;
				if (g.burst > 0)
				{
					g.burstT -= h;
					if (g.burstT <= 0) { g.burstT = 0.11f; g.burst--; FireEnemy(g.pos, g.angle, 400.0f + m_Wave * 10.0f); }
				}
				else if (g.cd <= 0) { g.burst = 3; g.burstT = 0; g.cd = m_Rng.R(1.8f, 2.8f); }
			}
		}

		void FireEnemy(vec2 pos, float angle, float speed)
		{
			SBullet b; b.pos = pos + vec2(std::cos(angle), std::sin(angle)) * 28.0f;
			b.vel = vec2(std::cos(angle), std::sin(angle)) * speed; b.life = 5.0f;
			ebullets.Add(b);
		}

		void UpdateBullets(float h)
		{
			const float hw = WORLD_W * 0.5f + 30, hh = WORLD_H * 0.5f + 30;
			for (int i = pbullets.Count() - 1; i >= 0; --i)
			{
				SBullet& b = pbullets[i];
				b.pos += b.vel * h; b.life -= h;
				if (b.life <= 0 || std::fabs(b.pos.x) > hw || std::fabs(b.pos.y) > hh) pbullets.Remove(i);
			}
			for (int i = ebullets.Count() - 1; i >= 0; --i)
			{
				SBullet& b = ebullets[i];
				b.pos += b.vel * h; b.life -= h;
				if (b.life <= 0 || std::fabs(b.pos.x) > hw || std::fabs(b.pos.y) > hh) ebullets.Remove(i);
			}
		}

		void UpdateRings(float h)
		{
			for (int i = rings.Count() - 1; i >= 0; --i)
			{
				SRing& r = rings[i];
				if (r.follow) { r.pos = m_Player.pos; continue; }
				r.t += h;
				if (r.t >= r.dur) rings.Remove(i);
			}
		}

		void UpdatePickups(float h, bool active)
		{
			for (int i = pickups.Count() - 1; i >= 0; --i)
			{
				SPickup& p = pickups[i];
				p.t += h; p.life -= h;
				p.pos += p.vel * h; p.vel *= std::exp(-1.5f * h);
				if (active && player.Count() > 0)
				{
					vec2 to = m_Player.pos - p.pos; const float d = glm::length(to);
					if (d < 170.0f && d > 1.0f) p.pos += (to / d) * (260.0f * (1.0f - d / 170.0f) + 60.0f) * h;
					if (d < 30.0f) { Collect(p.type, p.pos); pickups.Remove(i); continue; }
				}
				if (p.life <= 0) pickups.Remove(i);
			}
		}

		static vec4 PickupColor(int type)
		{
			static const vec4 c[5] = { vec4(1, 0.9f, 0.2f, 1), vec4(0.2f, 0.9f, 1, 1), vec4(0.4f, 0.6f, 1, 1), vec4(0.3f, 1, 0.4f, 1), vec4(1, 0.3f, 1, 1) };
			return c[type % 5];
		}

		void Collect(int type, vec2 at)
		{
			switch (type)
			{
			case 0: m_RapidT = 10.0f; break;
			case 1: m_SpreadT = 10.0f; break;
			case 2: m_ShieldT = 8.0f; break;
			case 3: m_Hp = std::min(10, m_Hp + 4); break;
			default: m_Nova = std::min(3, m_Nova + 1); break;
			}
			m_Score += 50;
			AddRing(at, 8, 60, 0.4f, PickupColor(type));
			Emit(at, vec2(0), PickupColor(type), 0, TAU, 60, 260, 0.3f, 0.8f, 4.0f, 2.5f, 26);
		}

		void MaybeDrop(vec2 at, float chance)
		{
			if (m_Rng.F() > chance) return;
			SPickup p; p.pos = at; p.type = m_Rng.I(5);
			p.vel = vec2(m_Rng.R(-60, 60), m_Rng.R(-60, 60));
			pickups.Add(p);
		}

		// ---------------------------------------------------------------- damage
		void DamageAsteroid(int i, int dmg)
		{
			SAsteroid& a = asteroids[i];
			a.hp -= dmg; a.flash = 1.0f;
			if (a.hp > 0) { Sparks(a.pos, vec4(1, 0.7f, 0.4f, 1), 6); return; }
			const SAsteroid dead = a;
			m_Score += 20 * dead.size;
			Explosion(dead.pos, vec4(1.0f, 0.6f, 0.3f, 1), 14 + dead.size * 10, 120.0f + dead.size * 90.0f);
			AddRing(dead.pos, AsteroidRadius(dead.size) * 0.5f, AsteroidRadius(dead.size) * 2.2f, 0.4f, vec4(1, 0.7f, 0.4f, 1));
			Shake(2.0f + dead.size * 2.0f);
			asteroids.Remove(i);
			if (dead.size > 1)
				for (int k = 0; k < 2; k++)
				{
					SAsteroid c; c.size = dead.size - 1; c.hp = c.size; c.pos = dead.pos + vec2(m_Rng.R(-10, 10), m_Rng.R(-10, 10));
					const float ang = m_Rng.R(0, TAU);
					c.vel = dead.vel * 0.4f + vec2(std::cos(ang), std::sin(ang)) * m_Rng.R(80.0f, 170.0f);
					c.angle = m_Rng.R(0, TAU); c.spin = m_Rng.R(-2.0f, 2.0f); c.shade = m_Rng.R(0.75f, 1.1f);
					asteroids.Add(c);
				}
			MaybeDrop(dead.pos, 0.04f);
		}

		void DamageDrone(int i, int dmg)
		{
			SDrone& d = drones[i];
			d.hp -= dmg; d.flash = 1.0f;
			if (d.hp > 0) { Sparks(d.pos, vec4(1, 0.4f, 0.8f, 1), 6); return; }
			const vec2 at = d.pos;
			m_Score += 100;
			Explosion(at, vec4(1, 0.25f, 0.7f, 1), 40, 420);
			AddRing(at, 10, 90, 0.35f, vec4(1, 0.3f, 0.8f, 1));
			Shake(4);
			drones.Remove(i);
			MaybeDrop(at, 0.12f);
		}

		void DamageGunner(int i, int dmg)
		{
			SGunner& g = gunners[i];
			g.hp -= dmg; g.flash = 1.0f;
			if (g.hp > 0) { Sparks(g.pos, vec4(1, 0.6f, 0.2f, 1), 8); return; }
			const vec2 at = g.pos;
			m_Score += 250;
			Explosion(at, vec4(1, 0.7f, 0.2f, 1), 70, 520);
			AddRing(at, 14, 140, 0.45f, vec4(1, 0.8f, 0.3f, 1));
			Shake(7);
			gunners.Remove(i);
			MaybeDrop(at, 0.35f);
		}

		void Collide()
		{
			// player bullets vs targets (backwards so swap-remove is safe)
			for (int bi = pbullets.Count() - 1; bi >= 0; --bi)
			{
				const vec2 bp = pbullets[bi].pos;
				bool hit = false;
				for (int i = asteroids.Count() - 1; i >= 0 && !hit; --i)
					if (glm::length(asteroids[i].pos - bp) < AsteroidRadius(asteroids[i].size) + 6) { DamageAsteroid(i, 1); hit = true; }
				for (int i = drones.Count() - 1; i >= 0 && !hit; --i)
					if (glm::length(drones[i].pos - bp) < 22) { DamageDrone(i, 1); hit = true; }
				for (int i = gunners.Count() - 1; i >= 0 && !hit; --i)
					if (glm::length(gunners[i].pos - bp) < 30) { DamageGunner(i, 1); hit = true; }
				if (hit) pbullets.Remove(bi);
			}
			if (player.Count() == 0) return;

			const vec2 pp = m_Player.pos;
			for (int i = ebullets.Count() - 1; i >= 0; --i)
				if (glm::length(ebullets[i].pos - pp) < 7 + 16)
				{
					const vec2 at = ebullets[i].pos; ebullets.Remove(i); HurtPlayer(1, at);
					if (player.Count() == 0) return;
				}
			for (int i = asteroids.Count() - 1; i >= 0; --i)
				if (glm::length(asteroids[i].pos - pp) < AsteroidRadius(asteroids[i].size) * 0.85f + 14)
				{
					if (m_Invuln <= 0) { const vec2 at = asteroids[i].pos; HurtPlayer(2, at); if (m_ShieldT > 0 || player.Count() > 0) DamageAsteroid(i, 9); }
					if (player.Count() == 0) return;
				}
			for (int i = drones.Count() - 1; i >= 0; --i)
				if (glm::length(drones[i].pos - pp) < 14 + 16)
				{
					if (m_Invuln <= 0) { const vec2 at = drones[i].pos; HurtPlayer(2, at); DamageDrone(i, 9); }
					if (player.Count() == 0) return;
				}
			for (int i = gunners.Count() - 1; i >= 0; --i)
				if (glm::length(gunners[i].pos - pp) < 24 + 16)
				{
					if (m_Invuln <= 0) { const vec2 at = gunners[i].pos; HurtPlayer(2, at); }
					if (player.Count() == 0) return;
				}
		}

		// ------------------------------------------------------------ render build
		void Put(size_t idx, vec2 p, float rot, float scale, vec4 color, int mat, float flash = 0, float alpha = 1, float phase = 0, bool isHud = false)
		{
			xf[idx] = vec4(p.x, p.y, rot, scale);
			col[idx] = color;
			isb[idx].a = vec4((float)mat, flash, alpha, phase);
			isb[idx].b = vec4(0, isHud ? 1.0f : 0.0f, 0, 0);
		}

		void BuildRender()
		{
			// thrusters (one GPU emit per frame)
			if (m_Thrust > 0 && player.Count() > 0)
			{
				const SPlayer& p = m_Player;
				const vec2 tail = p.pos - vec2(std::cos(p.angle), std::sin(p.angle)) * 18.0f;
				const float back = std::atan2(-p.vel.y, -p.vel.x);
				Emit(tail, p.vel * 0.3f, vec4(1, 0.55f, 0.15f, 1), back, 0.5f, 60, 260, 0.15f, 0.4f, 4.5f, 3.5f, std::min(24, 4 + (int)(m_Thrust * 700)));
			}
			m_Thrust = 0;

			for (int i = 0; i < asteroids.Count(); i++)
			{
				const SAsteroid& a = asteroids[i];
				Put(asteroids.Start() + i, a.pos, a.angle, AsteroidRadius(a.size), vec4(a.shade, a.shade, a.shade, 1), M_ASTEROID, a.flash);
			}
			for (int i = 0; i < drones.Count(); i++)
			{
				const SDrone& d = drones[i];
				Put(drones.Start() + i, d.pos, d.angle, 22, vec4(1), M_DRONE, d.flash, 1, d.phase);
			}
			for (int i = 0; i < gunners.Count(); i++)
			{
				const SGunner& g = gunners[i];
				Put(gunners.Start() + i, g.pos, g.angle, 30, vec4(1), M_GUNNER, g.flash, 1, g.cd * 3.0f);
			}
			for (int i = 0; i < ebullets.Count(); i++)
				Put(ebullets.Start() + i, ebullets[i].pos, 0, 9, vec4(1), M_EBULLET, 0, 1, (float)i);
			for (int i = 0; i < pbullets.Count(); i++)
			{
				const SBullet& b = pbullets[i];
				Put(pbullets.Start() + i, b.pos, std::atan2(b.vel.y, b.vel.x), 14, vec4(1), M_PBULLET);
			}
			for (int i = 0; i < pickups.Count(); i++)
			{
				const SPickup& p = pickups[i];
				const float fade = p.life < 3.0f ? (0.4f + 0.6f * std::fabs(std::sin(p.t * 10.0f))) : 1.0f;
				Put(pickups.Start() + i, p.pos + vec2(0, std::sin(p.t * 3.0f) * 4.0f), p.t * 1.5f, 17, PickupColor(p.type), M_PICKUP, 0, fade, p.t * 4.0f);
			}
			for (int i = 0; i < player.Count(); i++)
			{
				const float blink = m_Invuln > 0 ? (std::sin(m_Time * 42.0f) > 0 ? 1.0f : 0.3f) : 1.0f;
				Put(player.Start() + i, m_Player.pos, m_Player.angle, 24, vec4(1), M_PLAYER, 0, blink);
			}
			for (int i = 0; i < rings.Count(); i++)
			{
				const SRing& r = rings[i];
				if (r.follow) { Put(rings.Start() + i, r.pos, 0, r.r0, r.color, M_RING, 0, 0.55f + 0.25f * std::sin(m_Time * 8.0f)); continue; }
				const float k = std::min(1.0f, r.t / r.dur);
				const float e = 1.0f - (1.0f - k) * (1.0f - k);
				Put(rings.Start() + i, r.pos, 0, r.r0 + (r.r1 - r.r0) * e, r.color, M_RING, 0, 1.0f - k);
			}
			BuildHud();
		}

		// ---- immediate-mode HUD: every pixel of the dot-matrix font is one instance of the Hud unit ----
		void HudPix(float x, float y, float cell, vec4 color, float rot = 0.0f)
		{
			const int i = hud.Add(SNone{});
			if (i < 0) return;                                  // budget exhausted: drop the pixel
			Put(hud.Start() + i, vec2(x, y), rot, cell * 0.45f, color, M_FLAT, 0, 1, 0, true);
		}
		float TextWidth(const char* s, float cell) const { return (float)std::strlen(s) * 4.0f * cell - cell; }
		void Text(const char* s, float x, float y, float cell, vec4 color)
		{
			for (; *s; ++s, x += 4.0f * cell)
			{
				const char* g = Glyph(*s);
				if (!g) continue;
				for (int r = 0; r < 5; r++)
					for (int c = 0; c < 3; c++)
						if (g[r * 3 + c] == '1') HudPix(x + c * cell, y - r * cell, cell, color);
			}
		}
		void TextCentered(const char* s, float y, float cell, vec4 color) { Text(s, -TextWidth(s, cell) * 0.5f, y, cell, color); }

		void BuildHud()
		{
			hud.Clear();
			char buf[64];
			const float L = -WORLD_W * 0.5f + 28, T = WORLD_H * 0.5f - 28, B = -WORLD_H * 0.5f + 28;
			const vec4 white(0.85f, 0.95f, 1, 1), dim(0.45f, 0.55f, 0.7f, 1);

			if (m_State == State::Title)
			{
				TextCentered("LUNAR RIFT", 120, 14, vec4(0.5f, 1, 0.9f, 1));
				TextCentered("PRESS SPACE", -30, 6, white);
				TextCentered("WASD MOVE", -110, 4, dim);
				TextCentered("CLICK FIRE", -140, 4, dim);
				if (m_Hi > 0) { std::snprintf(buf, sizeof buf, "BEST %d", m_Hi); TextCentered(buf, -200, 5, vec4(1, 0.8f, 0.3f, 1)); }
				return;
			}

			std::snprintf(buf, sizeof buf, "SCORE %06d", m_Score);
			Text(buf, L, T, 5, white);
			std::snprintf(buf, sizeof buf, "WAVE %d", m_Wave);
			Text(buf, WORLD_W * 0.5f - 28 - TextWidth(buf, 5), T, 5, white);
			std::snprintf(buf, sizeof buf, "BEST %06d", std::max(m_Hi, m_Score));
			Text(buf, -TextWidth(buf, 4) * 0.5f, T, 4, vec4(1, 0.8f, 0.3f, 1));

			for (int i = 0; i < 10; i++)
			{
				const bool on = i < m_Hp;
				const float f = i / 9.0f;
				HudPix(L + 8 + i * 22.0f, B + 8, 18, on ? vec4(1.0f - f * 0.7f, 0.25f + f * 0.75f, 0.3f, 1) : vec4(0.15f, 0.18f, 0.22f, 1));
			}
			for (int i = 0; i < 3; i++)
				HudPix(L + 8 + i * 28.0f, B + 44, 20, i < m_Nova ? vec4(1, 0.35f, 1, 1) : vec4(0.18f, 0.12f, 0.2f, 1), PI * 0.25f);
			// weapon / shield timers as small bars
			float bx = L + 260;
			if (m_RapidT > 0)  { for (int i = 0; i < (int)(m_RapidT) + 1; i++)  HudPix(bx + i * 12.0f, B + 8, 9, PickupColor(0)); bx += 150; }
			if (m_SpreadT > 0) { for (int i = 0; i < (int)(m_SpreadT) + 1; i++) HudPix(bx + i * 12.0f, B + 8, 9, PickupColor(1)); bx += 150; }
			if (m_ShieldT > 0) { for (int i = 0; i < (int)(m_ShieldT) + 1; i++) HudPix(bx + i * 12.0f, B + 8, 9, PickupColor(2)); }

			if (m_Paused) TextCentered("PAUSED", 20, 10, white);
			if (m_State == State::GameOver)
			{
				TextCentered("GAME OVER", 90, 12, vec4(1, 0.3f, 0.3f, 1));
				if (m_StateT > 1.2f) TextCentered("SPACE", -40, 6, white);
			}
			else if (m_BannerT > 0)
			{
				std::snprintf(buf, sizeof buf, "WAVE %d", m_Wave);
				TextCentered(buf, 140, 9, vec4(0.5f, 1, 0.9f, std::min(1.0f, m_BannerT)));
			}
		}

		// ---------------------------------------------------------------- data
		GameScene* m_Scene = nullptr;
		std::unique_ptr<GameStore> m_Store;          // entity data of every unit (update thread only)
		lunar::Column<vec4> m_XfCol, m_ColCol;
		lunar::Column<ISBData> m_IsbCol;
		vec4* xf = nullptr;                          // render data, indexed by slot: Put(pool.Start() + i, ...)
		vec4* col = nullptr;
		ISBData* isb = nullptr;

		Rng m_Rng;
		State m_State = State::Title;
		float m_StateT = 0, m_Time = 0, m_Acc = 0, m_FrameDt = 0.016f;
		bool m_Paused = false, m_NovaRequest = false, m_ClearParticles = false;
		vec2 m_Mouse{ 0, 0 };

		SPlayer m_Player;
		int m_Hp = 10, m_Nova = 1, m_Score = 0, m_Hi = 0, m_Wave = 0;
		float m_Invuln = 0, m_FireCd = 0, m_RapidT = 0, m_SpreadT = 0, m_ShieldT = 0, m_Thrust = 0;
		float m_WaveDelay = 0, m_SpawnT = 0, m_BannerT = 0;
		int m_RemA = 0, m_RemD = 0, m_RemG = 0;

		float m_Shake = 0, m_Flash = 0;
		vec2 m_ShakeOff{ 0, 0 };
		std::vector<EmitCmd> m_Emits;
		uint32_t m_EmitCursor = 0;
	};
}
