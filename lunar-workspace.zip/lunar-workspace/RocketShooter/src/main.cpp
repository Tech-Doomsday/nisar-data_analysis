// ============================================================================
//  ROCKET SHOOTER (Lunar Rift) - the game's entry point.
//  The game itself is game::RiftModule (Game/RiftModule.h); this file only
//  creates the window through the Application and mounts the module.
// ============================================================================
#include "Game/RiftModule.h"

class RiftApp : public lunar::Application
{
public:
	RiftApp() : Application({ .title = "Lunar Rift", .width = 1600, .height = 900 }) {}

	void OnStart() override { Mount<game::RiftModule>(); }
};

LUNAR_MAIN(RiftApp)
