// ============================================================================
//  TESTGAME - the smallest complete game on Lunar. Debug the engine here, copy it to start a new game.
//
//  The shape every game has:
//
//    TestApp  (lunar::Application)   window settings, mounts the module(s)           -> OnStart()
//    TestModule  (lunar::Module)     the game itself
//        OnMount()    main thread, GL ready   build shader + Scene + SceneStorage, listen to events, hand the frame ring to the app
//        OnUpdate()   UPDATE thread, no GL    read input, move / spawn / destroy entities, upload this frame's slot
//        OnRender()   main thread             draw the slot that was written (the app swaps buffers afterwards)
//        OnUnmount()  main thread, GL alive   release anything that must not outlive the context
//
//  Entities live in a SceneStorage: one array per member (SoA), one segment per unit (= one kind of thing = one draw call).
//    Create<Unit>()    appends an entity, returns a Handle that stays valid while the entity lives
//    Destroy(handle)   queued; Flush() applies it (swap-remove: the unit's last entity fills the hole, handles stay valid)
//    RangeOf<Unit>()   the live entities as slots [begin, begin + count): loop over the arrays, no handles needed
//    Upload(slot)      copies the live ranges into this frame's GPU slot
//
//  Upload cost: a column created with UploadMode::OnChange only copies the 64-entity blocks that changed. Creating, removing
//  and moving entities marks blocks by itself; a write through Data() / Get() has to be declared: Touch(column, handle),
//  TouchRange(column, unit, firstSlot, count) ... Colour and rotation never change here, so they are copied only until every frame
//  slot has them; position is touched for the things that moved. SetVerifyUploads(true) reports a forgotten Touch.
//
//  Two ways to read input, both shown below:
//    events   Listen<KeyPressed>(...)    main thread, runs once per press. It must not touch the storage (update thread),
//                                        so it only leaves a note for OnUpdate (an atomic counter)
//    polling  ctx.input.Down(Key::A)     update thread, a snapshot per tick
//
//  Controls:  WASD / arrows move the green triangle   Space shoots   Esc quits
// ============================================================================
#include "LunarApp.h"

#include <atomic>
#include <cmath>
#include <memory>
#include <stdexcept>

using namespace lunar;

// ------------------------------------------------------------------ shaders
static const char* kVertexShader = R"GLSL(
#version 460 core
layout(location = 0) in vec3 aPosition;   // mesh vertex
layout(location = 1) in vec3 iPos;        // per instance
layout(location = 2) in vec3 iRot;        // per instance (unused here)
layout(location = 3) in vec4 iColor;      // per instance
out vec4 vColor;
void main()
{
    vColor = iColor;
    gl_Position = vec4(aPosition + iPos, 1.0);
}
)GLSL";

static const char* kFragmentShader = R"GLSL(
#version 460 core
in vec4 vColor;
layout(location = 0) out vec4 FragColor;
void main() { FragColor = vColor; }
)GLSL";

// ------------------------------------------------------------------ data
// Per-instance data as the GPU reads it (structure-of-arrays on the GPU: one block per member).
// The layout passed to Scene::Init and the offsetof() calls in OnMount must match this struct.
struct InstanceVertexData
{
	glm::vec3 pos;
	glm::vec3 rot;
	glm::vec4 color;
};

// Per-instance data for the instance SSBO (binding 0). Not read by this shader, but the Scene needs the type.
struct InstanceStorageData
{
	glm::mat4 modelMatrix;
	glm::mat2 direction;
	float speed;
	uint32_t isAlive;
};

using TestScene = Scene<InstanceVertexData, InstanceStorageData>;
using TestStore = SceneStorage<TestScene>;

// A "unit" is one kind of thing (one mesh, one draw call, many entities). The tag type names it.
struct Triangle {};   // the player and the drifter
struct Bullet {};

template<class Tag> static void InitTriangleMesh(float r)
{
	float vertices[] = { -r, -r, 0.0f,   r, -r, 0.0f,   0.0f, r, 0.0f };
	unsigned int indices[] = { 0, 1, 2 };
	Object<Tag>::ShapeData.Init(vertices, sizeof(vertices), indices, sizeof(indices));
	Object<Tag>::ShapeData.SetVertexLayout({ {0, 3, GL_FLOAT, sizeof(float) * 3} });
}
template<> void Object<Triangle>::Init() { InitTriangleMesh<Triangle>(0.1f); }
template<> void Object<Bullet>::Init()   { InitTriangleMesh<Bullet>(0.03f); }

// ------------------------------------------------------------------ the game
class TestModule final : public Module
{
public:
	TestModule() : Module("Test", 0) {}

	// main thread, GL context current
	void OnMount() override
	{
		// events: handlers run on the main thread; return true to consume the event
		Listen<events::KeyPressed>([this](events::KeyPressed& e)
		{
			if (e.repeat) return false;
			if (e.key == Key::Escape) { App().Quit(); return true; }
			if (e.key == Key::Space)  { m_Shots.fetch_add(1); return true; }   // note for the update thread
			return false;
		});

		// shader
		m_Shader.AddFragment(ShaderType::VertexShader, kVertexShader);
		m_Shader.AddFragment(ShaderType::FragmentShader, kFragmentShader);
		m_Shader.Compile();

		// scene: mesh vertex layout, per-instance layout, unit count, instance storage bytes, reserved units
		if (!m_Scene.Init(
			{ {0, 3, GL_FLOAT, sizeof(float) * 3} },
			{ {1, 3, GL_FLOAT, sizeof(float) * 3},      // pos
			  {2, 3, GL_FLOAT, sizeof(float) * 3},      // rot
			  {3, 4, GL_FLOAT, sizeof(float) * 4} },    // color
			2, 16 * 1024, 0))
			throw std::runtime_error("TestGame: Scene::Init failed");

		// units in draw order, each with its own capacity (entities it can hold)
		if (!m_Scene.AddUnit<Triangle>(true, 8) || !m_Scene.AddUnit<Bullet>(true, 256))
			throw std::runtime_error("TestGame: Scene::AddUnit failed");
		m_Scene.SetShaderInstanceStorageBufferBindingPoint(0);

		// entity data: one array per member. GPU columns are uploaded, CPU columns are not.
		m_Store = std::make_unique<TestStore>(m_Scene);
		m_Pos   = m_Store->AddGpuColumn<glm::vec3>(offsetof(InstanceVertexData, pos),   true, UploadMode::OnChange);
		m_Rot   = m_Store->AddGpuColumn<glm::vec3>(offsetof(InstanceVertexData, rot),   true, UploadMode::OnChange);
		m_Color = m_Store->AddGpuColumn<glm::vec4>(offsetof(InstanceVertexData, color), true, UploadMode::OnChange);
		m_Speed = m_Store->AddCpuColumn<float>();
		m_BulletUnit = m_Store->UnitId<Bullet>();
#ifndef NDEBUG
		m_Store->SetVerifyUploads(true);             // debug builds: report a write to an OnChange column that was not declared
#endif

		m_Player = m_Store->Create<Triangle>();
		*m_Store->Get(m_Pos, m_Player)   = { 0.0f, -0.5f, 0.0f };
		*m_Store->Get(m_Color, m_Player) = { 0.63f, 0.96f, 0.33f, 1.0f };

		m_Drifter = m_Store->Create<Triangle>();
		*m_Store->Get(m_Pos, m_Drifter)   = { 0.0f, 0.5f, 0.0f };
		*m_Store->Get(m_Color, m_Drifter) = { 0.33f, 0.60f, 0.93f, 1.0f };

		// hand the frame ring to the application: it now calls UpdateStart/End and RenderStart/Fence/End for us
		m_Gate = static_cast<SceneGate<TestScene>*>(App().SetGate(std::make_unique<SceneGate<TestScene>>(m_Scene)));
	}

	// main thread, GL context still alive. m_Store, m_Scene and m_Shader die with the module, still before the
	// window, so there is nothing to release by hand. Put anything else GL-related here.
	void OnUnmount() override
	{
		m_Gate = nullptr;
	}

	// UPDATE thread, no GL calls. One call per free frame slot.
	void OnUpdate(const UpdateContext& ctx) override
	{
		TestStore& store = *m_Store;
		glm::vec3* pos = store.Data(m_Pos);
		glm::vec4* color = store.Data(m_Color);
		float* speed = store.Data(m_Speed);

		// the player (polled input). Get() looks the handle up: fine for single entities
		const Input& in = ctx.input;
		glm::vec3 dir(0.0f);
		if (in.Down(Key::W) || in.Down(Key::Up))    dir.y += 1.0f;
		if (in.Down(Key::S) || in.Down(Key::Down))  dir.y -= 1.0f;
		if (in.Down(Key::A) || in.Down(Key::Left))  dir.x -= 1.0f;
		if (in.Down(Key::D) || in.Down(Key::Right)) dir.x += 1.0f;
		glm::vec3& playerPos = *store.Get(m_Pos, m_Player);
		if (dir != glm::vec3(0.0f))
		{
			playerPos += dir * (0.8f * ctx.dt);
			store.Touch(m_Pos, m_Player);                           // written through Data()/Get(): declare it
		}

		// the drifter swings left and right
		m_Time += ctx.dt;
		store.Get(m_Pos, m_Drifter)->x = 0.6f * std::sin(m_Time);
		store.Touch(m_Pos, m_Drifter);

		// shots requested by the Space events: spawn a bullet at the player (Create appends, it is safe anywhere)
		for (int shots = m_Shots.exchange(0); shots > 0; --shots)
		{
			Handle b = store.Create<Bullet>();
			if (b.IsNull()) break;                                  // the unit is full
			*store.Get(m_Pos, b)   = playerPos;
			*store.Get(m_Color, b) = { 1.0f, 0.9f, 0.3f, 1.0f };
			*store.Get(m_Speed, b) = 1.5f;
		}

		// all bullets: a loop over the unit's range, no handles. Destroy() is queued, so the loop is not disturbed.
		const Range bullets = store.RangeOf<Bullet>();
		for (uint32_t i = bullets.begin; i < bullets.begin + bullets.count; ++i)
		{
			pos[i].y += speed[i] * ctx.dt;
			if (pos[i].y > 1.2f) store.Destroy(store.HandleAt(m_BulletUnit, i));
		}
		store.TouchRange(m_Pos, m_BulletUnit, bullets.begin, bullets.count);   // every bullet moved

		store.Flush();                                              // applies the queued destroys (swap-remove)
		m_BulletCount.store(store.RangeOf<Bullet>().count);         // for the window title on the main thread

		store.Upload(m_Gate->Update());                             // live ranges -> this frame's slot, plus draw commands
		m_UploadBytes.store((uint32_t)store.LastUploadBytes());     // what this tick had to copy (for the title)
	}

	// main thread. The slot was written by OnUpdate; the application swaps the buffers and fences it after we return.
	void OnRender(const RenderContext& ctx) override
	{
		glViewport(0, 0, (GLsizei)ctx.window.fbWidth, (GLsizei)ctx.window.fbHeight);
		glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);

		m_Scene.RenderFrame(m_Shader, m_Gate->Render());

		if (ctx.time - m_LastTitle >= 0.5)
		{
			m_LastTitle = ctx.time;
			char title[112];
			std::snprintf(title, sizeof title, "Lunar TestGame | %.0f fps | bullets %u | upload %u B/tick", ctx.fps, m_BulletCount.load(), m_UploadBytes.load());
			App().GetWindow().SetTitle(title);
		}
	}

private:
	Shader m_Shader;
	TestScene m_Scene;
	std::unique_ptr<TestStore> m_Store;          // update thread only, created after Scene::Init
	SceneGate<TestScene>* m_Gate = nullptr;

	Column<glm::vec3> m_Pos, m_Rot;
	Column<glm::vec4> m_Color;
	Column<float> m_Speed;                        // CPU-only column
	int m_BulletUnit = -1;
	Handle m_Player, m_Drifter;
	float m_Time = 0.0f;

	std::atomic<int> m_Shots{ 0 };                // main thread (event) -> update thread
	std::atomic<uint32_t> m_BulletCount{ 0 };     // update thread -> main thread (title)
	std::atomic<uint32_t> m_UploadBytes{ 0 };
	double m_LastTitle = 0.0;                     // render thread only
};

class TestApp final : public Application
{
public:
	TestApp() : Application({ .title = "Lunar TestGame", .width = 800, .height = 600 }) {}

	void OnStart() override { Mount<TestModule>(); }
};

LUNAR_MAIN(TestApp)
