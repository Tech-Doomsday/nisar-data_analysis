# Lenz → Lunar: event system, application, entry point

Merge `src/` into `Lunar/src/`. Everything is new files **except three core files that were changed on request**: `Core/Core.h`, `Core/Core.cpp`, `Core/Scene.h` (see "Core fixes" below; `core-fixes.patch` is the exact diff).

```
src/LunarApp.h                  umbrella header (Lunar.h stays untouched; include this one instead of / after it)
src/Lunar/App/                  Application, ApplicationSpec, Window, Module, ModuleStack, FrameGate, EntryPoint
src/Lunar/Event/                Events, EventBus, EventAdapter, EventQueue (SPSC)
src/Lunar/Input/                KeyCodes, Input (per-tick snapshot), InputRelay (main -> update thread)
src/Lunar/Impl/SceneGate.h      connects the Application loops to a lunar::Scene
src/Lunar/Utils/                Log (plog, LN_* macros), FrameClock / FpsCounter / Backoff
RocketShooter/src/Game/RiftModule.h   the Rift demo as a Module (replaces the hand-written App in main.cpp)
RocketShooter/src/main.cpp      entry point of the game (was main_app.cpp, no LUNAR_RIFT_APP switch any more)
src/Lunar/Core/{Core.h,Core.cpp,Scene.h}   the three core files changed on request (original line endings kept)
core-fixes.patch                the exact diff of those three files (patch -p1)
tests/                          headless tests (workspace root)
```

## What replaces what

| Lenz | Lunar |
|---|---|
| `Runtime` | `lunar::Application` (`OnStart()` / `OnStop()`; `Run()` owns the loops) |
| `LENZ_MAIN(App)` + `extern GetAppWindow()` | `LUNAR_MAIN(App)`; window settings come from `ApplicationSpec` |
| `Window` + callbacks in `RendererCommands` | `lunar::Window` over `Core` (callbacks find it through the GLFW user pointer, no globals) |
| `Module` / `ModuleStack` | `lunar::Module` (adds `OnRender`, `Listen<E>()`), `ModuleStack` |
| `EventBus::On/Off/Emit` (static) | `app.Events()` instance; `On<E>()` returns an RAII `Subscription` |
| `EventAdapter` | `lunar::EventAdapter` (same virtuals, unsubscribes in its destructor) |
| `LZ_KEY_*` / `LZ_MOUSE_*` macros | `enum class Key`, `MouseButton`, `Mod` (same values as GLFW) |
| `Timestep` (statics) | `FrameClock` (one per loop), `FpsCounter` |
| `LZ_*` log macros | `LN_*` (plog). The existing `LUNAR_LOG/WARN/ERROR` are unchanged |

## Usage

```cpp
#include "LunarApp.h"

class Rift : public lunar::Module
{
public:
    Rift() : Module("Rift", /*priority*/ 0) {}
    void OnMount() override                                   // main thread, GL context current
    {
        Listen<lunar::events::KeyPressed>([this](auto& e) {   // return true = consumed
            if (e.key == lunar::Key::Escape) { App().Quit(); return true; }
            return false; });
        // build the Scene, App().SetGate(std::make_unique<lunar::SceneGate<GameScene>>(scene));
    }
    void OnUpdate(const lunar::UpdateContext& ctx) override   // update thread, no GL
    {
        if (ctx.input.Pressed(lunar::Key::Space)) Fire();
        if (ctx.input.Down(lunar::Key::A))        MoveLeft(ctx.dt);
    }
    void OnRender(const lunar::RenderContext& ctx) override { /* main thread */ }
    void OnUnmount() override { /* GL still alive: release GPU objects */ }
};

class MyApp : public lunar::Application
{
public:
    MyApp() : Application({ .title = "My game", .width = 1600, .height = 900 }) {}
    void OnStart() override { Mount<Rift>(); }
};
LUNAR_MAIN(MyApp)
```

## Rules to know

**Threads.** `OnMount/OnUnmount/OnRender/OnStart/OnStop` and event handlers run on the main thread.
`OnUpdate` runs on the update thread (`ThreadingMode::Split`, the default) or on the main thread
(`ThreadingMode::Single`, handy for debugging). Update code must not call GL. `Quit()` and `Mount/Unmount`
are callable from any thread.

**Order.** One priority number decides everything. Events and updates: higher first. Rendering: lower first
(overlays draw last). Unmount: higher first. Equal priorities keep mount order.

**Mount/Unmount while running** are applied by the main thread at the start of the next frame. Called from
the update thread, the module can go live at any moment after `Mount()` returns, so configure it through its
constructor only (the test suite caught exactly that mistake).

**Frame ring.** `SceneGate<YourScene>` does `UpdateStart/End` and `RenderStart/Fence/End` for you, in the order
the old hand-written loops used: update happens only when a slot is free, render only when one is written, the
swap happens before the fence. When the ring is full the update thread parks in `Scene::WaitForUpdateSlot` (no polling). Without a gate the update loop runs at `ApplicationSpec::updateHz`.

**Events and input.** Handlers return `true` to consume. The input relay forwards presses, typed text and
scroll to the update thread only if nothing consumed them; releases, focus changes and mouse motion always
pass (nothing can get stuck). `Input::Pressed()` is true for the tick in which a key went down, even if it
was already released again, so short taps are not lost. A focus loss releases everything.
Mouse motion is coalesced per frame; if the queue ever overflowed, held keys are released instead of trusted.

**Shutdown order.** update thread joined, `OnStop()`, modules unmounted + destroyed, your `Application` subclass
members, then window / context. So anything you own (scene, shaders, buffers) dies while GL is alive.

**Windows macros.** `FrameClock.h` uses `(std::min)`, so a `min` macro from `<windows.h>` cannot break it.

## Build integration

The workspace is split into one static library and the apps that link it (see the root `README.md`):
`Lunar/` (static library `Lunar`), `TestGame/` (simplest app, for debugging), `RocketShooter/` (the game).
`Lunar`'s CMake links glfw, GLEW, glm, plog and OpenGL as PUBLIC dependencies, so an app only needs
`target_link_libraries(MyApp PRIVATE Lunar)`.

## Core fixes (requested, now done)

**1. `LUNAR_ASSERT` is a real assert.** `LUNAR_ASSERT(cond)` and `LUNAR_ASSERT_MSG(cond, stream << expr)`.
Debug builds (`NDEBUG` not defined): a failed condition prints the condition and `file:line`, then breaks into the
debugger (`__debugbreak`, or a trap where there is none). Release builds: compiled out, the condition is **not evaluated**.
Safe inside `if/else` without braces. Heads-up: the old macro took a message (`LUNAR_ASSERT("text")`). Nothing in the files
I was given used it, but if you have code elsewhere that does, it would now pass silently (a string literal is true):
write `LUNAR_ASSERT_MSG(false, "text")` there.

**2. `Core::Init`, `Core::CreateWindow`, `Core::MakeContextCurrent` return `bool`.** False means it failed and the reason
was logged (with `LUNAR_ERROR`, and the GLEW error string). True means done, or already done (a second `Init()` or
`MakeContextCurrent()` returns true). Existing callers that ignore the result (the old `main.cpp`) still compile and
behave as before. `lunar::Window::Create` now uses the results and `Application::Run()` returns 1 when the window cannot
be created.

**3. The update side parks instead of sleep-polling.** `Scene` gained
`bool WaitForUpdateSlot()` (update thread; blocks until `UpdateStart()` can succeed, returns true; returns false when interrupted),
`InterruptUpdateWait()` and `ClearUpdateInterrupt()`. `RenderStart()` wakes the update side whenever it frees a slot, using an
event count (`std::atomic<uint32_t>` wait / notify_one), so no wake-up can be lost between the check and the wait.
`UpdateStart()` itself is unchanged (still non-blocking), so old loops keep working. `SceneGate` uses the new calls
(`FrameGate::WaitUpdate()` / `Interrupt()`), and `Application` interrupts it before joining the update thread, so quitting
while it is parked cannot hang. Effect measured in the tests: with the ring full for ~200 ms the update side made 0 failed
`UpdateStart()` calls when parked, versus 636 when polling. The render side still polls on purpose: it has to keep pumping
window events and `std::atomic::wait` has no timeout. Needs C++20 (your project already is).

## Include paths (fixed in this layout)

`Utils/Storage.h`, `Core/Scene.h` and `Game/GameTypes.h` now include the engine headers by paths that resolve
(`../Core/Core.h`, `../Utils/Storage.h`, `Lunar/Core/...`), so the throw-away forwarding header the tests used to need is gone.

## What was verified, and what was not

Built with g++ 13 (`-std=c++20 -Wall -Wextra`). Plain, ThreadSanitizer and ASan+UBSan runs are clean, repeated runs are stable:
* `tests.cpp`, 231 checks: bus ordering / consumption / re-entrancy / exception safety / lifetime, the SPSC queue across two threads,
  input edges and overflow, module ordering, FrameClock, the Application end to end (split and single thread, gate, event routing,
  close veto, quit from the update thread, mount/unmount while running, exception propagation, shutdown order, minimise, DPI
  cursor mapping), the wait/interrupt logic on a fake ring, parking vs polling, quitting while parked, a gate without the wait API,
  the three `Core` failure paths (init / window / GLEW) through `Core` and through `Application::Run()`, `LUNAR_ASSERT` (aborts on
  failure, passes on success, if/else safe).
* `assert_release.cpp`: with `-DNDEBUG` the assert vanishes and does not evaluate its argument.
* `scene_real.cpp`, 27 checks: **the real `Core/Scene.h`** (and Buffer / Shader / Shape / Entity) compiled against a stubbed GL:
  30,000 frames through the real ring on two threads with a fence that says "not ready" a few times, parking and wake-up on a freed
  slot, `InterruptUpdateWait` / `ClearUpdateInterrupt`, `SceneGate<Scene>` inside the Application in both threading modes, and
  quitting while the update thread is parked in the real `WaitForUpdateSlot`.
* `riftsmoke.cpp`: the ported Rift (`main_app.cpp` + `RiftModule.h`) against mocks of the Game headers.

Not verified here: a real MSVC build, real GLFW / GL driver behaviour (the GL in the tests is a stub, so GPU fence timing and
the persistent-mapping behaviour of a real driver are not exercised), real plog (`Log.cpp` follows plog's documented API but was only
compiled against my stub), and the real Rift game headers. To rerun: `tests/README.txt`.

## Not in this port

Texture, Cubemap, Framebuffer, DeferredShading, Text, Uniform helpers, Model/glTF loading, SkeletonAnimator, Physics /
PhysicsSystem, TaskSystem, AssetPackReader. An action-binding layer on top of `Input` would be a natural next step.
