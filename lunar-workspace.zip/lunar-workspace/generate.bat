@echo off
rem Generates the build files into .\build  (paths come from config.local.txt)
call "%~dp0load_config.bat"
if errorlevel 1 exit /b 1
echo [lunar] cmake:     %CMAKE_EXE%
echo [lunar] toolchain: %VCPKG_TOOLCHAIN_FWD%
"%CMAKE_EXE%" -B "%~dp0build" -S "%~dp0." -DCMAKE_TOOLCHAIN_FILE="%VCPKG_TOOLCHAIN_FWD%" %CMAKE_EXTRA_ARGS%
