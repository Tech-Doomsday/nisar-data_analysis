@echo off
rem Reads config.local.txt (KEY=VALUE per line) next to this script into environment variables,
rem normalizes the paths and checks that they exist. Called by generate.bat / generate_here.bat.
rem Sets: CMAKE_EXE, VCPKG_TOOLCHAIN_FWD, CMAKE_EXTRA_ARGS

set "LUNAR_CONFIG=%~dp0config.local.txt"
if not exist "%LUNAR_CONFIG%" goto :noconfig

set "CMAKE_EXE="
set "VCPKG_ROOT="
set "CMAKE_EXTRA_ARGS="
rem findstr drops comment lines and KEY= lines with an empty value
for /f "eol=# tokens=1,* delims==" %%A in ('findstr /v /r /c:"^#" /c:"=$" "%LUNAR_CONFIG%"') do set "%%A=%%B"

if "%CMAKE_EXE%"=="" set "CMAKE_EXE=cmake"
set "CMAKE_EXE=%CMAKE_EXE:/=\%"
if /i "%CMAKE_EXE%"=="cmake" goto :cmakeok
if not exist "%CMAKE_EXE%" if exist "%CMAKE_EXE%.exe" set "CMAKE_EXE=%CMAKE_EXE%.exe"
if not exist "%CMAKE_EXE%" goto :nocmake
:cmakeok

if "%VCPKG_ROOT%"=="" goto :novcpkg
set "VCPKG_ROOT=%VCPKG_ROOT:/=\%"
set "VCPKG_TOOLCHAIN=%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake"
if not exist "%VCPKG_TOOLCHAIN%" goto :novcpkgfile
set "VCPKG_TOOLCHAIN_FWD=%VCPKG_TOOLCHAIN:\=/%"
exit /b 0

:noconfig
echo [lunar] config.local.txt not found: %LUNAR_CONFIG%
echo [lunar] Copy config.example.txt to config.local.txt and fill in your paths.
exit /b 1
:nocmake
echo [lunar] CMAKE_EXE in config.local.txt does not exist: %CMAKE_EXE%
exit /b 1
:novcpkg
echo [lunar] VCPKG_ROOT is not set in config.local.txt
exit /b 1
:novcpkgfile
echo [lunar] vcpkg toolchain file not found: %VCPKG_TOOLCHAIN%
echo [lunar] VCPKG_ROOT in config.local.txt must be the folder that contains scripts\buildsystems\vcpkg.cmake
exit /b 1
