Headless tests for the application layer and for the core fixes. They use stubs of GLFW / GLEW / glm / plog / the GL
buffer+sync calls (tests/stubs), so no GPU or window is needed. This folder sits at the workspace root, next to Lunar/, TestGame/ and RocketShooter/ (no target compiles it).

Layout the commands expect:  ROOT/Lunar/src = the engine (static library sources),  ROOT/RocketShooter/src = the game,  ROOT/tests = this folder.

  ROOT=/path/to/project
  SRC=$ROOT/Lunar/src
  FL="-std=c++20 -O1 -g -pthread -I$ROOT/tests/stubs -I$ROOT/tests/mock -I$SRC -I$SRC/Lunar"
  APP="$SRC/Lunar/App/Application.cpp $SRC/Lunar/App/Window.cpp $SRC/Lunar/Utils/Log.cpp $SRC/Lunar/Core/Core.cpp $ROOT/tests/stubs/stubs.cpp"
  CORE="$SRC/Lunar/Core/Buffer.cpp $SRC/Lunar/Core/Shader.cpp $SRC/Lunar/Core/Shape.cpp $SRC/Lunar/Core/Scene.cpp $SRC/Lunar/Core/Entity.cpp $SRC/Lunar/Utils/Storage.cpp"

  # application layer + Core return values + LUNAR_ASSERT + Scene-wait semantics (fake ring)
  g++ $FL -I$ROOT/tests $ROOT/tests/tests.cpp $APP -o app_tests && ./app_tests

  # the REAL core (Buffer/Shader/Shape/Scene/Entity) against a stubbed GL: real frame ring, WaitForUpdateSlot,
  # InterruptUpdateWait, SceneGate<Scene> inside the Application
  g++ $FL -I$ROOT/tests $ROOT/tests/scene_real.cpp $CORE $APP -o scene_real && ./scene_real

  # SceneStorage + per-unit segments against the real Scene (handles, swap-remove, unit isolation, deferred destroy, upload, fuzz)
  g++ $FL -I$ROOT/tests $ROOT/tests/storage_tests.cpp $CORE $APP -o storage_tests && ./storage_tests
  (it prints three "Scene::... / SceneStorage::..." error lines on purpose: they come from the tests that overfill a unit / add a column too late)

  # The real game World, headless, deterministic: hashes every unit's instance data / ISB / draw commands / UBO packet / particle events
  # of every frame. Build it against two versions of the game and diff the output: identical == identical behaviour.
  # (needs the REAL glm, so use a copy of the stubs without the fake one)
  cp -r $ROOT/tests/stubs /tmp/stubs_noglm && rm -rf /tmp/stubs_noglm/glm
  FLG="-std=c++20 -O2 -pthread -I/tmp/stubs_noglm -I$SRC -I$SRC/Lunar"
  g++ $FLG -I$ROOT/RocketShooter/src $ROOT/tests/world_diff.cpp $CORE $APP_noglm -o world_diff && ./world_diff 20000 1     # args: frames seed
  (APP_noglm = $APP with /tmp/stubs_noglm/stubs.cpp instead of $ROOT/tests/stubs/stubs.cpp)

  # LUNAR_ASSERT in a release build (-DNDEBUG): compiled out, argument not evaluated
  g++ -std=c++20 -DNDEBUG -I$ROOT/tests/stubs -I$SRC -I$SRC/Lunar $ROOT/tests/assert_release.cpp $SRC/Lunar/Core/Core.cpp $ROOT/tests/stubs/stubs.cpp -o assert_release && ./assert_release

  # the Rocket Shooter entry point (RocketShooter/src/main.cpp + RiftModule.h) against mocks of the Game headers
  g++ $FL $ROOT/tests/riftsmoke.cpp $APP -o rift_smoke && ./rift_smoke

  add -fsanitize=thread  or  -fsanitize=address,undefined  for the sanitizer runs

tests.cpp includes LunarApp_noscene.h (LunarApp.h minus Lunar.h). riftsmoke.cpp includes ../RocketShooter/src/main.cpp. mock/Lunar.h and mock/Game/* are test-only stand-ins.
