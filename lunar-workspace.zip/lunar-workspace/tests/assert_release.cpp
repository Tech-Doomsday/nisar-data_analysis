// compiled with -DNDEBUG: LUNAR_ASSERT must vanish and must not evaluate its argument
#include <GLFW/glfw3.h>
#include "Lunar/Core/Core.h"
int main()
{
#ifndef NDEBUG
	return 2;
#endif
	int side = 0;
	LUNAR_ASSERT(++side);
	LUNAR_ASSERT_MSG(++side, "x" << ++side);
	LUNAR_ASSERT(false);                  // release: nothing happens
	LUNAR_ASSERT_MSG(false, "nothing");
	return side == 0 ? 0 : 1;
}
