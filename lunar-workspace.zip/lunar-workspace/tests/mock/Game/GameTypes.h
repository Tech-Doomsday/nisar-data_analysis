#pragma once
// MOCK of the real Game/GameTypes.h: same names/signatures the module touches, no GL.
#include <atomic>
#include <array>
#include <cstdint>
#include <initializer_list>
#include "Lunar/Core/Core.h"
namespace game {
	constexpr float WORLD_W = 1600.0f, WORLD_H = 900.0f;
	enum Unit { U_COUNT = 9 };
	constexpr size_t INSTANCE_STORAGE_BYTES = 1024, RESERVED_UNITS = 1; constexpr int ENTITY_PER_UNIT = 4;
	struct KPickup {}; struct KAsteroid {}; struct KDrone {}; struct KGunner {}; struct KEnemyBullet {};
	struct KPlayerBullet {}; struct KPlayer {}; struct KRing {}; struct KHud {};
	enum KeyBit : uint32_t { K_UP = 1, K_DOWN = 2, K_LEFT = 4, K_RIGHT = 8, K_FIRE = 16, K_NOVA = 32 };
	enum PressBit : uint32_t { P_PAUSE = 1, P_START = 2, P_NOVA = 4 };
	struct Input { std::atomic<uint32_t> keys{ 0 }, pressed{ 0 }; std::atomic<float> mouseX{ 0 }, mouseY{ 0 }; };
	struct EmitBlock { uint32_t header[8]; };
	struct FramePacket { uint32_t emitCount = 0, flags = 0; };
	struct El { int a, b, c; size_t d; };
	struct GameScene {
		struct UpdateChache { int frameNo; };
		struct RenderChache { int frameNo; operator bool() { return frameNo != -1; } };
		enum class S { Free, Written };
		std::atomic<S> state[3]{ S::Free, S::Free, S::Free }; UpdateChache slots[3]{ {0},{1},{2} }; int ui = 0, ri = 0; int units = 0;
		bool Init(std::initializer_list<El>, std::initializer_list<El>, int, size_t, size_t) { return true; }
		size_t GetEntityPerUnit() { return ENTITY_PER_UNIT; } size_t GetUnits() { return units; } size_t GetTotalEntityCap() { return 36; }
		size_t GetIVBsize() { return 1; } size_t GetISBsize() { return 1; } size_t GetIDBsize() { return 1; }
		template<class T> bool AddUnit() { ++units; return true; }
		void SetShaderInstanceStorageBufferBindingPoint(int) {}
		UpdateChache* UpdateStart() { return state[ui].load(std::memory_order_acquire) == S::Free ? &slots[ui] : nullptr; }
		void UpdateEnd(UpdateChache*) { state[ui].store(S::Written, std::memory_order_release); ui = (ui + 1) % 3; }
		RenderChache RenderStart() { return { state[ri].load(std::memory_order_acquire) == S::Written ? ri : -1 }; }
		void RenderFence(RenderChache&) {}
		void RenderEnd() { state[ri].store(S::Free, std::memory_order_release); ri = (ri + 1) % 3; }
	};
}
