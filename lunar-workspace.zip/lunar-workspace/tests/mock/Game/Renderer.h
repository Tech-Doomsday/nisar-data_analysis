#pragma once
#include "Game/GameTypes.h"
namespace game {
	inline std::atomic<int> g_draws{ 0 }; inline std::atomic<int> g_destroyed{ 0 };
	struct Viewport { int x, y, w, h; };
	inline Viewport Letterbox(int fbW, int fbH) {
		const float target = WORLD_W / WORLD_H; int w = fbW, h = (int)(fbW / target);
		if (h > fbH) { h = fbH; w = (int)(fbH * target); }
		return { (fbW - w) / 2, (fbH - h) / 2, w, h };
	}
	class Renderer {
	public:
		~Renderer() { stub::Log("~Renderer"); }
		void Init(GameScene&) {}
		EmitBlock* EventSlice(int) { return &blk; }
		void Draw(const FramePacket&, GameScene::RenderChache& rc, int fw, int fh) { ++g_draws; (void)rc; (void)fw; (void)fh; }
		EmitBlock blk{};
	};
}
