#pragma once
#include "Game/GameTypes.h"
namespace game {
	inline std::atomic<uint32_t> g_lastKeys{ 0 }, g_pressedSeen{ 0 }; inline std::atomic<float> g_mouseX{ -1e9f }; inline std::atomic<int> g_ticks{ 0 };
	class World {
	public:
		void Init(GameScene&) {}
		void Tick(float, Input& in) { g_lastKeys = in.keys.load(); g_pressedSeen |= in.pressed.exchange(0); g_mouseX = in.mouseX.load(); ++g_ticks; }
		void WriteFrame(GameScene::UpdateChache*, FramePacket&, EmitBlock*) {}
		size_t TotalEntities() const { return 7; } int Score() const { return 42; } int Wave() const { return 3; }
		FramePacket packets[3];
	};
}
