#include <GLFW/glfw3.h>
#include <cstdio>
#define LUNAR_DISABLE_ENTRYPOINT
#include "../RocketShooter/src/main.cpp"      // the real file, compiled against the mocks

int main()
{
	lunar::Log::Init(lunar::LogConfig{ lunar::LogLevel::Warn, false, false });
	int fails = 0; auto check = [&](bool ok, const char* what) { if (!ok) { ++fails; std::printf("FAIL %s\n", what); } };

	int frame = 0;
	stub::initCx = 0; stub::initCy = 0;
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
		if (frame == 5)  { w->fw = 3200; w->fh = 1800; w->fb(w, 3200, 1800); }             // HiDPI-ish framebuffer: 2x window
		if (frame == 10) { w->cursor(w, 400, 225); }                                      // centre of the 800x450 ... see below
		if (frame == 12) { w->key(w, int(lunar::Key::D), 0, GLFW_PRESS, 0); w->mbtn(w, 0, GLFW_PRESS, 0); w->mbtn(w, 0, GLFW_RELEASE, 0); }  // hold D, tap fire
		if (frame == 60) { w->key(w, int(lunar::Key::Escape), 0, GLFW_PRESS, 0); }        // Esc quits, consumed
	};
	int rc = lunar::Launch<RiftApp>(0, nullptr);
	check(rc == 0, "exit code 0");
	check(frame >= 60 && frame < 400, "quit via Esc");
	check(game::g_ticks > 10 && game::g_draws > 10, "world ticked and renderer drew");
	check((game::g_lastKeys.load() & game::K_RIGHT) != 0, "D held -> K_RIGHT reaches World::Tick");
	check((game::g_pressedSeen.load() & game::P_START) != 0, "left-click tap -> P_START (a tap shorter than a tick is not lost)");
	// window 1600x900 (created from the spec), fb 3200x1800: cursor (400,225) -> centre-left quarter of the playfield
	std::printf("mouseX seen by World: %.1f (expect -400)\n", (double)game::g_mouseX.load());
	check(std::abs(game::g_mouseX.load() - (-400.0f)) < 1.0f, "cursor mapped through DPI + letterbox to playfield coordinates");
	auto log = stub::TakeLog(); int r = -1, d = -1, t = -1;
	for (size_t i = 0; i < log.size(); ++i) { if (log[i] == "~Renderer") r = int(i); if (log[i] == "glfwDestroyWindow") d = int(i); if (log[i] == "glfwTerminate") t = int(i); }
	check(r != -1 && d != -1 && r < d && d < t, "renderer destroyed before the window / context");
	check(stub::swapsAfterDestroy == 0, "no swap after window destruction");
	std::printf("%s (%d failed)\n", fails ? "RIFT SMOKE FAILED" : "RIFT SMOKE OK", fails);
	return fails;
}
