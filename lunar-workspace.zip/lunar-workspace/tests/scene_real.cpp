// The REAL lunar::Scene (Core/Scene.h) against a stubbed GL: frame ring across two threads,
// including the new WaitForUpdateSlot / InterruptUpdateWait, and SceneGate<Scene> inside the Application.
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <thread>
#include <unistd.h>

#include "LunarApp_noscene.h"
#include "Lunar/Core/Scene.h"
#include "Lunar/Impl/CommonShapes.h"
#include <GLFW/glfw3.h>

using namespace lunar;
using namespace std::chrono_literals;

static int g_fail = 0, g_checks = 0;
#define CHECK(c) do { ++g_checks; if (!(c)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)

struct D { float v[4]; };
using RealScene = Scene<D, D>;

struct Watchdog {
	std::mutex m; std::condition_variable cv; bool done = false; std::thread t;
	Watchdog(int ms, const char* what) : t([this, ms, what] {
		std::unique_lock<std::mutex> l(m);
		if (!cv.wait_for(l, std::chrono::milliseconds(ms), [&] { return done; })) { std::printf("  WATCHDOG: %s hung\n", what); std::fflush(stdout); _exit(3); }
	}) {}
	~Watchdog() { { std::lock_guard<std::mutex> l(m); done = true; } cv.notify_all(); t.join(); }
};

static bool MakeScene(RealScene& s)
{
	return s.Init({ {0, 3, GL_FLOAT, sizeof(float) * 3} }, { {1, 4, GL_FLOAT, sizeof(float) * 4} }, 1, 64 * 1024, 1) && s.AddUnit<Cube>();
}

static void test_real_ring_two_threads()
{
	Watchdog dog(60000, "real ring");
	glstub::fenceBusyCalls = 3;                              // the GPU "needs a few polls" before a fence signals
	RealScene scene;
	CHECK(MakeScene(scene));

	constexpr int N = 30000;
	std::atomic<int> produced{ 0 }; std::atomic<uint64_t> nullStarts{ 0 }, waits{ 0 };
	std::thread updater([&] {
		while (produced < N) {
			if (auto* u = scene.UpdateStart()) { scene.UpdateEnd(u); ++produced; }
			else { ++nullStarts; ++waits; scene.WaitForUpdateSlot(); }
		}
	});
	int consumed = 0; bool slotOrder = true; int expectSlot = 0;
	while (consumed < N) {
		auto rc = scene.RenderStart();
		if (rc) {
			if (rc.frameNo != expectSlot) slotOrder = false;
			expectSlot = (expectSlot + 1) % 3;
			scene.RenderFence(rc); scene.RenderEnd(); ++consumed;
		} else std::this_thread::yield();
	}
	updater.join();
	CHECK(produced == N && consumed == N && slotOrder);
	CHECK(glstub::fences >= N && glstub::deletedFences >= N - 3);        // fences were created and recycled
	std::printf("        real ring: %d frames, update side parked %llu times\n", N, (unsigned long long)waits.load());
}

static void test_real_wait_and_interrupt()
{
	Watchdog dog(30000, "real wait/interrupt");
	glstub::fenceBusyCalls = 0;
	RealScene scene; CHECK(MakeScene(scene));
	CHECK(scene.WaitForUpdateSlot());                          // free slot: returns at once

	for (int i = 0; i < 3; ++i) { auto* u = scene.UpdateStart(); CHECK(u != nullptr); scene.UpdateEnd(u); }   // fill the ring
	CHECK(scene.UpdateStart() == nullptr);

	std::atomic<int> state{ -1 }; std::atomic<uint64_t> nullCalls{ 0 };
	std::thread updater([&] { state = scene.WaitForUpdateSlot() ? 1 : 0; });
	std::this_thread::sleep_for(100ms);
	CHECK(state == -1);                                        // parked, not spinning, not returned

	auto rc = scene.RenderStart(); CHECK(bool(rc)); scene.RenderFence(rc); scene.RenderEnd();   // slot 0 -> InFlight, cursor -> 1
	std::this_thread::sleep_for(30ms);
	CHECK(state == -1);                                        // InFlight is not Free yet: still parked
	auto r1 = scene.RenderStart(); scene.RenderFence(r1); scene.RenderEnd();                    // slot 1
	auto r2 = scene.RenderStart(); scene.RenderFence(r2); scene.RenderEnd();                    // slot 2
	std::this_thread::sleep_for(30ms);
	CHECK(state == -1);
	auto r0 = scene.RenderStart();                             // back on slot 0: fence signalled -> Free -> wakes the update side
	CHECK(!bool(r0));                                          // freed, but nothing written there yet
	updater.join();
	CHECK(state == 1);
	CHECK(scene.UpdateStart() != nullptr);

	// interrupt
	auto* u = scene.UpdateStart(); scene.UpdateEnd(u);        // slot 0 written again; update cursor now on slot 1 (InFlight)
	CHECK(scene.UpdateStart() == nullptr);
	state = -1;
	std::thread updater2([&] { state = scene.WaitForUpdateSlot() ? 1 : 0; });
	std::this_thread::sleep_for(50ms);
	CHECK(state == -1);
	scene.InterruptUpdateWait();
	updater2.join();
	CHECK(state == 0);
	CHECK(!scene.WaitForUpdateSlot());                         // stays interrupted
	scene.ClearUpdateInterrupt();
	std::atomic<int> st3{ -1 };
	std::thread updater3([&] { st3 = scene.WaitForUpdateSlot() ? 1 : 0; });
	std::this_thread::sleep_for(50ms);
	CHECK(st3 == -1);                                          // re-armed: parks again
	scene.InterruptUpdateWait(); updater3.join(); CHECK(st3 == 0);
}

struct IdleModule : Module
{
	std::atomic<int> updates{ 0 }, renders{ 0 };
	IdleModule() : Module("idle", 0) {}
	void OnUpdate(const UpdateContext&) override { ++updates; }
	void OnRender(const RenderContext&) override { if (++renders >= 80) App().Quit(); }
};

struct RealApp : Application
{
	RealScene scene; IdleModule* mod = nullptr;
	explicit RealApp(ThreadingMode m) : Application([&] { ApplicationSpec s; s.threading = m; return s; }()) {}
	void OnStart() override
	{
		if (!MakeScene(scene)) throw std::runtime_error("scene init");
		SetGate(std::make_unique<SceneGate<RealScene>>(scene));
		mod = &Mount<IdleModule>();
	}
};

static void test_real_scene_in_application()
{
	for (ThreadingMode mode : { ThreadingMode::Split, ThreadingMode::Single })
	{
		Watchdog dog(30000, "real scene in application");
		stub::Reset(); glstub::fenceBusyCalls = 1;
		int frame = 0;
		stub::pollHook = [&] {
			GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
			if (frame == 30) { w->iconified = 1; w->iconify(w, 1); }       // ring fills, update thread parks on the REAL scene
			if (frame == 50) { w->iconified = 0; w->iconify(w, 0); }
		};
		int updates = 0, renders = 0;
		{
			RealApp app(mode);
			CHECK(app.Run() == 0);
			updates = app.mod ? 0 : 0; (void)updates;
		}
		CHECK(!Application::Exists());
		(void)renders;
	}
	// quit while the update thread is parked inside the real Scene::WaitForUpdateSlot (must not hang)
	{
		Watchdog dog(30000, "quit while parked on real scene");
		stub::Reset(); glstub::fenceBusyCalls = 0; int frame = 0;
		stub::pollHook = [&] {
			GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
			if (frame == 10) { w->iconified = 1; w->iconify(w, 1); }
			if (frame == 40) { w->shouldClose = true; w->close(w); }
		};
		RealApp app(ThreadingMode::Split);
		CHECK(app.Run() == 0);
	}
}

int main()
{
	Log::Init(LogConfig{ LogLevel::Warn, false, false });
	test_real_ring_two_threads();
	test_real_wait_and_interrupt();
	test_real_scene_in_application();
	std::printf("real scene: %d checks, %d failed\n", g_checks, g_fail);
	return g_fail ? 1 : 0;
}
