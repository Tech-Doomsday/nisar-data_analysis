// SceneStorage (Impl/SceneStorage.h) + per-unit segments of the REAL lunar::Scene, against a stubbed GL.
#include <cstdio>
#include <cstring>
#include <map>
#include <random>
#include <vector>

#include "LunarApp_noscene.h"
#include "Lunar/Core/Scene.h"
#include "Lunar/Impl/SceneStorage.h"
#include <GLFW/glfw3.h>

using namespace lunar;

static int g_fail = 0, g_checks = 0;
#define CHECK(c) do { ++g_checks; if (!(c)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)

struct V3 { float x, y, z; };
struct IVB { V3 pos; V3 rot; float color[4]; };       // 40 bytes, SoA on the GPU
struct ISB { float a[4]; };

struct A {}; struct B {}; struct C {};
template<class T> static void InitTri()
{
	float v[] = { -0.5f, -0.5f, 0.f,  0.5f, -0.5f, 0.f,  0.f, 0.5f, 0.f };
	unsigned idx[] = { 0, 1, 2 };
	Object<T>::ShapeData.Init(v, sizeof(v), idx, sizeof(idx));
	Object<T>::ShapeData.SetVertexLayout({ {0, 3, GL_FLOAT, sizeof(float) * 3} });
}
template<> void Object<A>::Init() { InitTri<A>(); }
template<> void Object<B>::Init() { InitTri<B>(); }
template<> void Object<C>::Init() { InitTri<C>(); }

using TScene = Scene<IVB, ISB>;
using Store = SceneStorage<TScene>;
constexpr size_t kCap = 400;                           // entities in the scene

static bool InitScene(TScene& s)
{
	return s.Init({ {0, 3, GL_FLOAT, sizeof(float) * 3} },
		{ {1, 3, GL_FLOAT, sizeof(float) * 3}, {2, 3, GL_FLOAT, sizeof(float) * 3}, {3, 4, GL_FLOAT, sizeof(float) * 4} },
		3, kCap * sizeof(IVB), 1);                         // 3 units + 1 reserved -> default 100 entities per unit
}

struct Cols
{
	Column<V3> pos; Column<float> hp; Column<ISB> isb;
	Cols(Store& st) :
		pos(st.AddGpuColumn<V3>(offsetof(IVB, pos))), hp(st.AddCpuColumn<float>()), isb(st.AddIsbColumn<ISB>()) {}
};

// ---------------------------------------------------------------------------------------------------------------
static void test_segments()
{
	{   // default: unit u starts at u * entityPerUnit, exactly like before
		TScene s; CHECK(InitScene(s));
		CHECK(s.AddUnit<A>() && s.AddUnit<B>() && s.AddUnit<C>());
		CHECK(s.GetEntityPerUnit() == 100);
		CHECK(s.GetSegment(0).start == 0 && s.GetSegment(1).start == 100 && s.GetSegment(2).start == 200);
		CHECK(s.GetSegment(0).capacity == 100 && s.GetSegment(2).capacity == 100);
		Entity e0 = s.AddEntity<B>(); Entity e1 = s.AddEntity<B>();
		CHECK(e0.id == 100 && e1.id == 101 && s.GetEntityCount<B>() == 2);
		s.RemoveEntity<B>(0, nullptr);
		CHECK(s.GetEntityCount<B>() == 1);
	}
	{   // different capacities, handed out one after the other
		TScene s; CHECK(InitScene(s));
		CHECK(s.AddUnit<A>(true, 50));
		CHECK(s.AddUnit<B>(true, 300));
		CHECK(!s.AddUnit<C>(true, 100));                    // 50 + 300 + 100 > 400: refused, nothing modified
		CHECK(s.GetUnits() == 2);
		CHECK(s.AddUnit<C>(true, 50));
		CHECK(s.GetSegment(0).start == 0 && s.GetSegment(0).capacity == 50);
		CHECK(s.GetSegment(1).start == 50 && s.GetSegment(1).capacity == 300);
		CHECK(s.GetSegment(2).start == 350 && s.GetSegment(2).capacity == 50);
		size_t n = 0; while (s.AddEntity<A>().IsValid()) n++;
		CHECK(n == 50 && s.GetEntityCount<A>() == 50 && s.GetEntityCount<B>() == 0);   // A filled up, B untouched
	}
}

static void test_create_destroy_handles()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>());
	Store st(s); Cols c(st);

	Handle h[5];
	for (int i = 0; i < 5; i++) { h[i] = st.Create<A>(); CHECK(!h[i].IsNull()); st.Get(c.pos, h[i])->x = 10.f + i; *st.Get(c.hp, h[i]) = 100.f + i; }
	Range r = st.RangeOf<A>();
	CHECK(r.begin == 0 && r.count == 5);
	CHECK(*st.Get(c.hp, h[2]) == 102.f);

	st.Destroy(h[2]);                                      // queued only
	CHECK(st.IsAlive(h[2]) && st.RangeOf<A>().count == 5);
	st.Flush();
	CHECK(!st.IsAlive(h[2]) && st.RangeOf<A>().count == 4);
	CHECK(st.Get(c.pos, h[2]) == nullptr);                  // stale handle -> nullptr
	for (int i : { 0, 1, 3, 4 }) CHECK(st.Get(c.pos, h[i]) && st.Get(c.pos, h[i])->x == 10.f + i && *st.Get(c.hp, h[i]) == 100.f + i);
	CHECK(st.SlotOf(h[4]) == 2);                            // the LAST entity moved into the hole
	CHECK(st.HandleAt(0, 2) == h[4]);

	st.Destroy(h[0]); st.Destroy(h[0]); st.Flush();         // destroyed twice -> removed once
	CHECK(st.RangeOf<A>().count == 3 && !st.IsAlive(h[0]));

	st.Destroy(h[1]); st.Destroy(h[3]); st.Destroy(h[4]); st.Flush();
	CHECK(st.RangeOf<A>().count == 0 && s.GetEntityCount<A>() == 0);   // down to nothing: first / last / only

	Handle again = st.Create<A>();                          // the id is reused, the generation is not
	CHECK(!again.IsNull() && again.id == h[4].id && again.gen != h[4].gen);
	CHECK(!st.IsAlive(h[4]) && st.IsAlive(again));
	CHECK(st.Get(c.pos, again)->x == 0.f);                  // a recycled slot starts zeroed
	CHECK(!st.DestroyNow(h[4]) && st.IsAlive(again));       // the stale handle can not kill the new one
	CHECK(!st.DestroyNow(Handle{}));                        // null handle
}

static void test_unit_isolation()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>() && s.AddUnit<C>());
	Store st(s); Cols c(st);
	std::vector<Handle> a, b, cc;
	for (int i = 0; i < 40; i++) { Handle h = st.Create<A>(); a.push_back(h); st.Get(c.pos, h)->x = float(i); }
	for (int i = 0; i < 60; i++) { Handle h = st.Create<B>(); b.push_back(h); st.Get(c.pos, h)->x = 1000.f + i; *st.Get(c.hp, h) = float(i); }
	for (int i = 0; i < 10; i++) { Handle h = st.Create<C>(); cc.push_back(h); st.Get(c.pos, h)->x = 5000.f + i; }

	const size_t B0 = s.GetSegment(1).start, C0 = s.GetSegment(2).start;
	std::vector<V3> posBefore(st.Data(c.pos), st.Data(c.pos) + kCap);
	std::vector<float> hpBefore(st.Data(c.hp), st.Data(c.hp) + kCap);

	for (size_t i = 0; i < a.size(); i += 2) st.Destroy(a[i]);     // remove half of A, including slot 0
	st.Flush();
	CHECK(st.RangeOf<A>().count == 20 && st.RangeOf<B>().count == 60 && st.RangeOf<C>().count == 10);

	// everything outside A's segment is byte-for-byte unchanged
	CHECK(std::memcmp(posBefore.data() + B0, st.Data(c.pos) + B0, (kCap - B0) * sizeof(V3)) == 0);
	CHECK(std::memcmp(hpBefore.data() + B0, st.Data(c.hp) + B0, (kCap - B0) * sizeof(float)) == 0);
	for (size_t i = 0; i < b.size(); i++) CHECK(st.SlotOf(b[i]) == B0 + i);   // B's handles did not move at all
	for (size_t i = 0; i < cc.size(); i++) CHECK(st.SlotOf(cc[i]) == C0 + i);
	for (size_t i = 1; i < a.size(); i += 2) CHECK(st.IsAlive(a[i]) && st.Get(c.pos, a[i])->x == float(i));

	// and the other way round: B's removals leave A and C alone
	std::vector<V3> posA(st.Data(c.pos), st.Data(c.pos) + B0);
	for (size_t i = 0; i < b.size(); i += 3) st.Destroy(b[i]);
	st.Flush();
	CHECK(std::memcmp(posA.data(), st.Data(c.pos), B0 * sizeof(V3)) == 0);
	CHECK(std::memcmp(posBefore.data() + C0, st.Data(c.pos) + C0, 10 * sizeof(V3)) == 0);
}

static void test_deferred_destroy_in_loop()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>());
	Store st(s); Cols c(st);
	for (int i = 0; i < 50; i++) *st.Get(c.hp, st.Create<A>()) = float(i);

	Range r = st.RangeOf<A>(); float* hp = st.Data(c.hp);
	int visited = 0; double sum = 0;
	for (uint32_t i = r.begin; i < r.begin + r.count; i++)
	{
		visited++; sum += hp[i];
		if (int(hp[i]) % 2 == 0) st.Destroy(st.HandleAt(0, i));       // destroying inside the loop
	}
	CHECK(visited == 50 && sum == 1225.0);                  // every entity seen exactly once, none skipped or repeated
	CHECK(st.RangeOf<A>().count == 50);                     // nothing moved yet
	st.Flush();
	r = st.RangeOf<A>();
	CHECK(r.count == 25);
	double left = 0; bool allOdd = true;
	for (uint32_t i = r.begin; i < r.begin + r.count; i++) { left += hp[i]; if (int(hp[i]) % 2 == 0) allOdd = false; }
	CHECK(allOdd && left == 625.0);                          // the odd numbers 1..49
}

static void test_full_unit_and_column_rules()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>(true, 30) && s.AddUnit<B>());
	Store st(s); Cols c(st);
	Handle last; int n = 0;
	for (;;) { Handle h = st.Create<A>(); if (h.IsNull()) break; last = h; n++; }
	CHECK(n == 30 && st.RangeOf<A>().count == 30);
	st.DestroyNow(last);
	CHECK(!st.Create<A>().IsNull());                          // one slot free again
	Column<float> late = st.AddCpuColumn<float>();            // after the first Create: refused
	CHECK(!late.IsValid());
}

static void test_upload()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>());
	Store st(s); Cols c(st);
	std::vector<Handle> a, b;
	for (int i = 0; i < 6; i++) { Handle h = st.Create<A>(); a.push_back(h); st.Get(c.pos, h)->x = float(i); st.Get(c.isb, h)->a[0] = 10.f + i; }
	for (int i = 0; i < 4; i++) { Handle h = st.Create<B>(); b.push_back(h); st.Get(c.pos, h)->x = 100.f + i; st.Get(c.isb, h)->a[0] = 200.f + i; }
	st.Destroy(a[1]); st.Destroy(a[4]); st.Flush();           // A: 6 -> 4, order is now 0,5,2,3

	auto* slot = s.UpdateStart(); CHECK(slot != nullptr);
	st.Upload(slot);
	const char* base = (const char*)slot->instanceVertexBufferDataPtr;
	const V3* gpuPos = (const V3*)(base + kCap * offsetof(IVB, pos));        // the SoA block of `pos` in this frame's slice
	const float expectA[4] = { 0, 5, 2, 3 };
	for (int i = 0; i < 4; i++) CHECK(gpuPos[0 + i].x == expectA[i]);
	const size_t B0 = s.GetSegment(1).start;
	for (int i = 0; i < 4; i++) CHECK(gpuPos[B0 + i].x == 100.f + i);
	const ISB* gpuIsb = (const ISB*)slot->instanceStorageBufferDataPtr;
	const float expectIsb[4] = { 10, 15, 12, 13 };
	for (int i = 0; i < 4; i++) CHECK(gpuIsb[i].a[0] == expectIsb[i]);
	for (int i = 0; i < 4; i++) CHECK(gpuIsb[B0 + i].a[0] == 200.f + i);
	CHECK(slot->indirectDrawBufferPtr[0].instanceCount == 4 && slot->indirectDrawBufferPtr[1].instanceCount == 4);
	CHECK(slot->indirectDrawBufferPtr[1].baseInstance == B0);
	s.UpdateEnd(slot);
}

// random create / destroy / flush against a simple model; checks all invariants as it goes
static void test_fuzz()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>(true, 120) && s.AddUnit<B>(true, 80) && s.AddUnit<C>(true, 200));
	Store st(s); Cols c(st);
	struct Rec { Handle h; int unit; uint32_t token; bool queued; };
	std::vector<Rec> live; std::vector<Handle> dead;
	std::mt19937 rng(12345); uint32_t nextToken = 1;
	int caps[3] = { 120, 80, 200 };
	size_t bad = 0;

	auto verify = [&]()
	{
		int per[3] = { 0, 0, 0 };
		for (const Rec& r : live) per[r.unit]++;
		for (int u = 0; u < 3; u++)
		{
			Range rg = st.RangeOfUnit(u);
			if (rg.count != (uint32_t)per[u]) bad++;
			if (s.GetUnitEntityCount(u) != (size_t)per[u]) bad++;
			if (rg.begin != s.GetSegment(u).start) bad++;
			for (uint32_t i = rg.begin; i < rg.begin + rg.count; i++)
			{
				Handle h = st.HandleAt(u, i);
				if (h.IsNull() || st.SlotOf(h) != i) bad++;           // slot <-> handle tables agree
			}
		}
		for (const Rec& r : live)
		{
			size_t slot = st.SlotOf(r.h);
			if (slot == Store::npos) { bad++; continue; }
			if (slot < s.GetSegment(r.unit).start || slot >= s.GetSegment(r.unit).start + s.GetUnitEntityCount(r.unit)) bad++;   // inside its own unit's live range
			if (st.Data(c.pos)[slot].x != float(r.token) || st.Data(c.hp)[slot] != float(r.token) || st.Data(c.isb)[slot].a[0] != float(r.token)) bad++;   // data followed the entity
		}
		for (const Handle& h : dead) if (st.IsAlive(h) || st.SlotOf(h) != Store::npos) bad++;
	};

	for (int step = 0; step < 40000; step++)
	{
		const int op = (int)(rng() % 10);
		if (op < 4)                                               // create
		{
			int u = (int)(rng() % 3);
			int inUnit = 0; for (const Rec& r : live) if (r.unit == u) inUnit++;
			Handle h = u == 0 ? st.Create<A>() : u == 1 ? st.Create<B>() : st.Create<C>();
			if (inUnit >= caps[u]) { if (!h.IsNull()) bad++; }       // full: must be refused
			else
			{
				if (h.IsNull()) { bad++; continue; }
				uint32_t t = nextToken++;
				st.Get(c.pos, h)->x = float(t); *st.Get(c.hp, h) = float(t); st.Get(c.isb, h)->a[0] = float(t);
				live.push_back({ h, u, t, false });
			}
		}
		else if (op < 7 && !live.empty())                         // queue a destroy
		{
			Rec& r = live[rng() % live.size()];
			st.Destroy(r.h); r.queued = true;
			if (rng() % 8 == 0) st.Destroy(r.h);                  // sometimes twice
		}
		else if (op == 7 && !live.empty())                        // immediate destroy of a random entity (nothing queued on it)
		{
			size_t k = rng() % live.size();
			if (!live[k].queued) { if (!st.DestroyNow(live[k].h)) bad++; dead.push_back(live[k].h); live[k] = live.back(); live.pop_back(); }
		}
		else                                                      // flush
		{
			st.Flush();
			for (size_t k = 0; k < live.size();) if (live[k].queued) { dead.push_back(live[k].h); live[k] = live.back(); live.pop_back(); } else k++;
			if (dead.size() > 300) dead.erase(dead.begin(), dead.begin() + 150);
			verify();
		}
	}
	st.Flush();
	for (size_t k = 0; k < live.size();) if (live[k].queued) { dead.push_back(live[k].h); live[k] = live.back(); live.pop_back(); } else k++;
	verify();
	CHECK(bad == 0);
	std::printf("        fuzz: 40000 ops, %zu entities alive at the end, %zu invariant violations\n", live.size(), bad);
}


// ---------------------------------------------------------------------------------------------------------------
// dense units: no handles, slots only. Remove while looping BACKWARDS.
static void test_dense_unit()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>());
	Store st(s); Cols c(st);
	for (int i = 0; i < 10; i++) { size_t sl = st.Append<A>(); CHECK(sl == (size_t)i); st.Data(c.pos)[sl].x = float(i); }
	for (int i = 0; i < 5; i++)  { size_t sl = st.Append<B>(); st.Data(c.pos)[sl].x = 100.f + i; }
	CHECK(st.RangeOf<A>().count == 10 && st.RangeOf<B>().count == 5);
	CHECK(st.HandleAt(0, 3).IsNull());                              // no handles in a dense unit

	// remove the even ones while looping backwards: every entity is seen exactly once, the odd ones survive
	Range r = st.RangeOf<A>(); int visited = 0;
	for (int i = (int)(r.begin + r.count) - 1; i >= (int)r.begin; --i)
	{
		visited++;
		if (int(st.Data(c.pos)[i].x) % 2 == 0) CHECK(st.RemoveAt(0, (size_t)i));
	}
	CHECK(visited == 10 && st.RangeOf<A>().count == 5);
	double sum = 0; r = st.RangeOf<A>(); for (uint32_t i = r.begin; i < r.begin + r.count; i++) sum += st.Data(c.pos)[i].x;
	CHECK(sum == 1 + 3 + 5 + 7 + 9);
	for (int i = 0; i < 5; i++) CHECK(st.Data(c.pos)[s.GetSegment(1).start + i].x == 100.f + i);   // B untouched
	CHECK(!st.RemoveAt(0, 50) && !st.RemoveAt(0, s.GetSegment(1).start));                          // outside the unit's live range

	// mixing the two ways in one unit is refused
	CHECK(st.Create<A>().IsNull());                                 // A is dense
	CHECK(st.Append<B>() != Store::npos);                           // B is dense too
	TScene s2; CHECK(InitScene(s2)); CHECK(s2.AddUnit<A>()); Store st2(s2); Cols c2(st2);
	Handle h = st2.Create<A>(); CHECK(!h.IsNull());
	CHECK(st2.Append<A>() == Store::npos);                          // A is tracked

	// full unit
	TScene s3; CHECK(InitScene(s3)); CHECK(s3.AddUnit<A>(true, 7)); Store st3(s3); Cols c3(st3);
	int n = 0; while (st3.Append<A>() != Store::npos) n++;
	CHECK(n == 7);
}

static void test_clear_unit()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>());
	Store st(s); Cols c(st);
	std::vector<Handle> a;
	for (int i = 0; i < 20; i++) a.push_back(st.Create<A>());
	for (int i = 0; i < 6; i++)  { size_t sl = st.Append<B>(); st.Data(c.pos)[sl].x = 7.f; }
	st.Destroy(a[3]);                                               // queued before the clear
	st.ClearUnit(0);
	CHECK(st.RangeOf<A>().count == 0 && s.GetUnitEntityCount(0) == 0);
	for (const Handle& h : a) CHECK(!st.IsAlive(h));                // every handle of the unit is stale
	st.Flush();                                                     // the queued destroy of a stale handle is ignored
	CHECK(st.RangeOf<A>().count == 0);
	CHECK(st.RangeOf<B>().count == 6);                              // the other unit keeps its entities
	Handle again = st.Create<A>(); CHECK(!again.IsNull() && st.IsAlive(again) && !st.IsAlive(a[0]) && !st.IsAlive(a[3]));
	for (int i = 0; i < 100; i++) CHECK(!st.Create<A>().IsNull() || i >= 99);     // ids are recycled: the unit refills to its capacity
	st.Clear<B>(); CHECK(st.RangeOf<B>().count == 0 && st.Append<B>() == s.GetSegment(1).start);
}

static void test_remove_at_on_tracked_unit()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>());
	Store st(s); Cols c(st);
	Handle h[4]; for (int i = 0; i < 4; i++) { h[i] = st.Create<A>(); st.Data(c.pos)[st.SlotOf(h[i])].x = float(i); }
	CHECK(st.RemoveAt(0, 1));                                       // slot 1 = h[1]
	CHECK(!st.IsAlive(h[1]) && st.IsAlive(h[3]) && st.SlotOf(h[3]) == 1 && st.Get(c.pos, h[3])->x == 3.f);
}

// per-unit column masks and the "does not follow" flag
static void test_column_masks_and_follow()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>() && s.AddUnit<B>());
	Store st(s);
	auto pos  = st.AddGpuColumn<V3>(offsetof(IVB, pos));                     // follows (default)
	auto rot  = st.AddGpuColumn<V3>(offsetof(IVB, rot), false);             // rebuilt by the game every frame: does not follow
	const UnitMask mA = st.MaskOf<A>(), mBoth = st.MaskOf<A, B>();
	auto onlyA = st.AddCpuColumn<float>(mA);                     // only unit A uses it
	auto both  = st.AddCpuColumn<float>(mBoth);
	{ const UnitMask mAB = st.MaskOf<A, B>(); CHECK(st.MaskOf<A>() == 1u && st.MaskOf<B>() == 2u && mAB == 3u); }

	for (int i = 0; i < 4; i++) { size_t a = st.Append<A>(); size_t b = st.Append<B>();
		st.Data(pos)[a].x = float(i); st.Data(rot)[a].x = 10.f + i; st.Data(onlyA)[a] = 20.f + i; st.Data(both)[a] = 30.f + i;
		st.Data(pos)[b].x = float(i); st.Data(rot)[b].x = 10.f + i; st.Data(onlyA)[b] = 777.f;      st.Data(both)[b] = 30.f + i; }
	const size_t B0 = s.GetSegment(1).start;
	CHECK(st.RemoveAt(0, 0));                                                 // A: slot 0 <- last (slot 3)
	CHECK(st.Data(pos)[0].x == 3.f && st.Data(onlyA)[0] == 23.f && st.Data(both)[0] == 33.f);   // masked / following columns moved
	CHECK(st.Data(rot)[0].x == 10.f);                                         // the non-following column did NOT move
	CHECK(st.RemoveAt(1, B0));                                                // B: the A-only column must not be touched
	CHECK(st.Data(pos)[B0].x == 3.f && st.Data(both)[B0] == 33.f);
	CHECK(st.Data(onlyA)[B0] == 777.f);
	size_t sl = st.Append<A>();                                               // zero on create applies the same rules
	CHECK(st.Data(pos)[sl].x == 0.f && st.Data(onlyA)[sl] == 0.f && st.Data(rot)[sl].x == 13.f);   // `rot` keeps its stale value
}

// dense mode against a model: random appends and BACKWARD-loop removals, compared with a plain std::vector per unit
static void test_dense_fuzz()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>(true, 90) && s.AddUnit<B>(true, 150) && s.AddUnit<C>(true, 60));
	Store st(s); Cols c(st);
	std::vector<float> model[3]; const int caps[3] = { 90, 150, 60 };
	std::mt19937 rng(777); float next = 1; size_t bad = 0;
	for (int step = 0; step < 30000; step++)
	{
		const int u = (int)(rng() % 3);
		if (rng() % 3 != 0)
		{
			size_t sl = u == 0 ? st.Append<A>() : u == 1 ? st.Append<B>() : st.Append<C>();
			if ((int)model[u].size() >= caps[u]) { if (sl != Store::npos) bad++; continue; }
			if (sl == Store::npos || sl != s.GetSegment(u).start + model[u].size()) { bad++; continue; }
			st.Data(c.pos)[sl].x = next; st.Data(c.hp)[sl] = next; model[u].push_back(next); next += 1;
		}
		else if (!model[u].empty())                                             // a backward sweep removing ~1/4
		{
			Range r = st.RangeOfUnit(u);
			for (int i = (int)(r.begin + r.count) - 1; i >= (int)r.begin; --i)
				if (rng() % 4 == 0)
				{
					const size_t local = (size_t)i - r.begin;
					if (!st.RemoveAt(u, (size_t)i)) bad++;
					model[u][local] = model[u].back(); model[u].pop_back();      // the same swap-remove on the model
				}
		}
		if (step % 500 == 0)
			for (int k = 0; k < 3; k++)
			{
				Range r = st.RangeOfUnit(k);
				if (r.count != model[k].size()) { bad++; continue; }
				for (uint32_t i = 0; i < r.count; i++) if (st.Data(c.pos)[r.begin + i].x != model[k][i] || st.Data(c.hp)[r.begin + i] != model[k][i]) bad++;
			}
	}
	CHECK(bad == 0);
	std::printf("        dense fuzz: 30000 steps, %zu violations\n", bad);
}


// ---------------------------------------------------------------------------------------------------------------
// dirty-range upload (UploadMode::OnChange)
static TScene::UpdateChache* AcquireSlot(TScene& s)
{
	auto* u = s.UpdateStart();                                           // like the Application: the render side frees finished slots
	for (int g = 0; !u && g < 8; g++) { auto r = s.RenderStart(); if (r) { s.RenderFence(r); s.RenderEnd(); } u = s.UpdateStart(); }
	return u;
}

struct DCols
{
	Column<V3> pos, rot; Column<ISB> isb; Column<float> hp;
	DCols(Store& st) :
		pos(st.AddGpuColumn<V3>(offsetof(IVB, pos), true, UploadMode::OnChange)),
		rot(st.AddGpuColumn<V3>(offsetof(IVB, rot))),                       // Always
		isb(st.AddIsbColumn<ISB>(true, UploadMode::OnChange)),
		hp(st.AddCpuColumn<float>()) {}
};

// the frame slot holds the CPU values of every live entity (the invariant the dirty upload has to keep)
static bool GpuMatches(TScene& s, Store& st, TScene::UpdateChache* u, DCols& c)
{
	const char* base = (const char*)u->instanceVertexBufferDataPtr;
	const V3* gp = (const V3*)(base + kCap * offsetof(IVB, pos));
	const V3* gr = (const V3*)(base + kCap * offsetof(IVB, rot));
	const ISB* gi = (const ISB*)u->instanceStorageBufferDataPtr;
	for (size_t unit = 0; unit < s.GetUnits(); unit++)
	{
		Range r = st.RangeOfUnit((int)unit);
		for (uint32_t i = r.begin; i < r.begin + r.count; i++)
			if (std::memcmp(&gp[i], &st.Data(c.pos)[i], sizeof(V3)) || std::memcmp(&gr[i], &st.Data(c.rot)[i], sizeof(V3)) ||
				std::memcmp(&gi[i], &st.Data(c.isb)[i], sizeof(ISB))) return false;
	}
	return true;
}

static size_t UploadOnce(TScene& s, Store& st, DCols& c, bool* match = nullptr)
{
	auto* u = AcquireSlot(s);
	st.Upload(u);
	if (match) *match = GpuMatches(s, st, u, c);
	s.UpdateEnd(u);
	return st.LastUploadBytes();
}

static void test_dirty_upload_bytes()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>(true, 300));
	Store st(s); DCols c(st);
	for (int i = 0; i < 200; i++) { size_t sl = st.Append<A>(); st.Data(c.pos)[sl].x = float(i); st.Data(c.isb)[sl].a[0] = float(i); st.Data(c.rot)[sl].y = float(i); }
	bool ok = true; bool m;
	// pos 200*12 + rot 200*12 + isb 200*16 = 8000 for each of the 3 frame slots, then only the Always column (rot) = 2400
	const size_t expect1[5] = { 8000, 8000, 8000, 2400, 2400 };
	for (int i = 0; i < 5; i++) { size_t b = UploadOnce(s, st, c, &m); CHECK(b == expect1[i]); ok = ok && m; }

	st.Data(c.pos)[70].x = 99.f; st.TouchAt(c.pos, 0, 70);               // one element: its block of 64 entities (64..127), in each slot once
	const size_t expect2[4] = { 768 + 2400, 768 + 2400, 768 + 2400, 2400 };
	for (int i = 0; i < 4; i++) { size_t b = UploadOnce(s, st, c, &m); CHECK(b == expect2[i]); ok = ok && m; }

	for (int i = 190; i < 200; i++) st.Data(c.pos)[i].z = 5.f;
	st.TouchRange(c.pos, 0, 190, 10);                                      // blocks 2 and 3 as one run: entities 128..199 = 72 * 12 bytes
	for (int i = 0; i < 3; i++) { size_t b = UploadOnce(s, st, c, &m); CHECK(b == 864 + 2400); ok = ok && m; }
	CHECK(UploadOnce(s, st, c, &m) == 2400);

	st.Data(c.isb)[5].a[1] = 7.f; st.Touch(c.isb, Handle{});                // a null handle touches nothing
	CHECK(UploadOnce(s, st, c, &m) == 2400);
	st.Touch(c.isb);                                                       // whole column: 200 * 16 in each slot
	for (int i = 0; i < 3; i++) { CHECK(UploadOnce(s, st, c, &m) == 3200 + 2400); ok = ok && m; }
	CHECK(ok);

	// structural changes mark by themselves: swap-remove marks the destination block, a new entity its block
	st.RemoveAt(0, 3);                                                     // slot 3 <- last (199): block 0
	for (int i = 0; i < 3; i++) { size_t b = UploadOnce(s, st, c, &m); CHECK(b == 64 * 12 + 64 * 16 + 199 * 12); ok = ok && m; }
	size_t sl = st.Append<A>(); st.Data(c.pos)[sl].x = 1.f;                // slot 199, block 3 (entities 192..199 = 8)
	for (int i = 0; i < 3; i++) { size_t b = UploadOnce(s, st, c, &m); CHECK(b == 8 * 12 + 8 * 16 + 200 * 12); ok = ok && m; }
	CHECK(ok);
}

// random structural changes + declared writes, 3 units (one tracked, two dense), GPU slot checked after every upload, verify mode on
static void test_dirty_upload_fuzz()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>(true, 120) && s.AddUnit<B>(true, 80) && s.AddUnit<C>(true, 200));
	Store st(s); DCols c(st); st.SetVerifyUploads(true);
	std::mt19937 rng(4242); std::vector<Handle> handlesA; size_t mismatches = 0; int uploads = 0;
	auto touchSome = [&](int unit)
	{
		Range r = st.RangeOfUnit(unit); if (!r.count) return;
		const uint32_t i = r.begin + rng() % r.count, n = 1 + rng() % 9;
		const uint32_t cnt = std::min(n, r.begin + r.count - i);
		for (uint32_t k = 0; k < cnt; k++) { st.Data(c.pos)[i + k].x = float(rng() % 1000); st.Data(c.isb)[i + k].a[2] = float(rng() % 1000); }
		switch (rng() % 3)
		{
		case 0: st.TouchRange(c.pos, unit, i, cnt); st.TouchRange(c.isb, unit, i, cnt); break;
		case 1: st.TouchUnit(c.pos, unit); st.TouchUnit(c.isb, unit); break;
		default: st.Touch(c.pos); st.Touch(c.isb); break;
		}
	};
	for (int step = 0; step < 30000; step++)
	{
		const int op = (int)(rng() % 12);
		if (op < 3) { Handle h = st.Create<A>(); if (!h.IsNull()) { handlesA.push_back(h); st.Data(c.pos)[st.SlotOf(h)].y = 1.f; st.TouchAt(c.pos, 0, st.SlotOf(h)); } }
		else if (op < 5) { size_t sl = (rng() & 1) ? st.Append<B>() : st.Append<C>(); if (sl != Store::npos) { st.Data(c.pos)[sl].x = float(rng() % 100); st.Data(c.isb)[sl].a[0] = 3.f; /* no Touch: creation marks it */ } }
		else if (op < 6 && !handlesA.empty()) { size_t k = rng() % handlesA.size(); st.Destroy(handlesA[k]); handlesA[k] = handlesA.back(); handlesA.pop_back(); }
		else if (op < 7) st.Flush();
		else if (op < 8) { int u = 1 + (int)(rng() % 2); Range r = st.RangeOfUnit(u); if (r.count) st.RemoveAt(u, r.begin + rng() % r.count); }
		else if (op < 9) touchSome((int)(rng() % 3));
		else if (op < 10) { Range r = st.RangeOfUnit(1); if (r.count) { st.Data(c.rot)[r.begin].z = float(step); } }   // Always column: nothing to declare
		else if (op < 11 && !handlesA.empty()) { Handle h = handlesA[rng() % handlesA.size()]; if (st.IsAlive(h)) { st.Get(c.pos, h)->z = float(step % 17); st.Touch(c.pos, h); } }
		else
		{
			st.Flush();
			bool match = true; UploadOnce(s, st, c, &match); uploads++;
			if (!match) mismatches++;
		}
	}
	CHECK(mismatches == 0 && uploads > 1000);
	CHECK(st.UploadViolations() == 0);              // verify mode: no skipped block ever differed from the CPU array
	std::printf("        dirty upload fuzz: %d uploads, %zu GPU mismatches, %zu undeclared writes\n", uploads, mismatches, st.UploadViolations());
}

// verify mode finds a write that was not declared
static void test_dirty_upload_verify()
{
	TScene s; CHECK(InitScene(s)); CHECK(s.AddUnit<A>());
	Store st(s); DCols c(st); st.SetVerifyUploads(true);
	for (int i = 0; i < 10; i++) st.Data(c.pos)[st.Append<A>()].x = float(i);
	for (int i = 0; i < 3; i++) UploadOnce(s, st, c);                  // every frame slot has it
	st.Data(c.pos)[4].x = 123.f; st.TouchAt(c.pos, 0, 4);              // declared
	for (int i = 0; i < 3; i++) UploadOnce(s, st, c);
	CHECK(st.UploadViolations() == 0);
	st.Data(c.pos)[6].x = 456.f;                                       // NOT declared
	bool match = true; UploadOnce(s, st, c, &match);
	CHECK(st.UploadViolations() >= 1);                                 // found
	CHECK(!match);                                                     // and the GPU slot really is stale without the check
}

int main()
{
	test_segments();
	test_create_destroy_handles();
	test_unit_isolation();
	test_deferred_destroy_in_loop();
	test_full_unit_and_column_rules();
	test_upload();
	test_fuzz();
	test_dense_unit();
	test_clear_unit();
	test_remove_at_on_tracked_unit();
	test_column_masks_and_follow();
	test_dense_fuzz();
	test_dirty_upload_bytes();
	test_dirty_upload_fuzz();
	test_dirty_upload_verify();
	std::printf("storage tests: %d checks, %d failed\n", g_checks, g_fail);
	return g_fail ? 1 : 0;
}
