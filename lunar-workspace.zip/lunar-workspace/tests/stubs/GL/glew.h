#pragma once
// test stub of the GLEW / GL surface used by Core + Window
#include <cstddef>
#include <cstdint>
typedef unsigned int GLenum; typedef unsigned int GLuint; typedef int GLint; typedef int GLsizei;
typedef unsigned char GLboolean; typedef char GLchar;
#define GLAPIENTRY
#define GL_TRUE 1
#define GL_FALSE 0
#define GL_NO_ERROR 0
#define GL_DONT_CARE 0x1100
#define GL_VERSION 0x1F02
#define GL_RENDERER 0x1F01
#define GL_SHADING_LANGUAGE_VERSION 0x8B8C
#define GL_CONTEXT_FLAGS 0x821E
#define GL_CONTEXT_FLAG_DEBUG_BIT 0x2
#define GL_DEBUG_OUTPUT 0x92E0
#define GL_DEBUG_OUTPUT_SYNCHRONOUS 0x8242
#define GL_DEBUG_TYPE_ERROR 0x824C
#define GL_DEBUG_SEVERITY_HIGH 0x9146
#define GL_DEBUG_SEVERITY_MEDIUM 0x9147
#define GL_DEBUG_SEVERITY_LOW 0x9148
#define GL_DEBUG_SEVERITY_NOTIFICATION 0x826B
#define GLEW_OK 0
#define GL_FLOAT 0x1406
extern GLboolean glewExperimental;
extern GLboolean GLEW_VERSION_3_3;
GLenum glewInit();
const unsigned char* glewGetErrorString(GLenum);
GLenum glGetError();
const unsigned char* glGetString(GLenum);
void glGetIntegerv(GLenum, GLint*);
void glEnable(GLenum);
void glViewport(GLint, GLint, GLsizei, GLsizei);
typedef void (*GLDEBUGPROC)(GLenum, GLenum, GLuint, GLenum, GLsizei, const GLchar*, const void*);
void glDebugMessageCallback(GLDEBUGPROC, const void*);
void glDebugMessageControl(GLenum, GLenum, GLenum, GLsizei, const GLuint*, GLboolean);

// ---- extra surface so the real core (Buffer/Scene/Shader/Shape) compiles and the frame ring can run ----
#include "glconsts.h"
typedef unsigned int GLbitfield; typedef float GLfloat; typedef unsigned char GLubyte;
typedef int64_t GLintptr; typedef int64_t GLsizeiptr; typedef uint64_t GLuint64;
struct __GLsync; typedef __GLsync* GLsync;
namespace glstub {
	extern int fenceBusyCalls;          // glClientWaitSync reports "not yet" this many times per fence before signalling
	extern long fences, deletedFences;
}
void glCreateBuffers(GLsizei, GLuint*); void glDeleteBuffers(GLsizei, const GLuint*);
void glNamedBufferStorage(GLuint, GLsizeiptr, const void*, GLbitfield);
void glNamedBufferData(GLuint, GLsizeiptr, const void*, GLenum);
void glNamedBufferSubData(GLuint, GLintptr, GLsizeiptr, const void*);
void* glMapNamedBufferRange(GLuint, GLintptr, GLsizeiptr, GLbitfield);
GLboolean glUnmapNamedBuffer(GLuint);
void glFlushMappedNamedBufferRange(GLuint, GLintptr, GLsizeiptr);
GLsync glFenceSync(GLenum, GLbitfield); void glDeleteSync(GLsync);
GLenum glClientWaitSync(GLsync, GLbitfield, GLuint64);
GLuint glCreateProgram(); GLuint glCreateShader(GLenum);
#define GLSTUB_VOID(name) template<class... A> inline void name(A...) {}
GLSTUB_VOID(glAttachShader) GLSTUB_VOID(glBindBuffer) GLSTUB_VOID(glBindBufferBase) GLSTUB_VOID(glBindBufferRange)
GLSTUB_VOID(glBindVertexArray) GLSTUB_VOID(glCompileShader) GLSTUB_VOID(glCreateVertexArrays) GLSTUB_VOID(glDeleteProgram)
GLSTUB_VOID(glDeleteShader) GLSTUB_VOID(glDeleteVertexArrays) GLSTUB_VOID(glDetachShader) GLSTUB_VOID(glEnableVertexArrayAttrib)
GLSTUB_VOID(glFlushMappedBufferRange) GLSTUB_VOID(glGetProgramInfoLog) GLSTUB_VOID(glGetProgramiv) GLSTUB_VOID(glGetShaderInfoLog)
GLSTUB_VOID(glGetShaderiv) GLSTUB_VOID(glLinkProgram) GLSTUB_VOID(glMemoryBarrier) GLSTUB_VOID(glMultiDrawElementsIndirect)
GLSTUB_VOID(glShaderSource) GLSTUB_VOID(glUseProgram) GLSTUB_VOID(glVertexArrayAttribBinding) GLSTUB_VOID(glVertexArrayAttribFormat)
GLSTUB_VOID(glVertexArrayAttribIFormat) GLSTUB_VOID(glVertexArrayBindingDivisor) GLSTUB_VOID(glVertexArrayElementBuffer)
GLSTUB_VOID(glVertexArrayVertexBuffer)
