#pragma once
// test stub of GLFW with scripted events. Callbacks are stored and fired by the test from the poll hook.
#include <functional>
#include <string>
#include <vector>
#define GLFW_TRUE 1
#define GLFW_FALSE 0
#define GLFW_PRESS 1
#define GLFW_RELEASE 0
#define GLFW_REPEAT 2
#define GLFW_RESIZABLE 0x20003
#define GLFW_OPENGL_DEBUG_CONTEXT 0x22007
#define GLFW_SAMPLES 0x2100D
#define GLFW_ICONIFIED 0x20005
#define GLFW_FOCUSED 0x20001
#define GLFW_CONTEXT_VERSION_MAJOR 0x22002
#define GLFW_CONTEXT_VERSION_MINOR 0x22003
#define GLFW_OPENGL_PROFILE 0x22008
#define GLFW_OPENGL_CORE_PROFILE 0x32001
struct GLFWmonitor {};
struct GLFWvidmode { int width, height, redBits, greenBits, blueBits, refreshRate; };
struct GLFWwindow {
	void* user = nullptr; bool shouldClose = false; bool destroyed = false;
	int w = 0, h = 0, fw = 0, fh = 0; int iconified = 0, focused = 1; double cx = 0, cy = 0;
	void (*close)(GLFWwindow*) = nullptr;
	void (*size)(GLFWwindow*, int, int) = nullptr;
	void (*fb)(GLFWwindow*, int, int) = nullptr;
	void (*pos)(GLFWwindow*, int, int) = nullptr;
	void (*focus)(GLFWwindow*, int) = nullptr;
	void (*iconify)(GLFWwindow*, int) = nullptr;
	void (*key)(GLFWwindow*, int, int, int, int) = nullptr;
	void (*chr)(GLFWwindow*, unsigned int) = nullptr;
	void (*mbtn)(GLFWwindow*, int, int, int) = nullptr;
	void (*cursor)(GLFWwindow*, double, double) = nullptr;
	void (*scroll)(GLFWwindow*, double, double) = nullptr;
};
namespace stub {
	extern std::function<void()> pollHook;      // called inside glfwPollEvents / glfwWaitEventsTimeout (main thread)
	extern int swaps, swapsAfterDestroy, emptyEvents, terminateCalls;
	extern GLFWwindow* lastWindow;
	extern double initCx, initCy;
	extern bool failInit, failCreate, failGlew;   // failure injection
	void Reset();
	void Log(const char* s);                    // thread-safe ordered event log
	std::vector<std::string> TakeLog();
}
typedef void (*GLFWerrorfun)(int, const char*);
GLFWerrorfun glfwSetErrorCallback(GLFWerrorfun);
int glfwInit(); void glfwTerminate();
void glfwWindowHint(int, int);
GLFWwindow* glfwCreateWindow(int, int, const char*, GLFWmonitor*, GLFWwindow*);
void glfwDestroyWindow(GLFWwindow*);
void glfwSetWindowUserPointer(GLFWwindow*, void*); void* glfwGetWindowUserPointer(GLFWwindow*);
void glfwMakeContextCurrent(GLFWwindow*); void glfwSwapInterval(int); void glfwSwapBuffers(GLFWwindow*);
void glfwPollEvents(); void glfwWaitEventsTimeout(double); void glfwPostEmptyEvent();
int glfwWindowShouldClose(GLFWwindow*); void glfwSetWindowShouldClose(GLFWwindow*, int);
void glfwGetWindowSize(GLFWwindow*, int*, int*); void glfwGetFramebufferSize(GLFWwindow*, int*, int*);
void glfwGetWindowContentScale(GLFWwindow*, float*, float*); int glfwGetWindowAttrib(GLFWwindow*, int);
void glfwGetWindowPos(GLFWwindow*, int*, int*); void glfwGetCursorPos(GLFWwindow*, double*, double*);
void glfwSetWindowTitle(GLFWwindow*, const char*);
GLFWmonitor* glfwGetPrimaryMonitor(); const GLFWvidmode* glfwGetVideoMode(GLFWmonitor*);
void glfwSetWindowMonitor(GLFWwindow*, GLFWmonitor*, int, int, int, int, int);
#define DECL_CB(name, ...) void glfwSet##name##Callback(GLFWwindow*, void (*)(__VA_ARGS__));
DECL_CB(WindowClose, GLFWwindow*) DECL_CB(WindowSize, GLFWwindow*, int, int) DECL_CB(FramebufferSize, GLFWwindow*, int, int)
DECL_CB(WindowPos, GLFWwindow*, int, int) DECL_CB(WindowFocus, GLFWwindow*, int) DECL_CB(WindowIconify, GLFWwindow*, int)
DECL_CB(Key, GLFWwindow*, int, int, int, int) DECL_CB(Char, GLFWwindow*, unsigned int) DECL_CB(MouseButton, GLFWwindow*, int, int, int)
DECL_CB(CursorPos, GLFWwindow*, double, double) DECL_CB(Scroll, GLFWwindow*, double, double)
