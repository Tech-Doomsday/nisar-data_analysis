#pragma once
// test stub: only what the new code touches
namespace glm {
	struct dvec2 {
		double x = 0, y = 0;
		dvec2() = default;
		explicit dvec2(double s) : x(s), y(s) {}
		dvec2(double a, double b) : x(a), y(b) {}
		dvec2& operator+=(const dvec2& o) { x += o.x; y += o.y; return *this; }
	};
}
