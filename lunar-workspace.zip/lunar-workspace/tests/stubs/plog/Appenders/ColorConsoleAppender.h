#pragma once
#include "../Log.h"
namespace plog { template<class F> class ColorConsoleAppender : public IAppender { public: void write(Severity s, const std::string& m) override { std::cerr << "[plog " << s << "] " << m << "\n"; } }; }
