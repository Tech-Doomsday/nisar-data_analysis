#pragma once
#include <cstddef>
#include "../Log.h"
namespace plog { template<class F> class RollingFileAppender : public IAppender { public: RollingFileAppender(const char*, size_t, int) {} void write(Severity, const std::string&) override {} }; }
