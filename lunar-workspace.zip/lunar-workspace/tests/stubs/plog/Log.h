#pragma once
// test stub of the plog API used by Log.h / Log.cpp (API as documented by plog 1.1.x)
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
#define PLOG_DEFAULT_INSTANCE_ID 0
namespace plog {
	enum Severity { none = 0, fatal = 1, error = 2, warning = 3, info = 4, debug = 5, verbose = 6 };
	struct IAppender { virtual ~IAppender() = default; virtual void write(Severity, const std::string&) = 0; };
	template<int I = 0> class Logger {
	public:
		Logger& addAppender(IAppender* a) { appenders.push_back(a); return *this; }
		void setMaxSeverity(Severity s) { max = s; }
		bool checkSeverity(Severity s) const { return s <= max; }
		void write(Severity s, const std::string& m) { std::lock_guard<std::mutex> l(mu); for (auto* a : appenders) a->write(s, m); }
		Severity max = none; std::vector<IAppender*> appenders; std::mutex mu;
	};
	template<int I = 0> inline Logger<I>*& LoggerPtr() { static Logger<I>* p = nullptr; return p; }
	template<int I = 0> inline Logger<I>* get() { return LoggerPtr<I>(); }
	template<int I = 0> inline Logger<I>& init(Severity s = none, IAppender* a = nullptr) {
		if (!LoggerPtr<I>()) LoggerPtr<I>() = new Logger<I>(); LoggerPtr<I>()->setMaxSeverity(s); if (a) LoggerPtr<I>()->addAppender(a); return *LoggerPtr<I>(); }
	struct Line { Severity s; std::ostringstream o; bool on;
		explicit Line(Severity sev) : s(sev), on(get() && get()->checkSeverity(sev)) {}
		template<class T> Line& operator<<(const T& v) { if (on) o << v; return *this; }
		~Line() { if (on) get()->write(s, o.str()); } };
}
#define PLOG_VERBOSE ::plog::Line(::plog::verbose)
#define PLOG_DEBUG   ::plog::Line(::plog::debug)
#define PLOG_INFO    ::plog::Line(::plog::info)
#define PLOG_WARNING ::plog::Line(::plog::warning)
#define PLOG_ERROR   ::plog::Line(::plog::error)
#define PLOG_FATAL   ::plog::Line(::plog::fatal)
