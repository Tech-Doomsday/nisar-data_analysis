#include <GLFW/glfw3.h>
#include <GL/glew.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace stub {
	std::function<void()> pollHook;
	int swaps = 0, swapsAfterDestroy = 0, emptyEvents = 0, terminateCalls = 0;
	GLFWwindow* lastWindow = nullptr;
	double initCx = 0, initCy = 0;
	bool failInit = false, failCreate = false, failGlew = false;
	static std::mutex logMutex; static std::vector<std::string> logv;
	void Log(const char* s) { std::lock_guard<std::mutex> l(logMutex); logv.emplace_back(s); }
	std::vector<std::string> TakeLog() { std::lock_guard<std::mutex> l(logMutex); auto v = logv; logv.clear(); return v; }
	void Reset() { pollHook = nullptr; swaps = swapsAfterDestroy = emptyEvents = terminateCalls = 0; lastWindow = nullptr; TakeLog(); initCx = initCy = 0; failInit = failCreate = failGlew = false; }
}
static std::atomic<int> g_emptyEvents{0};

GLboolean glewExperimental = 0; GLboolean GLEW_VERSION_3_3 = 1;
GLenum glewInit() { return stub::failGlew ? 1 : GLEW_OK; }
const unsigned char* glewGetErrorString(GLenum) { return (const unsigned char*)"stub glew failure"; } GLenum glGetError() { return 0; }
const unsigned char* glGetString(GLenum) { return (const unsigned char*)"stub"; }
void glGetIntegerv(GLenum e, GLint* v) { *v = (e == GL_CONTEXT_FLAGS) ? GL_CONTEXT_FLAG_DEBUG_BIT : (e == GL_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT ? 256 : 0); }
void glEnable(GLenum) {} void glViewport(GLint, GLint, GLsizei, GLsizei) {}
void glDebugMessageCallback(GLDEBUGPROC, const void*) {}
void glDebugMessageControl(GLenum, GLenum, GLenum, GLsizei, const GLuint*, GLboolean) {}

GLFWerrorfun glfwSetErrorCallback(GLFWerrorfun f) { return f; }
int glfwInit() { return stub::failInit ? 0 : 1; }
void glfwTerminate() { stub::Log("glfwTerminate"); stub::terminateCalls++; }
void glfwWindowHint(int, int) {}
GLFWwindow* glfwCreateWindow(int w, int h, const char*, GLFWmonitor*, GLFWwindow*) {
	if (stub::failCreate) return nullptr;
	auto* win = new GLFWwindow(); win->w = w; win->h = h; win->fw = w; win->fh = h; win->cx = stub::initCx; win->cy = stub::initCy; stub::lastWindow = win; return win;
}
void glfwDestroyWindow(GLFWwindow* w) { stub::Log("glfwDestroyWindow"); w->destroyed = true; }
void glfwSetWindowUserPointer(GLFWwindow* w, void* p) { w->user = p; }
void* glfwGetWindowUserPointer(GLFWwindow* w) { return w->user; }
void glfwMakeContextCurrent(GLFWwindow*) {} void glfwSwapInterval(int) {}
void glfwSwapBuffers(GLFWwindow* w) { stub::swaps++; if (w->destroyed) stub::swapsAfterDestroy++; std::this_thread::sleep_for(std::chrono::microseconds(300)); }
void glfwPollEvents() { if (stub::pollHook) stub::pollHook(); }
void glfwWaitEventsTimeout(double t) { if (stub::pollHook) stub::pollHook(); std::this_thread::sleep_for(std::chrono::duration<double>(t < 0.005 ? t : 0.005)); }
void glfwPostEmptyEvent() { g_emptyEvents++; stub::emptyEvents = g_emptyEvents; }
int glfwWindowShouldClose(GLFWwindow* w) { return w->shouldClose; }
void glfwSetWindowShouldClose(GLFWwindow* w, int v) { w->shouldClose = v != 0; }
void glfwGetWindowSize(GLFWwindow* w, int* a, int* b) { *a = w->w; *b = w->h; }
void glfwGetFramebufferSize(GLFWwindow* w, int* a, int* b) { *a = w->fw; *b = w->fh; }
void glfwGetWindowContentScale(GLFWwindow*, float* a, float* b) { *a = *b = 1.0f; }
int glfwGetWindowAttrib(GLFWwindow* w, int attr) { return attr == GLFW_ICONIFIED ? w->iconified : attr == GLFW_FOCUSED ? w->focused : 0; }
void glfwGetWindowPos(GLFWwindow*, int* a, int* b) { *a = 10; *b = 20; }
void glfwGetCursorPos(GLFWwindow* w, double* a, double* b) { *a = w->cx; *b = w->cy; }
void glfwSetWindowTitle(GLFWwindow*, const char*) {}
GLFWmonitor* glfwGetPrimaryMonitor() { static GLFWmonitor m; return &m; }
const GLFWvidmode* glfwGetVideoMode(GLFWmonitor*) { static GLFWvidmode v{ 1920, 1080, 8, 8, 8, 60 }; return &v; }
void glfwSetWindowMonitor(GLFWwindow*, GLFWmonitor*, int, int, int, int, int) {}
#define DEF_CB(name, field, ...) void glfwSet##name##Callback(GLFWwindow* w, void (*f)(__VA_ARGS__)) { w->field = f; }
DEF_CB(WindowClose, close, GLFWwindow*) DEF_CB(WindowSize, size, GLFWwindow*, int, int) DEF_CB(FramebufferSize, fb, GLFWwindow*, int, int)
DEF_CB(WindowPos, pos, GLFWwindow*, int, int) DEF_CB(WindowFocus, focus, GLFWwindow*, int) DEF_CB(WindowIconify, iconify, GLFWwindow*, int)
DEF_CB(Key, key, GLFWwindow*, int, int, int, int) DEF_CB(Char, chr, GLFWwindow*, unsigned int) DEF_CB(MouseButton, mbtn, GLFWwindow*, int, int, int)
DEF_CB(CursorPos, cursor, GLFWwindow*, double, double) DEF_CB(Scroll, scroll, GLFWwindow*, double, double)

// ---- GL buffer / sync model for the real-core tests ----
#include <cstdlib>
#include <unordered_map>
namespace glstub { int fenceBusyCalls = 0; long fences = 0, deletedFences = 0; }
namespace {
	std::unordered_map<GLuint, std::vector<char>> g_buffers; GLuint g_nextBuffer = 1;
	struct FakeFence { int calls = 0; };
}
void glCreateBuffers(GLsizei n, GLuint* ids) { for (int i = 0; i < n; ++i) { ids[i] = g_nextBuffer++; g_buffers[ids[i]]; } }
void glDeleteBuffers(GLsizei n, const GLuint* ids) { for (int i = 0; i < n; ++i) g_buffers.erase(ids[i]); }
void glNamedBufferStorage(GLuint b, GLsizeiptr sz, const void*, GLbitfield) { g_buffers[b].assign(size_t(sz), 0); }
void glNamedBufferData(GLuint b, GLsizeiptr sz, const void*, GLenum) { g_buffers[b].assign(size_t(sz), 0); }
void glNamedBufferSubData(GLuint, GLintptr, GLsizeiptr, const void*) {}
void* glMapNamedBufferRange(GLuint b, GLintptr off, GLsizeiptr, GLbitfield) { return g_buffers[b].data() + off; }
GLboolean glUnmapNamedBuffer(GLuint) { return 1; }
void glFlushMappedNamedBufferRange(GLuint, GLintptr, GLsizeiptr) {}
GLsync glFenceSync(GLenum, GLbitfield) { ++glstub::fences; return reinterpret_cast<GLsync>(new FakeFence()); }
void glDeleteSync(GLsync s) { ++glstub::deletedFences; delete reinterpret_cast<FakeFence*>(s); }
GLenum glClientWaitSync(GLsync s, GLbitfield, GLuint64) {
	auto* f = reinterpret_cast<FakeFence*>(s);
	return (++f->calls > glstub::fenceBusyCalls) ? GL_ALREADY_SIGNALED : 0x911B;
}
GLuint glCreateProgram() { return 1; } GLuint glCreateShader(GLenum) { return 1; }
