// Headless tests for the new application layer (stubbed GLFW/GL/plog).
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <future>
#include <sys/wait.h>
#include <unistd.h>
#include <cstdio>
#include <set>
#include <string>
#include <thread>
#include <vector>

#include "LunarApp_noscene.h"
#include <GLFW/glfw3.h>

using namespace lunar;
using namespace std::chrono_literals;

static int g_fail = 0, g_checks = 0;
#define CHECK(c) do { ++g_checks; if (!(c)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
#define RUN(fn) do { std::printf("[ RUN ] %s\n", #fn); int before = g_fail; fn(); std::printf("[ %s ] %s\n", g_fail == before ? " OK " : "FAIL", #fn); } while (0)

// ─────────────────────────────────────────────── EventBus
struct Ping { int v = 0; };
struct Pong { int v = 0; };

static void test_bus_order_and_consume()
{
	EventBus bus;
	std::vector<int> calls;
	auto a = bus.On<Ping>([&](Ping&) { calls.push_back(1); return false; }, 0);
	auto b = bus.On<Ping>([&](Ping&) { calls.push_back(2); return false; }, 10);
	auto c = bus.On<Ping>([&](Ping&) { calls.push_back(3); return false; }, 0);
	auto d = bus.On<Ping>([&](Ping&) { calls.push_back(4); return false; }, -5);
	CHECK(!bus.Emit(Ping{}));
	CHECK((calls == std::vector<int>{ 2, 1, 3, 4 }));        // priority desc, registration order among equals

	calls.clear();
	auto stop = bus.On<Ping>([&](Ping&) { calls.push_back(99); return true; }, 5);   // consumes
	CHECK(bus.Emit(Ping{}));
	CHECK((calls == std::vector<int>{ 2, 99 }));             // 1,3,4 never ran

	calls.clear();
	stop.Reset();
	auto v = bus.On<Ping>([&](Ping&) { calls.push_back(7); }, 100);   // void handler never consumes
	CHECK(!bus.Emit(Ping{}));
	CHECK(calls.size() == 5 && calls[0] == 7);
	CHECK(bus.ListenerCount<Ping>() == 5);
	CHECK(bus.ListenerCount<Pong>() == 0);
}

static void test_bus_copy_semantics()
{
	EventBus bus;
	auto a = bus.On<Ping>([](Ping& p) { p.v += 1; return false; }, 10);
	int seen = -1;
	auto b = bus.On<Ping>([&](Ping& p) { seen = p.v; return false; }, 0);
	Ping mine{ 5 };
	bus.Emit(mine);
	CHECK(seen == 6);          // later listener sees the earlier one's change
	CHECK(mine.v == 5);        // caller's object untouched
}

static void test_bus_reentrancy()
{
	EventBus bus;
	std::vector<int> calls;
	Subscription self, later, added;

	later = bus.On<Ping>([&](Ping&) { calls.push_back(3); return false; }, 0);
	self = bus.On<Ping>([&](Ping&) {
		calls.push_back(1);
		self.Reset();                                   // unsubscribe myself while running
		later.Reset();                                  // and a listener that has not run yet
		added = bus.On<Ping>([&](Ping&) { calls.push_back(9); return false; }, 100);   // subscribe during Emit
		return false;
	}, 10);
	auto tail = bus.On<Ping>([&](Ping&) { calls.push_back(4); return false; }, -1);

	bus.Emit(Ping{});
	CHECK((calls == std::vector<int>{ 1, 4 }));          // removed 'later' skipped, new one not called this time
	calls.clear();
	bus.Emit(Ping{});
	CHECK((calls == std::vector<int>{ 9, 4 }));          // new one is live and ordered by priority, others gone
	CHECK(bus.ListenerCount<Ping>() == 2);
}

static void test_bus_raii_and_lifetime()
{
	EventBus bus;
	int n = 0;
	{
		auto s = bus.On<Ping>([&](Ping&) { ++n; });
		CHECK(s.Active());
		bus.Emit(Ping{});
		Subscription moved = std::move(s);
		CHECK(!s.Active() && moved.Active());
		bus.Emit(Ping{});
	}
	bus.Emit(Ping{});
	CHECK(n == 2);                                       // unsubscribed when `moved` died

	Subscription kept;
	{
		auto d = bus.On<Ping>([&](Ping&) { ++n; });
		d.Detach();                                      // lives as long as the bus
	}
	bus.Emit(Ping{});
	CHECK(n == 3);

	Subscription outlives;
	{
		EventBus shortLived;
		outlives = shortLived.On<Ping>([](Ping&) {});
	}
	outlives.Reset();                                    // bus is gone: must not crash
	CHECK(!outlives.Active());
}

static void test_bus_exception_safety()
{
	EventBus bus;
	int n = 0;
	auto thrower = bus.On<Ping>([&](Ping&) -> bool { throw std::runtime_error("boom"); }, 10);
	auto other = bus.On<Ping>([&](Ping&) { ++n; }, 0);
	bool caught = false;
	try { bus.Emit(Ping{}); } catch (const std::runtime_error&) { caught = true; }
	CHECK(caught);
	thrower.Reset();                                     // would be deferred forever if emitDepth leaked
	CHECK(bus.ListenerCount<Ping>() == 1);
	bus.Emit(Ping{});
	CHECK(n == 1);
}

struct Probe : EventAdapter
{
	int keys = 0; bool consume = false;
	bool OnKeyPressed(events::KeyPressed&) override { ++keys; return consume; }
};
static void test_adapter()
{
	EventBus bus;
	int lower = 0;
	auto low = bus.On<events::KeyPressed>([&](events::KeyPressed&) { ++lower; }, -10);
	{
		Probe p;
		p.SubscribeEvents(bus);
		p.consume = true;
		bus.Emit(events::KeyPressed{});
		CHECK(p.keys == 1 && lower == 0);                // consumed -> lower listener never runs
		p.consume = false;
		bus.Emit(events::KeyPressed{});
		CHECK(p.keys == 2 && lower == 1);
	}
	bus.Emit(events::KeyPressed{});                      // adapter destroyed: no dangling call
	CHECK(lower == 2);
}

// ─────────────────────────────────────────────── queue
static void test_queue_basic()
{
	SpscQueue<int, 4> q;
	int v;
	CHECK(!q.TryPop(v));
	for (int i = 0; i < 4; ++i) CHECK(q.TryPush(i));
	CHECK(!q.TryPush(99));                               // full
	for (int round = 0; round < 10; ++round)             // wrap around many times
	{
		CHECK(q.TryPop(v)); CHECK(v == round);
		CHECK(q.TryPush(4 + round));
	}
}

static void test_queue_threads()
{
	SpscQueue<uint64_t, 1024> q;
	constexpr uint64_t N = 2'000'000;
	std::atomic<bool> ok{ true };
	std::thread consumer([&] {
		uint64_t expect = 0, v;
		while (expect < N) { if (q.TryPop(v)) { if (v != expect) { ok = false; return; } ++expect; } else std::this_thread::yield(); }
	});
	for (uint64_t i = 0; i < N; ++i) while (!q.TryPush(i)) std::this_thread::yield();
	consumer.join();
	CHECK(ok.load());
}

// ─────────────────────────────────────────────── input
static void test_input_edges()
{
	InputRelay relay; Input in;
	// a tap shorter than a tick must not be lost
	relay.Offer(events::KeyPressed{ Key::Space, 0, 0, false }, false);
	relay.Offer(events::KeyReleased{ Key::Space, 0, 0 }, false);
	relay.Drain(in);
	CHECK(in.Pressed(Key::Space) && in.Released(Key::Space) && !in.Down(Key::Space));
	relay.Drain(in);
	CHECK(!in.Pressed(Key::Space) && !in.Released(Key::Space));      // edges last one tick

	// held across ticks
	relay.Offer(events::KeyPressed{ Key::A, 0, 0, false }, false);
	relay.Drain(in); CHECK(in.Pressed(Key::A) && in.Down(Key::A));
	relay.Drain(in); CHECK(!in.Pressed(Key::A) && in.Down(Key::A));
	// auto-repeat is not a press
	relay.Offer(events::KeyPressed{ Key::A, 0, 0, true }, false);
	relay.Drain(in); CHECK(!in.Pressed(Key::A) && in.Down(Key::A));
	relay.Offer(events::KeyReleased{ Key::A, 0, 0 }, false);
	relay.Drain(in); CHECK(in.Released(Key::A) && !in.Down(Key::A));

	// consumed press is hidden, its release changes nothing
	relay.Offer(events::KeyPressed{ Key::B, 0, 0, false }, true);
	relay.Offer(events::KeyReleased{ Key::B, 0, 0 }, true);
	relay.Drain(in); CHECK(!in.Pressed(Key::B) && !in.Released(Key::B) && !in.Down(Key::B));

	relay.Offer(events::MouseButtonPressed{ MouseButton::Left, 0 }, false);
	relay.Drain(in); CHECK(in.Pressed(MouseButton::Left) && in.Down(MouseButton::Left));
	relay.Offer(events::MouseButtonPressed{ MouseButton::Right, 0 }, true);       // UI ate it
	relay.Drain(in); CHECK(!in.Down(MouseButton::Right));

	relay.Offer(events::KeyTyped{ 0x41 }, false);
	relay.Offer(events::KeyTyped{ 0x42 }, true);
	relay.Drain(in); CHECK(in.Typed().size() == 1 && in.Typed()[0] == 0x41);
}

static void test_input_mouse_and_focus()
{
	InputRelay relay; Input in;
	for (int i = 1; i <= 1000; ++i) relay.Offer(events::MouseMoved{ double(i), 2.0 * i, 1.0, 2.0 }, false);
	relay.Offer(events::MouseScrolled{ 0, 1 }, false);
	relay.Offer(events::MouseScrolled{ 0, 2 }, false);
	relay.Offer(events::MouseScrolled{ 0, 100 }, true);                          // consumed
	relay.Flush();
	relay.Drain(in);
	CHECK(in.MousePosition().x == 1000 && in.MousePosition().y == 2000);
	CHECK(in.MouseDelta().x == 1000 && in.MouseDelta().y == 2000);               // coalesced, nothing lost
	CHECK(in.Scroll().y == 3);
	relay.Drain(in);
	CHECK(in.MouseDelta().x == 0 && in.Scroll().y == 0 && in.MousePosition().x == 1000);

	// click position is the position at click time
	relay.Offer(events::MouseMoved{ 5, 5, 5, 5 }, false);
	relay.Offer(events::MouseButtonReleased{ MouseButton::Left, 0 }, false);
	relay.Offer(events::MouseMoved{ 50, 50, 45, 45 }, false);
	relay.Flush();
	relay.Drain(in);
	CHECK(in.MousePosition().x == 50);

	relay.Offer(events::KeyPressed{ Key::W, 0, 0, false }, false);
	relay.Offer(events::MouseButtonPressed{ MouseButton::Left, 0 }, false);
	relay.Drain(in); CHECK(in.Down(Key::W) && in.Down(MouseButton::Left));
	relay.Offer(events::WindowFocus{ false }, false);                            // alt-tab
	relay.Drain(in);
	CHECK(!in.Down(Key::W) && !in.Down(MouseButton::Left) && in.Released(Key::W) && !in.HasFocus());
	relay.Offer(events::WindowFocus{ true }, false);
	relay.Drain(in); CHECK(in.HasFocus());
}

static void test_input_overflow()
{
	InputRelay relay; Input in;
	relay.Offer(events::KeyPressed{ Key::W, 0, 0, false }, false);
	for (int i = 0; i < 5000; ++i) relay.Offer(events::KeyTyped{ 65u }, false);  // update thread stalled
	CHECK(relay.Dropped() > 0);
	relay.Drain(in);
	CHECK(!in.Down(Key::W));                                                     // state untrusted -> released
	relay.Offer(events::KeyPressed{ Key::W, 0, 0, false }, false);
	relay.Drain(in); CHECK(in.Down(Key::W));                                     // and it recovers
}

static void test_input_cross_thread()
{
	InputRelay relay; Input in;
	std::atomic<bool> done{ false };
	std::thread producer([&] {
		for (int i = 0; i < 100000; ++i) {
			relay.Offer(events::KeyPressed{ Key::D, 0, 0, false }, false);
			relay.Offer(events::KeyReleased{ Key::D, 0, 0 }, false);
			if (i % 16 == 0) relay.Flush();
			if (i % 256 == 0) std::this_thread::yield();
		}
		done = true;
	});
	uint64_t presses = 0, releases = 0;
	while (!done.load() || true) {
		relay.Drain(in);
		presses += in.Pressed(Key::D); releases += in.Released(Key::D);
		if (done.load()) { relay.Drain(in); presses += in.Pressed(Key::D); releases += in.Released(Key::D); break; }
	}
	producer.join();
	CHECK(releases > 0 && presses > 0);
	CHECK(!in.Down(Key::D));            // whether or not the queue overflowed on the way, nothing is left stuck down
	std::printf("        cross-thread: %llu presses seen, %llu dropped\n", (unsigned long long)presses, (unsigned long long)relay.Dropped());
}

// ─────────────────────────────────────────────── misc
struct Dummy : Module { using Module::Module; };
static void test_module_stack_order()
{
	ModuleStack s;
	std::vector<Dummy*> raw;
	for (int p : { 0, 100, -5, 0, 100 }) { auto m = std::make_unique<Dummy>("m", p); raw.push_back(m.get()); s.Insert(std::move(m)); }
	std::vector<Module*> order; for (auto& m : s) order.push_back(m.get());
	CHECK((order == std::vector<Module*>{ raw[1], raw[4], raw[0], raw[3], raw[2] }));   // 100,100,0,0,-5 stable
	CHECK(s.Find<Dummy>() == raw[1]);
	auto taken = s.Extract(raw[0]);
	CHECK(taken.get() == raw[0] && s.Count() == 4 && !s.Contains(raw[0]));
	CHECK(s.ExtractFirst().get() == raw[1]);
}

static void test_clock()
{
	FrameClock c(0.05f);
	CHECK(c.Tick() == 0.0f);                              // first delta is 0, not "time since start"
	std::this_thread::sleep_for(120ms);
	CHECK(c.Tick() == 0.05f);                             // clamped
	std::this_thread::sleep_for(10ms);
	float d = c.Tick(); CHECK(d > 0.005f && d < 0.05f);
	CHECK(c.Ticks() == 3 && c.Time() > 0.05);
	FpsCounter f(0.05);
	for (int i = 0; i < 10; ++i) f.Frame();
	std::this_thread::sleep_for(60ms);
	CHECK(f.Update() && f.Fps() > 10 && f.Fps() < 1000);
}

// ─────────────────────────────────────────────── application (headless)
struct FakeSceneCore
{
	struct UpdateChache { int frameNo; };
	struct RenderChache { int frameNo; operator bool() { return frameNo != -1; } };
	enum class S { Free, Written };
	std::atomic<S> state[3]{ S::Free, S::Free, S::Free };
	UpdateChache slots[3]{ {0}, {1}, {2} };
	int ui = 0, ri = 0;
	std::atomic<uint64_t> failedStarts{ 0 };          // how often the update side asked and found no free slot
	std::atomic<uint32_t> signal{ 0 };
	std::atomic<bool> wake{ false };

	UpdateChache* UpdateStart()
	{
		if (state[ui].load(std::memory_order_acquire) == S::Free) return &slots[ui];
		failedStarts.fetch_add(1, std::memory_order_relaxed);
		return nullptr;
	}
	void UpdateEnd(UpdateChache*) { state[ui].store(S::Written, std::memory_order_release); ui = (ui + 1) % 3; }
	RenderChache RenderStart() { return { state[ri].load(std::memory_order_acquire) == S::Written ? ri : -1 }; }
	void RenderFence(RenderChache&) {}
	void RenderEnd() { state[ri].store(S::Free, std::memory_order_release); SignalUpdate(); ri = (ri + 1) % 3; }

	void SignalUpdate() { signal.fetch_add(1, std::memory_order_release); signal.notify_one(); }
};

// same wait/notify code as the real Scene::WaitForUpdateSlot / InterruptUpdateWait
struct FakeScene : FakeSceneCore
{
	bool WaitForUpdateSlot()
	{
		for (;;)
		{
			const uint32_t ticket = signal.load(std::memory_order_acquire);
			if (state[ui].load(std::memory_order_acquire) == S::Free) return true;
			if (wake.load(std::memory_order_acquire)) return false;
			signal.wait(ticket, std::memory_order_acquire);
		}
	}
	void InterruptUpdateWait() { wake.store(true, std::memory_order_release); SignalUpdate(); }
	void ClearUpdateInterrupt() { wake.store(false, std::memory_order_release); }
};

// an older Scene without the wait API: SceneGate must keep working with the polling back-off
struct FakeSceneLegacy : FakeSceneCore {};

struct Watchdog   // a hang becomes a failed run instead of a stuck one
{
	std::mutex m; std::condition_variable cv; bool done = false; std::thread t;
	Watchdog(int ms, const char* what) : t([this, ms, what] {
		std::unique_lock<std::mutex> l(m);
		if (!cv.wait_for(l, std::chrono::milliseconds(ms), [&] { return done; })) { std::printf("  WATCHDOG: %s hung\n", what); std::fflush(stdout); _exit(3); }
	}) {}
	~Watchdog() { { std::lock_guard<std::mutex> l(m); done = true; } cv.notify_all(); t.join(); }
};

struct Counters
{
	std::atomic<int> updates{ 0 }, renders{ 0 }, mounts{ 0 }, unmounts{ 0 };
	std::thread::id updateThread, renderThread, mountThread;
	std::atomic<bool> updateThreadVaried{ false };
	std::mutex mu; std::vector<int> updateOrder, renderOrder;
};

struct TestModule : Module
{
	Counters& c; std::function<void(TestModule&, const UpdateContext&)> onUpdate; std::function<void(TestModule&, const RenderContext&)> onRender;
	std::function<void(TestModule&)> onMount;
	// NOTE: a module mounted from another thread must be configured through its constructor only
	struct Hooks { std::function<void(TestModule&)> mount; std::function<void(TestModule&, const UpdateContext&)> update; };
	TestModule(Counters& cc, int prio, const char* name = "t") : Module(name, prio), c(cc) {}
	TestModule(Counters& cc, int prio, const char* name, Hooks h) : Module(name, prio), c(cc), onUpdate(std::move(h.update)), onMount(std::move(h.mount)) {}
	void OnMount() override { c.mounts++; c.mountThread = std::this_thread::get_id(); stub::Log("OnMount"); if (onMount) onMount(*this); }
	void OnUnmount() override { c.unmounts++; stub::Log("OnUnmount"); }
	~TestModule() override { stub::Log("~Module"); }
	void OnUpdate(const UpdateContext& u) override
	{
		c.updates++;
		if (c.updateThread == std::thread::id{}) c.updateThread = std::this_thread::get_id();
		else if (c.updateThread != std::this_thread::get_id()) c.updateThreadVaried = true;
		{ std::lock_guard<std::mutex> l(c.mu); if (c.updateOrder.size() < 6) c.updateOrder.push_back(GetPriority()); }
		if (onUpdate) onUpdate(*this, u);
	}
	void OnRender(const RenderContext& r) override
	{
		c.renders++; c.renderThread = std::this_thread::get_id();
		{ std::lock_guard<std::mutex> l(c.mu); if (c.renderOrder.size() < 6) c.renderOrder.push_back(GetPriority()); }
		if (onRender) onRender(*this, r);
	}
	using Module::Listen; using Module::App; using Module::Events;
};

struct Member { ~Member() { stub::Log("~AppMember"); } };

struct TestApp : Application
{
	Counters& c; FakeScene scene; FakeSceneLegacy legacyScene; Member member; bool useGate; bool legacy; std::function<void(TestApp&)> startHook;
	TestApp(Counters& cc, ThreadingMode mode, bool gate = true, std::function<void(TestApp&)> hook = {}, bool legacyGate = false)
		: Application(MakeSpec(mode)), c(cc), useGate(gate), legacy(legacyGate), startHook(std::move(hook)) {}
	FakeSceneCore& ring() { return legacy ? static_cast<FakeSceneCore&>(legacyScene) : static_cast<FakeSceneCore&>(scene); }
	static ApplicationSpec MakeSpec(ThreadingMode m) { ApplicationSpec s; s.threading = m; s.title = "test"; s.maxDelta = 0.05f; return s; }
	void OnStart() override
	{
		stub::Log("OnStart");
		if (useGate && legacy) SetGate(std::make_unique<SceneGate<FakeSceneLegacy>>(legacyScene));
		else if (useGate) SetGate(std::make_unique<SceneGate<FakeScene>>(scene));
		if (startHook) startHook(*this);
	}
	void OnStop() override { stub::Log("OnStop"); }
};

static void quit_after_renders(TestModule& m, const RenderContext&, int n) { if (m.c.renders >= n) m.App().Quit(); }

static void test_app_split_basic()
{
	stub::Reset();
	Counters c;
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& game = a.Mount<TestModule>(c, 0, "game");
		auto& ui = a.Mount<TestModule>(c, 100, "ui");
		game.onRender = [](TestModule& m, const RenderContext& r) { quit_after_renders(m, r, 60); CHECK(r.window.fbWidth == 1280); };
		(void)ui;
	});
	int rc = app.Run();
	CHECK(rc == 0);
	CHECK(c.mounts == 2 && c.mountThread == std::this_thread::get_id());
	CHECK(c.updates > 20 && c.renders >= 60);
	CHECK(c.updateThread != std::this_thread::get_id());          // really on another thread
	CHECK(c.renderThread == std::this_thread::get_id());
	CHECK(!c.updateThreadVaried);
	// priority rules: update high->low, render low->high
	CHECK(c.updateOrder.size() >= 2 && c.updateOrder[0] == 100 && c.updateOrder[1] == 0);
	CHECK(c.renderOrder.size() >= 2 && c.renderOrder[0] == 0 && c.renderOrder[1] == 100);
	CHECK(stub::swaps >= 30);                                      // 60 renders / 2 modules = 30 frames
	CHECK(c.unmounts == 2);
}

static void test_app_single_thread()
{
	stub::Reset();
	Counters c;
	TestApp app(c, ThreadingMode::Single, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.onRender = [](TestModule& mm, const RenderContext& r) { quit_after_renders(mm, r, 50); };
	});
	CHECK(app.Run() == 0);
	CHECK(c.updates > 10 && c.renders >= 50);
	CHECK(c.updateThread == std::this_thread::get_id() && c.renderThread == std::this_thread::get_id());
}

static void test_app_shutdown_order()
{
	stub::Reset();
	{
		Counters c;
		TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
			auto& m = a.Mount<TestModule>(c, 0);
			m.onRender = [](TestModule& mm, const RenderContext& r) { quit_after_renders(mm, r, 5); };
		});
		CHECK(app.Run() == 0);
		auto log = stub::TakeLog();
		// order after the loops: OnStop, then the module is unmounted and destroyed, window still alive
		auto idx = [&](const char* s) { for (size_t i = 0; i < log.size(); ++i) if (log[i] == s) return int(i); return -1; };
		CHECK(idx("OnStop") > idx("OnMount"));
		CHECK(idx("OnUnmount") > idx("OnStop"));
		CHECK(idx("~Module") > idx("OnUnmount"));
		CHECK(idx("glfwDestroyWindow") == -1);                    // not yet: window dies in ~Application
		stub::Log("--end of Run--");
		(void)app;
	}
	auto log = stub::TakeLog();
	auto idx = [&](const char* s) { for (size_t i = 0; i < log.size(); ++i) if (log[i] == s) return int(i); return -1; };
	CHECK(idx("~AppMember") != -1 && idx("glfwDestroyWindow") != -1 && idx("glfwTerminate") != -1);
	CHECK(idx("~AppMember") < idx("glfwDestroyWindow"));          // subclass members die while the context is alive
	CHECK(idx("glfwDestroyWindow") < idx("glfwTerminate"));
	CHECK(stub::swapsAfterDestroy == 0);
}

static void test_app_events_and_input()
{
	stub::Reset();
	Counters c;
	std::atomic<int> seenByLow{ 0 }, seenByUi{ 0 };
	std::atomic<bool> updateSawSpace{ false }, updateSawEnter{ false }, updateSawX{ false };
	int frame = 0;
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& ui = a.Mount<TestModule>(c, 100, "ui");
		auto& game = a.Mount<TestModule>(c, 0, "game");
		ui.Listen<events::KeyPressed>([&](events::KeyPressed& e) { ++seenByUi; return e.key == Key::Space; });   // UI eats Space
		game.Listen<events::KeyPressed>([&](events::KeyPressed&) { ++seenByLow; });
		game.onUpdate = [&](TestModule&, const UpdateContext& u) {
			if (u.input.Pressed(Key::Space)) updateSawSpace = true;
			if (u.input.Pressed(Key::Enter)) updateSawEnter = true;
			if (u.input.Pressed(Key::X)) updateSawX = true;
		};
		game.onRender = [](TestModule& m, const RenderContext& r) { quit_after_renders(m, r, 120); };
	});
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow;
		if (!w) return;
		++frame;
		if (frame == 10) { w->key(w, int(Key::Space), 0, GLFW_PRESS, 0); w->key(w, int(Key::Space), 0, GLFW_RELEASE, 0); }
		if (frame == 12) { w->key(w, int(Key::Enter), 0, GLFW_PRESS, 0); w->key(w, int(Key::Enter), 0, GLFW_RELEASE, 0); }
		if (frame == 14) { w->key(w, int(Key::X), 0, GLFW_PRESS, 0); w->key(w, int(Key::X), 0, GLFW_RELEASE, 0); }
		if (frame == 16) { w->key(w, -1, 0, GLFW_PRESS, 0); }                        // GLFW_KEY_UNKNOWN: ignored
	};
	CHECK(app.Run() == 0);
	CHECK(seenByUi == 3);                       // ui saw every press (priority 100)
	CHECK(seenByLow == 2);                      // Space was consumed by the ui: never reached the game's listener
	CHECK(!updateSawSpace);                     // ...nor the update thread
	CHECK(updateSawEnter && updateSawX);        // other keys: even a press+release in one poll arrives
}

static void test_app_close_veto()
{
	stub::Reset();
	Counters c;
	int frame = 0;
	std::atomic<int> closeAsked{ 0 };
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.Listen<events::WindowClosed>([&](events::WindowClosed&) { return ++closeAsked == 1; });   // veto the first one only
	});
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
		if (frame == 5 || frame == 40) { w->shouldClose = true; w->close(w); }       // like the X button
	};
	CHECK(app.Run() == 0);
	CHECK(closeAsked == 2);
	CHECK(frame >= 40);                         // survived the first close request
}

static void test_app_request_close_flag()
{
	stub::Reset();
	Counters c; int frame = 0;
	TestApp app(c, ThreadingMode::Single, false, [&](TestApp& a) { a.Mount<TestModule>(c, 0); });
	stub::pollHook = [&] { if (++frame == 8 && stub::lastWindow) stub::lastWindow->shouldClose = true; };   // no callback fired
	CHECK(app.Run() == 0);
	CHECK(frame < 30);
}

static void test_app_quit_from_update_thread()
{
	stub::Reset();
	Counters c;
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.onUpdate = [](TestModule& mm, const UpdateContext&) { if (mm.c.updates > 30) mm.App().Quit(7); };
	});
	CHECK(app.Run() == 7);
}

static void test_app_dynamic_modules()
{
	stub::Reset();
	const std::thread::id mainThreadId = std::this_thread::get_id();
	Counters c;
	std::atomic<bool> lateMountedOnMain{ false }, unmountedLate{ false };
	std::atomic<int> lateUpdates{ 0 };
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.onUpdate = [&](TestModule& mm, const UpdateContext&) {
			if (mm.c.updates == 10) {                      // from the UPDATE thread
				const std::thread::id mainId = mainThreadId;
				mm.App().Mount<TestModule>(c, 50, "late", TestModule::Hooks{
					[&, mainId](TestModule&) { lateMountedOnMain = (std::this_thread::get_id() == mainId); },
					[&](TestModule&, const UpdateContext&) { ++lateUpdates; } });
			}
		};
		m.onRender = [&](TestModule& mm, const RenderContext&) {
			if (lateUpdates > 20 && !unmountedLate) { unmountedLate = true; mm.App().Quit(); }
		};
	});
	CHECK(app.Run() == 0);
	CHECK(c.mounts == 2 && lateUpdates > 20);
	CHECK(lateMountedOnMain);                                 // mounted from the update thread, OnMount ran on the main thread
	CHECK(c.unmounts == 2);                                   // the late module is unmounted at shutdown
}

static void test_app_unmount_while_running()
{
	stub::Reset();
	Counters c;
	std::atomic<int> victimUpdates{ 0 }; std::atomic<int> after{ 0 }; bool asked = false;
	struct Victim : TestModule { using TestModule::TestModule; };
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& v = a.Mount<Victim>(c, 10, "victim");
		v.onUpdate = [&](TestModule&, const UpdateContext&) { ++victimUpdates; };
		auto& m = a.Mount<TestModule>(c, 0);
		m.onRender = [&](TestModule& mm, const RenderContext&) {
			if (!asked && victimUpdates > 10) { asked = true; CHECK(mm.App().Unmount<Victim>()); CHECK(mm.App().Unmount<Victim>()); }  // twice: harmless
			if (asked && ++after > 60) mm.App().Quit();
		};
	});
	CHECK(app.Run() == 0);
	CHECK(c.unmounts == 2);
	CHECK(app.GetModule<Victim>() == nullptr);
}

static void test_app_update_exception()
{
	stub::Reset();
	Counters c; bool thrown = false;
	{
		TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
			auto& m = a.Mount<TestModule>(c, 0);
			m.onUpdate = [](TestModule& mm, const UpdateContext&) { if (mm.c.updates == 5) throw std::runtime_error("sim exploded"); };
		});
		try { app.Run(); } catch (const std::runtime_error& e) { thrown = std::string(e.what()) == "sim exploded"; }
	}
	CHECK(thrown);
	auto log = stub::TakeLog();
	int destroyed = 0; for (auto& s : log) destroyed += (s == "glfwDestroyWindow");
	CHECK(destroyed == 1);                                     // still cleaned up
	CHECK(c.unmounts == 1);
}

static void test_app_start_exception_and_double_instance()
{
	stub::Reset();
	Counters c; bool thrown = false;
	{
		TestApp app(c, ThreadingMode::Single, false, [&](TestApp& a) { a.Mount<TestModule>(c, 0); throw std::logic_error("bad start"); });
		bool second = false;
		try { TestApp other(c, ThreadingMode::Single); } catch (const std::logic_error&) { second = true; }
		CHECK(second);                                         // only one Application at a time
		try { app.Run(); } catch (const std::logic_error&) { thrown = true; }
	}
	CHECK(thrown);
	CHECK(c.unmounts == 1);
	CHECK(!Application::Exists());
}

static void test_app_ungated_update_rate()
{
	stub::Reset();
	Counters c;
	ApplicationSpec spec;
	struct App2 : Application {
		Counters& c; App2(Counters& cc, ApplicationSpec s) : Application(std::move(s)), c(cc) {}
		void OnStart() override {
			auto& m = Mount<TestModule>(c, 0);
			m.onRender = [this](TestModule&, const RenderContext&) {
				static auto t0 = std::chrono::steady_clock::now();
				if (std::chrono::steady_clock::now() - t0 > 500ms) Quit();
			};
		}
	};
	spec.updateHz = 100.0; spec.threading = ThreadingMode::Split;
	App2 app(c, spec);
	CHECK(app.Run() == 0);
	CHECK(c.updates > 25 && c.updates < 80);                  // ~50 ticks in 0.5 s at 100 Hz (render quits a bit early)
}

static void test_app_minimized()
{
	stub::Reset();
	Counters c; int frame = 0; std::atomic<int> rendersWhileIconified{ 0 };
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.onRender = [&](TestModule&, const RenderContext&) { if (stub::lastWindow->iconified) ++rendersWhileIconified; };
	});
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
		if (frame == 20) { w->iconified = 1; w->iconify(w, 1); }
		if (frame == 60) { w->iconified = 0; w->iconify(w, 0); }
		if (frame == 90) { w->shouldClose = true; w->close(w); }
	};
	CHECK(app.Run() == 0);
	CHECK(rendersWhileIconified == 0);
	CHECK(frame >= 90);
}

static void test_cursor_mapping_and_first_delta()
{
	stub::Reset();
	Counters c; std::vector<events::MouseMoved> moves; int frame = 0;
	WindowMetrics wm; wm.width = 800; wm.height = 450; wm.fbWidth = 1600; wm.fbHeight = 900;
	auto p = wm.CursorToFramebuffer(100, 50);
	CHECK(p.x == 200 && p.y == 800);                           // x2 DPI, y flipped
	stub::initCx = 300; stub::initCy = 300;                     // where the cursor is when the window appears
	TestApp app(c, ThreadingMode::Single, false, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.Listen<events::MouseMoved>([&](events::MouseMoved& e) { moves.push_back(e); });
	});
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
		if (frame == 2) w->cursor(w, 310, 305);
		if (frame == 3) w->cursor(w, 320, 300);
		if (frame == 4) w->focus(w, 0);
		if (frame == 5) w->focus(w, 1);
		if (frame == 6) w->cursor(w, 900, 900);                // jump while unfocused
		if (frame == 7) w->shouldClose = true;
	};
	CHECK(app.Run() == 0);
	CHECK(moves.size() == 3);
	CHECK(moves[0].dx == 10 && moves[0].dy == 5);             // first event after create: relative to the real cursor pos
	CHECK(moves[1].dx == 10 && moves[1].dy == -5);
	CHECK(moves[2].dx == 0 && moves[2].dy == 0);              // after refocus: no spike
}


// ─────────────────────────────────────────────── scene wait API (the eventcount) + parking in the application
static void test_scene_wait_api()
{
	Watchdog dog(20000, "test_scene_wait_api");
	FakeScene sc;
	// free slot: returns at once
	CHECK(sc.WaitForUpdateSlot());

	// blocked until the render side frees a slot
	for (int i = 0; i < 3; ++i) { auto* u = sc.UpdateStart(); CHECK(u != nullptr); sc.UpdateEnd(u); }
	CHECK(sc.UpdateStart() == nullptr);
	std::atomic<int> result{ -1 };
	std::thread waiter([&] { result = sc.WaitForUpdateSlot() ? 1 : 0; });
	std::this_thread::sleep_for(50ms);
	CHECK(result == -1);                                   // really parked
	auto r = sc.RenderStart(); CHECK(bool(r)); sc.RenderFence(r); sc.RenderEnd();   // frees slot 0 + signals
	waiter.join();
	CHECK(result == 1 && sc.UpdateStart() != nullptr);

	// interrupt: returns false, stays false for later calls, can be re-armed
	for (int i = 0; i < 1; ++i) { auto* u = sc.UpdateStart(); sc.UpdateEnd(u); }          // ring full again
	result = -1;
	std::thread waiter2([&] { result = sc.WaitForUpdateSlot() ? 1 : 0; });
	std::this_thread::sleep_for(30ms);
	sc.InterruptUpdateWait();
	waiter2.join();
	CHECK(result == 0);
	CHECK(!sc.WaitForUpdateSlot());                        // sticky
	sc.ClearUpdateInterrupt();
	auto r2 = sc.RenderStart(); sc.RenderFence(r2); sc.RenderEnd();
	CHECK(sc.WaitForUpdateSlot());

	// stress: producer parks instead of polling, consumer renders; no lost wake-up, no hang, order preserved
	FakeScene ring;
	constexpr int N = 200000;
	std::atomic<int> produced{ 0 };
	std::thread producer([&] {
		while (produced < N) {
			if (auto* u = ring.UpdateStart()) { u->frameNo = produced; ring.UpdateEnd(u); ++produced; }
			else ring.WaitForUpdateSlot();
		}
	});
	int consumed = 0; bool ordered = true;
	while (consumed < N) {
		auto rc = ring.RenderStart();
		if (rc) { if (ring.slots[rc.frameNo].frameNo != consumed) ordered = false; ++consumed; ring.RenderFence(rc); ring.RenderEnd(); }
		else std::this_thread::yield();
	}
	producer.join();
	CHECK(ordered && produced == N);
}

static void test_app_parks_when_ring_full()
{
	Watchdog dog(30000, "test_app_parks_when_ring_full");
	auto run = [&](bool legacy) -> uint64_t {
		stub::Reset();
		Counters c; int frame = 0; uint64_t atStart = 0, atEnd = 0;
		TestApp* appPtr = nullptr;
		TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) { a.Mount<TestModule>(c, 0); }, legacy);
		appPtr = &app;
		stub::pollHook = [&] {
			GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
			if (frame == 20) { w->iconified = 1; w->iconify(w, 1); }                    // nothing is rendered from now on
			if (frame == 25) atStart = appPtr->ring().failedStarts;                      // ring is full by now
			if (frame == 65) atEnd = appPtr->ring().failedStarts;                        // ~200 ms later
			if (frame == 70) { w->iconified = 0; w->iconify(w, 0); }
			if (frame == 120) { w->shouldClose = true; w->close(w); }
		};
		CHECK(app.Run() == 0);
		CHECK(c.updates > 5);
		return atEnd - atStart;
	};
	const uint64_t parked = run(false);
	const uint64_t polled = run(true);
	std::printf("        failed UpdateStart calls while the ring was full for ~200 ms:  waiting gate %llu   polling gate %llu\n",
		(unsigned long long)parked, (unsigned long long)polled);
	CHECK(parked <= 10);                                   // parked: no polling at all
	CHECK(polled > 200);                                   // the old back-off keeps hammering
}

static void test_app_quit_while_parked()
{
	Watchdog dog(20000, "test_app_quit_while_parked");
	stub::Reset();
	Counters c; int frame = 0;
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) { a.Mount<TestModule>(c, 0); });
	stub::pollHook = [&] {
		GLFWwindow* w = stub::lastWindow; if (!w) return; ++frame;
		if (frame == 15) { w->iconified = 1; w->iconify(w, 1); }                        // update thread fills the ring and parks
		if (frame == 40) { w->shouldClose = true; w->close(w); }                        // quit while it is parked: must not hang
	};
	CHECK(app.Run() == 0);
	CHECK(c.unmounts == 1);
}

static void test_app_legacy_gate()
{
	Watchdog dog(20000, "test_app_legacy_gate");
	stub::Reset();
	Counters c;
	TestApp app(c, ThreadingMode::Split, true, [&](TestApp& a) {
		auto& m = a.Mount<TestModule>(c, 0);
		m.onRender = [](TestModule& mm, const RenderContext& r) { quit_after_renders(mm, r, 60); };
	}, /*legacyGate*/ true);
	CHECK(app.Run() == 0);
	CHECK(c.updates > 20 && c.renders >= 60);
}

// ─────────────────────────────────────────────── core fixes
static void test_core_return_values()
{
	stub::Reset();
	stub::failInit = true;
	CHECK(!Core::Init());
	CHECK(!Core::CreateWindow(10, 10, "x"));               // not initialised

	stub::Reset();
	CHECK(Core::Init());
	CHECK(Core::Init());                                   // already initialised: still "ready"
	stub::failCreate = true;
	CHECK(!Core::CreateWindow(10, 10, "x"));
	CHECK(!Core::CreateWindow(10, 10, "x"));               // the failed attempt tore Core down

	stub::Reset();
	CHECK(Core::Init());
	CHECK(Core::CreateWindow(10, 10, "x") && Core::GetWindow() != nullptr);
	stub::failGlew = true;
	CHECK(!Core::MakeContextCurrent(Core::GetWindow()));
	stub::failGlew = false;
	CHECK(Core::MakeContextCurrent(Core::GetWindow()));
	CHECK(Core::MakeContextCurrent(Core::GetWindow()));    // second call: nothing to do, still true
	Core::Terminate();
	CHECK(Core::GetWindow() == nullptr);
}

static void test_app_reports_platform_failures()
{
	for (int mode = 0; mode < 3; ++mode)
	{
		stub::Reset();
		stub::failInit = (mode == 0); stub::failCreate = (mode == 1); stub::failGlew = (mode == 2);
		Counters c; bool started = false;
		{
			TestApp app(c, ThreadingMode::Single, false, [&](TestApp&) { started = true; });
			CHECK(app.Run() == 1);                         // reported, not a crash / hang / silent success
			CHECK(!started);                               // OnStart is never reached without a window
		}
		auto log = stub::TakeLog();
		int destroyed = 0; for (auto& l : log) destroyed += (l == "glfwDestroyWindow");
		if (mode == 2) CHECK(destroyed == 1);              // the window that was created is cleaned up again
		CHECK(!Application::Exists());
	}
}

static bool c_true() { return true; }
static void test_assert_macro()
{
	LUNAR_ASSERT(1 == 1);
	LUNAR_ASSERT_MSG(2 > 1, "never printed");
	if (c_true()) LUNAR_ASSERT(true); else LUNAR_ASSERT(true);                // safe in if/else

	auto dies = [](auto&& fn) {
		fflush(stdout);
		pid_t pid = fork();
		if (pid == 0) { if (!freopen("/dev/null", "w", stderr)) _exit(9); fn(); _exit(0); }
		int st = 0; waitpid(pid, &st, 0);
		return WIFSIGNALED(st);
	};
	CHECK(dies([] { LUNAR_ASSERT(1 == 2); }));
	CHECK(dies([] { LUNAR_ASSERT_MSG(false, "boom " << 42); }));
	CHECK(!dies([] { LUNAR_ASSERT(true); }));
}

int main()
{
	Log::Init(LogConfig{ LogLevel::Warn, false, false });      // quiet
	RUN(test_bus_order_and_consume);
	RUN(test_bus_copy_semantics);
	RUN(test_bus_reentrancy);
	RUN(test_bus_raii_and_lifetime);
	RUN(test_bus_exception_safety);
	RUN(test_adapter);
	RUN(test_queue_basic);
	RUN(test_queue_threads);
	RUN(test_input_edges);
	RUN(test_input_mouse_and_focus);
	RUN(test_input_overflow);
	RUN(test_input_cross_thread);
	RUN(test_module_stack_order);
	RUN(test_clock);
	RUN(test_app_split_basic);
	RUN(test_app_single_thread);
	RUN(test_app_shutdown_order);
	RUN(test_app_events_and_input);
	RUN(test_app_close_veto);
	RUN(test_app_request_close_flag);
	RUN(test_app_quit_from_update_thread);
	RUN(test_app_dynamic_modules);
	RUN(test_app_unmount_while_running);
	RUN(test_app_update_exception);
	RUN(test_app_start_exception_and_double_instance);
	RUN(test_app_ungated_update_rate);
	RUN(test_app_minimized);
	RUN(test_cursor_mapping_and_first_delta);
	RUN(test_scene_wait_api);
	RUN(test_app_parks_when_ring_full);
	RUN(test_app_quit_while_parked);
	RUN(test_app_legacy_gate);
	RUN(test_core_return_values);
	RUN(test_app_reports_platform_failures);
	RUN(test_assert_macro);
	std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
	return g_fail ? 1 : 0;
}
