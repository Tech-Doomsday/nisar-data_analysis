// Runs the REAL game World (Game/World.h) headless for thousands of frames with a scripted input and a fixed seed, and prints a hash of
// everything the update thread produces each frame (every unit's instance data, ISB, draw-command counts, UBO packet, particle events).
// Build it against two versions of the game and diff the output: identical lines == identical behaviour.
#include <cstdio>
#include <cstring>
#include "Game/GameTypes.h"
#include "Game/Meshes.h"
#include "Game/World.h"

using namespace game;

struct Hash
{
	uint64_t h = 1469598103934665603ull;
	void Bytes(const void* p, size_t n) { const unsigned char* b = (const unsigned char*)p; for (size_t i = 0; i < n; i++) { h ^= b[i]; h *= 1099511628211ull; } }
	template<class T> void Add(const T& v) { Bytes(&v, sizeof(T)); }
};

int main(int argc, char** argv)
{
	const int frames = argc > 1 ? std::atoi(argv[1]) : 6000;
	const uint32_t seed = argc > 2 ? (uint32_t)std::strtoul(argv[2], nullptr, 0) : 0xC0FFEEu;   // game rng seed (also scripts the input)
	GameScene scene;
	if (!scene.Init({ {0, 2, GL_FLOAT, sizeof(float) * 2}, {3, 1, GL_FLOAT, sizeof(float) * 1} },
		{ {1, 4, GL_FLOAT, sizeof(float) * 4}, {2, 4, GL_FLOAT, sizeof(float) * 4} }, (int)U_COUNT, INSTANCE_STORAGE_BYTES, RESERVED_UNITS)) return 2;
	if (!scene.AddUnit<KPickup>() || !scene.AddUnit<KAsteroid>() || !scene.AddUnit<KDrone>() || !scene.AddUnit<KGunner>() ||
		!scene.AddUnit<KEnemyBullet>() || !scene.AddUnit<KPlayerBullet>() || !scene.AddUnit<KPlayer>() || !scene.AddUnit<KRing>() || !scene.AddUnit<KHud>()) return 3;
	scene.SetShaderInstanceStorageBufferBindingPoint(0);

	World world; world.Init(scene); world.Seed(seed);
	Input in;
	std::vector<unsigned char> events(EVENT_SLICE);
	uint32_t rs = 99 + seed; auto rnd = [&] { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; };
	uint32_t keys = 0; Hash total; size_t maxCount[U_COUNT] = {}; size_t maxEntities = 0; int checkedFrames = 0;

	for (int f = 0; f < frames; f++)
	{
		if (f % 9 == 0) { keys = rnd() & (K_UP | K_DOWN | K_LEFT | K_RIGHT | K_NOVA); if (rnd() % 8 != 0) keys |= K_FIRE; }
		in.keys.store(keys);
		in.mouseX.store(600.0f * std::sin(f * 0.013f)); in.mouseY.store(300.0f * std::cos(f * 0.021f));
		uint32_t pressed = 0;
		if (f == 3 || f % 150 == 0) pressed |= P_START;
		if (f % 410 == 0) pressed |= P_NOVA;
		if (f % 1500 == 700) pressed |= P_PAUSE;
		if (f % 1500 == 760) pressed |= P_PAUSE;
		in.pressed.store(pressed);

		// like the Application: when the update side finds no free slot, the render side polls (a finished slot is freed there)
		GameScene::UpdateChache* u = scene.UpdateStart();
		for (int guard = 0; !u && guard < 8; guard++)
		{
			auto r = scene.RenderStart();
			if (r) { scene.RenderFence(r); scene.RenderEnd(); }
			u = scene.UpdateStart();
		}
		if (!u) { std::printf("no free slot at frame %d\n", f); return 4; }
		std::memset(events.data(), 0, events.size());
		world.Tick(1.0f / 60.0f, in);
		world.WriteFrame(u, world.packets[u->frameNo], (EmitBlock*)events.data());

		Hash fh;
		const size_t cap = scene.GetTotalEntityCap();
		for (int unit = 0; unit < (int)U_COUNT; unit++)
		{
			const auto& cmd = u->indirectDrawBufferPtr[unit];
			fh.Add(cmd.count); fh.Add(cmd.instanceCount); fh.Add(cmd.firstIndex); fh.Add(cmd.baseVertex); fh.Add(cmd.baseInstance);
			const size_t start = scene.GetEntityPerUnit() * unit, n = cmd.instanceCount;
			maxCount[unit] = std::max(maxCount[unit], n);
			const char* ivb = (const char*)u->instanceVertexBufferDataPtr;
			fh.Bytes(ivb + cap * 0 + start * sizeof(vec4), n * sizeof(vec4));
			fh.Bytes(ivb + cap * sizeof(vec4) + start * sizeof(vec4), n * sizeof(vec4));
			fh.Bytes((const char*)u->instanceStorageBufferDataPtr + start * sizeof(ISBData), n * sizeof(ISBData));
		}
		const FramePacket& pk = world.packets[u->frameNo];
		fh.Add(pk.ubo); fh.Add(pk.emitCount); fh.Add(pk.flags);
		fh.Bytes(events.data(), offsetof(EmitBlock, cmds) + sizeof(EmitCmd) * pk.emitCount);
		fh.Add(world.Score()); fh.Add(world.Wave()); fh.Add((uint64_t)world.TotalEntities());
		maxEntities = std::max(maxEntities, world.TotalEntities());
		total.Add(fh.h); checkedFrames++;
		if (f % 500 == 0) std::printf("frame %5d  hash %016llx  entities %4zu  score %d wave %d\n", f, (unsigned long long)fh.h, world.TotalEntities(), world.Score(), world.Wave());

		scene.UpdateEnd(u);
	}
	std::printf("TOTAL %016llx over %d frames, max entities %zu, max per unit:", (unsigned long long)total.h, checkedFrames, maxEntities);
	for (int unit = 0; unit < (int)U_COUNT; unit++) std::printf(" %zu", maxCount[unit]);
	std::printf("\n");
	return 0;
}
